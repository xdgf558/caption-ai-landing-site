PRAGMA defer_foreign_keys=ON;;
CREATE TABLE d1_migrations(id INTEGER PRIMARY KEY,name TEXT UNIQUE,applied_at TEXT);
CREATE TABLE music_admin_audit_logs (
  id TEXT PRIMARY KEY NOT NULL,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  target_id TEXT NOT NULL,
  summary_json TEXT NOT NULL CHECK (json_valid(summary_json) AND json_type(summary_json) = 'object'),
  request_id TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL CHECK (created_at >= 0)
) STRICT;
CREATE TABLE music_analytics_admission_guard (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  passed INTEGER NOT NULL CHECK(passed=1)
) STRICT;
CREATE TABLE music_analytics_daily (
  day_start_ms INTEGER NOT NULL CHECK(day_start_ms>=0 AND day_start_ms%86400000=0),
  metric TEXT NOT NULL CHECK(metric IN ('play_start','qualified_play','play_complete','preview_end','vip_cta_click','membership_center_open','vip_grant_confirmed','vip_grant_reversed')),
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  variant TEXT NOT NULL CHECK(variant IN ('full','preview')),
  access_kind TEXT NOT NULL CHECK(access_kind IN ('free','vip','unknown')),
  value INTEGER NOT NULL CHECK(value>=0),
  PRIMARY KEY(day_start_ms,metric,track_id,variant,access_kind)
) STRICT;
CREATE TABLE music_analytics_events (
  event_id TEXT PRIMARY KEY NOT NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('play_start','qualified_play','play_complete','preview_end','vip_cta_click','membership_center_open','vip_grant_confirmed','vip_grant_reversed')),
  play_session_id TEXT,
  anonymous_session_id TEXT NOT NULL,
  track_id TEXT NOT NULL,
  revision_no INTEGER NOT NULL,
  variant TEXT NOT NULL CHECK (variant IN ('full','preview')),
  occurred_at INTEGER NOT NULL CHECK (occurred_at >= 0),
  received_at INTEGER NOT NULL CHECK (received_at >= 0),
  listened_ms INTEGER NOT NULL DEFAULT 0 CHECK (listened_ms >= 0),
  entry_source TEXT NOT NULL CHECK (entry_source IN ('catalog','collection','detail','player','membership')), consent_version TEXT,
  FOREIGN KEY (track_id, revision_no) REFERENCES music_track_revisions(track_id, revision_no)
) STRICT;
CREATE TABLE music_analytics_health (
  id INTEGER PRIMARY KEY CHECK(id=1),
  last_sweep_at INTEGER NOT NULL CHECK(last_sweep_at>=0)
) STRICT;
CREATE TABLE music_analytics_rates (
  scope TEXT NOT NULL CHECK(scope IN ('session','source','global')),
  window_start INTEGER NOT NULL CHECK(window_start>=0 AND window_start%60000=0),
  subject TEXT NOT NULL CHECK(length(subject)=64),
  hits INTEGER NOT NULL CHECK(hits>0),
  PRIMARY KEY(scope,window_start,subject)
) STRICT;
CREATE TABLE music_assets (
  id TEXT PRIMARY KEY NOT NULL,
  owner_track_id TEXT NOT NULL REFERENCES music_tracks(id),
  kind TEXT NOT NULL CHECK (kind IN ('audio','preview','cover','lyrics','evidence')),
  object_key TEXT NOT NULL UNIQUE CHECK (length(object_key) BETWEEN 1 AND 512),
  state TEXT NOT NULL DEFAULT 'reserved' CHECK (state IN ('reserved','uploading','uploaded','validated','rejected')),
  content_type TEXT NOT NULL,
  format TEXT NOT NULL CHECK (format IN ('mp3','jpeg','png','webp','txt','lrc','pdf')),
  byte_size INTEGER CHECK (byte_size > 0),
  duration_ms INTEGER CHECK (duration_ms > 0),
  derived_from_asset_id TEXT,
  source_start_ms INTEGER,
  source_end_ms INTEGER,
  sha256 TEXT CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
  etag TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  UNIQUE (owner_track_id, id),
  FOREIGN KEY (owner_track_id, derived_from_asset_id) REFERENCES music_assets(owner_track_id, id),
  CHECK (derived_from_asset_id IS NULL OR derived_from_asset_id <> id),
  CHECK (kind = 'preview' OR (derived_from_asset_id IS NULL AND source_start_ms IS NULL AND source_end_ms IS NULL)),
  CHECK (state NOT IN ('uploaded','validated') OR (byte_size IS NOT NULL AND sha256 IS NOT NULL)),
  CHECK (kind NOT IN ('audio','preview') OR state <> 'validated' OR duration_ms IS NOT NULL),
  CHECK (kind <> 'preview' OR state <> 'validated' OR
    (derived_from_asset_id IS NOT NULL AND source_start_ms IS NOT NULL AND source_end_ms IS NOT NULL AND source_start_ms >= 0 AND source_end_ms > source_start_ms)),
  CHECK ((kind IN ('audio','preview') AND format = 'mp3' AND content_type = 'audio/mpeg') OR
    (kind = 'cover' AND ((format = 'jpeg' AND content_type = 'image/jpeg') OR (format = 'png' AND content_type = 'image/png') OR (format = 'webp' AND content_type = 'image/webp'))) OR
    (kind = 'lyrics' AND format IN ('txt','lrc') AND content_type = 'text/plain') OR
    (kind = 'evidence' AND ((format = 'pdf' AND content_type = 'application/pdf') OR (format = 'jpeg' AND content_type = 'image/jpeg') OR (format = 'png' AND content_type = 'image/png')))),
  CHECK (byte_size IS NULL OR byte_size <= CASE kind WHEN 'audio' THEN 33554432 WHEN 'preview' THEN 4194304 WHEN 'cover' THEN 5242880 WHEN 'lyrics' THEN 131072 WHEN 'evidence' THEN 10485760 END)
) STRICT;
CREATE TABLE music_collection_assets (
  id TEXT PRIMARY KEY NOT NULL,
  owner_collection_id TEXT NOT NULL REFERENCES music_collections(id),
  kind TEXT NOT NULL CHECK (kind = 'cover'),
  object_key TEXT NOT NULL UNIQUE CHECK (length(object_key) BETWEEN 1 AND 512),
  state TEXT NOT NULL DEFAULT 'reserved' CHECK (state IN ('reserved','uploading','uploaded','validated','rejected')),
  content_type TEXT NOT NULL,
  format TEXT NOT NULL CHECK (format IN ('jpeg','png','webp')),
  byte_size INTEGER CHECK (byte_size > 0 AND byte_size <= 5242880),
  sha256 TEXT CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
  etag TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  CHECK (state NOT IN ('uploaded','validated') OR (byte_size IS NOT NULL AND sha256 IS NOT NULL AND etag IS NOT NULL)),
  CHECK ((format = 'jpeg' AND content_type = 'image/jpeg') OR
    (format = 'png' AND content_type = 'image/png') OR
    (format = 'webp' AND content_type = 'image/webp'))
) STRICT;
CREATE TABLE music_collection_tracks (
  collection_id TEXT NOT NULL REFERENCES music_collections(id),
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  position INTEGER NOT NULL CHECK (position >= 0),
  PRIMARY KEY (collection_id, track_id),
  UNIQUE (collection_id, position)
) STRICT;
CREATE TABLE music_collection_upload_sessions (
  id TEXT PRIMARY KEY NOT NULL,
  asset_id TEXT NOT NULL UNIQUE REFERENCES music_collection_assets(id),
  actor_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','uploading','completed','rejected','expired')),
  declared_bytes INTEGER NOT NULL CHECK (declared_bytes > 0 AND declared_bytes <= 5242880),
  actual_bytes INTEGER CHECK (actual_bytes >= 0 AND actual_bytes <= declared_bytes),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), expected_sha256 TEXT
  CHECK (expected_sha256 IS NULL OR (length(expected_sha256)=64 AND expected_sha256 NOT GLOB '*[^0-9a-f]*')), write_token TEXT,
  CHECK (status <> 'completed' OR actual_bytes = declared_bytes AND actual_bytes IS NOT NULL)
) STRICT;
CREATE TABLE music_collections (
  id TEXT PRIMARY KEY NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  original_locale TEXT NOT NULL CHECK (original_locale IN ('zh-Hant','zh-Hans','en','ja')),
  title_json TEXT NOT NULL CHECK (json_valid(title_json) AND json_type(title_json) = 'object'),
  description_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(description_json) AND json_type(description_json) = 'object'),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at)
, collection_type TEXT NOT NULL DEFAULT 'playlist'
  CHECK (collection_type IN ('playlist','album')), listening_mode TEXT NOT NULL DEFAULT 'mixed'
  CHECK (listening_mode IN ('mixed','free','vip') AND (collection_type='album' OR listening_mode='mixed')), cover_track_id TEXT REFERENCES music_tracks(id)
  CHECK (collection_type='album' OR cover_track_id IS NULL), cover_asset_id TEXT REFERENCES music_collection_assets(id)) STRICT;
CREATE TABLE music_featured_home (
  id INTEGER PRIMARY KEY NOT NULL CHECK (id = 1),
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= 0)
) STRICT;
CREATE TABLE music_featured_items (
  slot_kind TEXT NOT NULL CHECK (slot_kind IN ('primary','secondary','collection')),
  position INTEGER NOT NULL CHECK (position >= 0 AND
    ((slot_kind = 'primary' AND position = 0) OR (slot_kind IN ('secondary','collection') AND position < 6))),
  track_id TEXT REFERENCES music_tracks(id),
  collection_id TEXT REFERENCES music_collections(id),
  PRIMARY KEY (slot_kind, position),
  UNIQUE (track_id),
  UNIQUE (collection_id),
  CHECK ((slot_kind IN ('primary','secondary') AND track_id IS NOT NULL AND collection_id IS NULL) OR
    (slot_kind = 'collection' AND collection_id IS NOT NULL AND track_id IS NULL))
) STRICT;
CREATE TABLE music_membership_attributions (
  verified_grant_ref TEXT PRIMARY KEY NOT NULL,
  anonymous_session_id TEXT NOT NULL,
  entry_track_id TEXT NOT NULL REFERENCES music_tracks(id),
  observed_at INTEGER NOT NULL CHECK (observed_at >= 0),
  qualification TEXT NOT NULL CHECK (qualification IN ('verified_new','unavailable')),
  reversed_at INTEGER CHECK (reversed_at >= observed_at)
) STRICT;
CREATE TABLE music_mutations (
  actor_id TEXT NOT NULL,
  route TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  request_hash TEXT NOT NULL CHECK (length(request_hash) = 64),
  result_json TEXT NOT NULL CHECK (json_valid(result_json) AND json_type(result_json) = 'object'),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (actor_id, route, idempotency_key)
) STRICT;
CREATE TABLE music_publication_guards (
  operation_token TEXT PRIMARY KEY NOT NULL,
  passed INTEGER NOT NULL CHECK (passed = 1)
) STRICT;
CREATE TABLE music_rate_sources (
  category TEXT NOT NULL CHECK (category IN ('catalog','artwork','audio')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  source_hash TEXT NOT NULL CHECK (length(source_hash)=64 AND source_hash NOT GLOB '*[^0-9a-f]*'),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start,source_hash)
) STRICT;
CREATE TABLE music_rate_windows (
  category TEXT NOT NULL CHECK (category IN ('catalog','artwork','audio')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start)
) STRICT;
CREATE TABLE music_rights_evidence (
  review_id TEXT NOT NULL REFERENCES music_rights_reviews(id),
  asset_id TEXT NOT NULL REFERENCES music_assets(id),
  PRIMARY KEY (review_id, asset_id)
) STRICT;
CREATE TABLE music_rights_reviews (
  id TEXT PRIMARY KEY NOT NULL,
  revision_id TEXT NOT NULL UNIQUE REFERENCES music_track_revisions(id),
  review_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(review_json) AND json_type(review_json) = 'object'),
  review_status TEXT NOT NULL DEFAULT 'pending' CHECK (review_status IN ('pending','approved','blocked')),
  reviewer_id TEXT,
  reviewed_at INTEGER CHECK (reviewed_at >= 0), revision_fingerprint TEXT
  CHECK (revision_fingerprint IS NULL OR (length(revision_fingerprint) = 64 AND revision_fingerprint NOT GLOB '*[^0-9a-f]*')),
  CHECK (review_status = 'pending' OR (reviewer_id IS NOT NULL AND length(reviewer_id) > 0 AND reviewed_at IS NOT NULL))
) STRICT;
CREATE TABLE music_settings (
  key TEXT PRIMARY KEY NOT NULL,
  value_json TEXT NOT NULL CHECK (json_valid(value_json)),
  updated_at INTEGER NOT NULL CHECK (updated_at >= 0)
) STRICT;
CREATE TABLE music_share_rate_sources (
  category TEXT NOT NULL CHECK (category IN ('share')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  source_hash TEXT NOT NULL CHECK (length(source_hash)=64 AND source_hash NOT GLOB '*[^0-9a-f]*'),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start,source_hash)
) STRICT;
CREATE TABLE music_share_rate_windows (
  category TEXT NOT NULL CHECK (category IN ('share')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start)
) STRICT;
CREATE TABLE music_track_revisions (
  id TEXT PRIMARY KEY NOT NULL,
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  revision_no INTEGER NOT NULL CHECK (revision_no > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json) AND json_type(metadata_json) = 'object'),
  audio_asset_id TEXT,
  preview_asset_id TEXT,
  cover_asset_id TEXT,
  lyrics_asset_id TEXT,
  access_mode TEXT NOT NULL DEFAULT 'vip' CHECK (access_mode IN ('free','vip','early_access')),
  early_access_until INTEGER CHECK (early_access_until >= 0),
  post_early_access_mode TEXT CHECK (post_early_access_mode IN ('free','vip')),
  policy_version INTEGER NOT NULL DEFAULT 1 CHECK (policy_version > 0),
  technical_reviewed_at INTEGER CHECK (technical_reviewed_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), technical_fingerprint TEXT
  CHECK (technical_fingerprint IS NULL OR (length(technical_fingerprint) = 64 AND technical_fingerprint NOT GLOB '*[^0-9a-f]*')), free_until INTEGER
  CHECK (free_until IS NULL OR (free_until>=0 AND access_mode='vip')),
  UNIQUE (track_id, id),
  UNIQUE (track_id, revision_no),
  FOREIGN KEY (track_id, audio_asset_id) REFERENCES music_assets(owner_track_id, id),
  FOREIGN KEY (track_id, preview_asset_id) REFERENCES music_assets(owner_track_id, id),
  FOREIGN KEY (track_id, cover_asset_id) REFERENCES music_assets(owner_track_id, id),
  FOREIGN KEY (track_id, lyrics_asset_id) REFERENCES music_assets(owner_track_id, id),
  CHECK ((access_mode = 'early_access' AND early_access_until IS NOT NULL AND post_early_access_mode IS NOT NULL) OR
    (access_mode IN ('free','vip') AND early_access_until IS NULL AND post_early_access_mode IS NULL)),
  CHECK (state <> 'sealed' OR (audio_asset_id IS NOT NULL AND technical_reviewed_at IS NOT NULL))
) STRICT;
CREATE TABLE music_tracks (
  id TEXT PRIMARY KEY NOT NULL,
  slug TEXT NOT NULL UNIQUE CHECK (length(slug) BETWEEN 1 AND 100),
  lifecycle TEXT NOT NULL DEFAULT 'draft' CHECK (lifecycle IN ('draft','published','unpublished','archived')),
  draft_revision_id TEXT,
  published_revision_id TEXT,
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  first_published_at INTEGER CHECK (first_published_at >= 0),
  published_at INTEGER CHECK (published_at >= first_published_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  UNIQUE (id, slug),
  FOREIGN KEY (id, draft_revision_id) REFERENCES music_track_revisions(track_id, id),
  FOREIGN KEY (id, published_revision_id) REFERENCES music_track_revisions(track_id, id),
  CHECK (lifecycle <> 'published' OR (published_revision_id IS NOT NULL AND first_published_at IS NOT NULL AND published_at IS NOT NULL)),
  CHECK (lifecycle NOT IN ('draft','archived') OR published_revision_id IS NULL)
) STRICT;
CREATE TABLE music_upload_cleanup (
  upload_id TEXT PRIMARY KEY NOT NULL REFERENCES music_upload_sessions(id),
  asset_id TEXT NOT NULL UNIQUE REFERENCES music_assets(id),
  actor_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  plan_hash TEXT NOT NULL CHECK (length(plan_hash)=64),
  claimed_at INTEGER NOT NULL CHECK (claimed_at>=0),
  proof_json TEXT CHECK (proof_json IS NULL OR
    (json_valid(proof_json) AND json_type(proof_json)='object' AND
      COALESCE(json_extract(proof_json,'$.kind') IN ('never_started','object_observed'),0))),
  proved_at INTEGER CHECK (proved_at>=claimed_at),
  released_at INTEGER CHECK (released_at>=proved_at),
  CHECK ((proof_json IS NULL)=(proved_at IS NULL)),
  CHECK (released_at IS NULL OR proved_at IS NOT NULL)
) STRICT;
CREATE TABLE music_upload_sessions (
  id TEXT PRIMARY KEY NOT NULL,
  asset_id TEXT NOT NULL UNIQUE REFERENCES music_assets(id),
  actor_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','uploading','completed','rejected','expired')),
  declared_bytes INTEGER NOT NULL CHECK (declared_bytes > 0 AND declared_bytes <= 33554432),
  actual_bytes INTEGER CHECK (actual_bytes >= 0 AND actual_bytes <= declared_bytes),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), expected_sha256 TEXT
  CHECK (expected_sha256 IS NULL OR (length(expected_sha256)=64 AND expected_sha256 NOT GLOB '*[^0-9a-f]*')), write_token TEXT,
  CHECK (status <> 'completed' OR actual_bytes = declared_bytes AND actual_bytes IS NOT NULL)
) STRICT;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(1,'0001_music_foundation.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(2,'0002_music_publication.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(3,'0003_music_uploads.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(4,'0004_music_cleanup.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(5,'0005_music_rate_limits.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(6,'0006_music_analytics.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(7,'0007_music_albums.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(8,'0008_music_featured.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(9,'0009_music_album_covers.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(10,'0010_music_limited_free.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(11,'0011_music_share_rate_limits.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('ca760000-0000-4000-8000-000000000091','isolated-fixture','fixture.seed','ca760000-0000-4000-8000-000000000010','{"fixture":true}','ca760000-0000-4000-8000-000000000092',1791158400000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000012','ca760000-0000-4000-8000-000000000010','audio','music/audio/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000012.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000013','ca760000-0000-4000-8000-000000000010','preview','music/previews/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000013.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000012',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000014','ca760000-0000-4000-8000-000000000010','cover','music/covers/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000014.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000015','ca760000-0000-4000-8000-000000000010','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000015.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000022','ca760000-0000-4000-8000-000000000020','audio','music/audio/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000022.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000023','ca760000-0000-4000-8000-000000000020','preview','music/previews/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000023.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000022',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000024','ca760000-0000-4000-8000-000000000020','cover','music/covers/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000024.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000025','ca760000-0000-4000-8000-000000000020','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000025.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000032','ca760000-0000-4000-8000-000000000030','audio','music/audio/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000032.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000033','ca760000-0000-4000-8000-000000000030','preview','music/previews/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000033.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000032',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000034','ca760000-0000-4000-8000-000000000030','cover','music/covers/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000034.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000035','ca760000-0000-4000-8000-000000000030','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000035.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000042','ca760000-0000-4000-8000-000000000040','audio','music/audio/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000042.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000043','ca760000-0000-4000-8000-000000000040','preview','music/previews/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000043.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000042',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000044','ca760000-0000-4000-8000-000000000040','cover','music/covers/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000044.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000045','ca760000-0000-4000-8000-000000000040','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000045.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000052','ca760000-0000-4000-8000-000000000050','audio','music/audio/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000052.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000053','ca760000-0000-4000-8000-000000000050','preview','music/previews/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000053.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000052',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000054','ca760000-0000-4000-8000-000000000050','cover','music/covers/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000054.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000055','ca760000-0000-4000-8000-000000000050','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000055.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000062','ca760000-0000-4000-8000-000000000060','audio','music/audio/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000062.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000063','ca760000-0000-4000-8000-000000000060','preview','music/previews/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000063.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000062',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000064','ca760000-0000-4000-8000-000000000060','cover','music/covers/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000064.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000065','ca760000-0000-4000-8000-000000000060','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000065.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_collection_tracks"("collection_id","track_id","position") VALUES('ca760000-0000-4000-8000-000000000090','ca760000-0000-4000-8000-000000000010',0);;
INSERT INTO "music_collections"("id","slug","original_locale","title_json","description_json","status","version","created_at","updated_at","collection_type","listening_mode","cover_track_id","cover_asset_id") VALUES('ca760000-0000-4000-8000-000000000090','old-collection','en','{"en":"Old collection"}','{}','published',1,1791158390000,1791158390000,'playlist','mixed',NULL,NULL);;
INSERT INTO "music_featured_home"("id","version","updated_at") VALUES(1,1,0);;
INSERT INTO "music_featured_items"("slot_kind","position","track_id","collection_id") VALUES('primary',0,'ca760000-0000-4000-8000-000000000010',NULL);;
INSERT INTO "music_settings"("key","value_json","updated_at") VALUES('catalogVersion','0',0);;
INSERT INTO "music_settings"("key","value_json","updated_at") VALUES('previewLimitMs','45000',0);;
INSERT INTO "music_settings"("key","value_json","updated_at") VALUES('storageQuotaBytes','0',0);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000011','ca760000-0000-4000-8000-000000000010',1,'sealed','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000012','ca760000-0000-4000-8000-000000000013','ca760000-0000-4000-8000-000000000014','ca760000-0000-4000-8000-000000000015','free',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000021','ca760000-0000-4000-8000-000000000020',1,'sealed','{"originalLocale":"en","title":{"en":"vip","zh-Hant":"夾具 vip"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000022','ca760000-0000-4000-8000-000000000023','ca760000-0000-4000-8000-000000000024','ca760000-0000-4000-8000-000000000025','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000031','ca760000-0000-4000-8000-000000000030',1,'sealed','{"originalLocale":"en","title":{"en":"limited-active","zh-Hant":"夾具 limited-active"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000032','ca760000-0000-4000-8000-000000000033','ca760000-0000-4000-8000-000000000034','ca760000-0000-4000-8000-000000000035','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',1791158460000);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000041','ca760000-0000-4000-8000-000000000040',1,'sealed','{"originalLocale":"en","title":{"en":"limited-expired","zh-Hant":"夾具 limited-expired"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000042','ca760000-0000-4000-8000-000000000043','ca760000-0000-4000-8000-000000000044','ca760000-0000-4000-8000-000000000045','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',1791158340000);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000051','ca760000-0000-4000-8000-000000000050',1,'sealed','{"originalLocale":"en","title":{"en":"early-access","zh-Hant":"夾具 early-access"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000052','ca760000-0000-4000-8000-000000000053','ca760000-0000-4000-8000-000000000054','ca760000-0000-4000-8000-000000000055','early_access',1791158460000,'vip',1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000061','ca760000-0000-4000-8000-000000000060',1,'sealed','{"originalLocale":"en","title":{"en":"unpublished","zh-Hant":"夾具 unpublished"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000062','ca760000-0000-4000-8000-000000000063','ca760000-0000-4000-8000-000000000064','ca760000-0000-4000-8000-000000000065','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000010','permanent-free','published',NULL,'ca760000-0000-4000-8000-000000000011',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000020','vip','published',NULL,'ca760000-0000-4000-8000-000000000021',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000030','limited-active','published',NULL,'ca760000-0000-4000-8000-000000000031',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000040','limited-expired','published',NULL,'ca760000-0000-4000-8000-000000000041',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000050','early-access','published',NULL,'ca760000-0000-4000-8000-000000000051',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000060','unpublished','unpublished',NULL,'ca760000-0000-4000-8000-000000000061',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000070','draft-no-audio','draft',NULL,NULL,1,NULL,NULL,1791158380000,1791158380000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000080','archived-no-audio','archived',NULL,NULL,1,NULL,NULL,1791158380000,1791158380000);;
CREATE INDEX music_analytics_rates_expiry ON music_analytics_rates(window_start);
CREATE INDEX music_assets_derived ON music_assets(derived_from_asset_id);
CREATE INDEX music_assets_owner ON music_assets(owner_track_id, state, kind);
CREATE INDEX music_attribution_retention ON music_membership_attributions(observed_at);
CREATE INDEX music_audit_time ON music_admin_audit_logs(created_at, id);
CREATE INDEX music_collection_track ON music_collection_tracks(track_id);
CREATE INDEX music_collections_type_status ON music_collections(collection_type,status,slug);
CREATE UNIQUE INDEX music_events_play_once
  ON music_analytics_events(anonymous_session_id,play_session_id,event_type);
CREATE INDEX music_events_retention ON music_analytics_events(received_at);
CREATE INDEX music_events_session ON music_analytics_events(anonymous_session_id, track_id, variant, event_type, occurred_at);
CREATE INDEX music_mutations_expiry ON music_mutations(expires_at);
CREATE INDEX music_rate_sources_expiry ON music_rate_sources(window_start);
CREATE INDEX music_rate_windows_expiry ON music_rate_windows(window_start);
CREATE INDEX music_share_rate_sources_expiry ON music_share_rate_sources(window_start);
CREATE INDEX music_share_rate_windows_expiry ON music_share_rate_windows(window_start);
CREATE INDEX music_tracks_public ON music_tracks(lifecycle, published_at DESC, id);
CREATE INDEX music_upload_expiry ON music_upload_sessions(status, expires_at);
CREATE TRIGGER music_album_cover_insert BEFORE INSERT ON music_collections WHEN NEW.cover_asset_id IS NOT NULL
BEGIN SELECT RAISE(ABORT,'MUSIC_ALBUM_COVER_INVALID'); END;
CREATE TRIGGER music_album_cover_update BEFORE UPDATE ON music_collections
WHEN NEW.cover_asset_id IS NOT NULL AND (NEW.collection_type<>'album' OR NOT EXISTS
 (SELECT 1 FROM music_collection_assets WHERE id=NEW.cover_asset_id AND owner_collection_id=NEW.id AND state='validated' AND kind='cover'))
BEGIN SELECT RAISE(ABORT,'MUSIC_ALBUM_COVER_INVALID'); END;
CREATE TRIGGER music_analytics_event_aggregate AFTER INSERT ON music_analytics_events
BEGIN
  INSERT INTO music_analytics_daily(day_start_ms,metric,track_id,variant,access_kind,value)
  SELECT NEW.received_at-NEW.received_at%86400000,NEW.event_type,NEW.track_id,NEW.variant,
    IIF(r.access_mode='free' OR (r.free_until IS NOT NULL AND NEW.received_at<r.free_until)
      OR (r.access_mode='early_access' AND r.early_access_until<=NEW.received_at
      AND r.post_early_access_mode='free'),'free','vip'),1
  FROM music_track_revisions r WHERE r.track_id=NEW.track_id AND r.revision_no=NEW.revision_no
  ON CONFLICT(day_start_ms,metric,track_id,variant,access_kind) DO UPDATE SET value=value+1;
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_AGGREGATE_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_analytics_event_validate BEFORE INSERT ON music_analytics_events
BEGIN
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_INVALID_EVENT') WHERE
    NEW.event_type NOT IN ('play_start','qualified_play','play_complete','preview_end','vip_cta_click')
    OR NEW.consent_version IS NOT 'music-analytics-v1' OR NEW.play_session_id IS NULL;
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_INVALID_TRACK') WHERE NOT EXISTS (
    SELECT 1 FROM music_analytics_public_variants p WHERE p.track_id=NEW.track_id
      AND p.revision_no=NEW.revision_no AND p.variant=NEW.variant AND p.published_at<=NEW.received_at
      AND NEW.listened_ms<=p.duration_ms+1000
      AND (NEW.event_type<>'qualified_play' OR NEW.listened_ms>=MIN(30000,p.duration_ms/2.0))
      AND (NEW.event_type<>'play_complete' OR NEW.listened_ms>=p.duration_ms*0.9));
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_INVALID_EVENT') WHERE
    (NEW.event_type='preview_end' AND NEW.variant<>'preview')
    OR (NEW.event_type IN ('play_start','vip_cta_click') AND NEW.listened_ms<>0);
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_SESSION_CONFLICT') WHERE EXISTS (
    SELECT 1 FROM music_analytics_events e WHERE e.anonymous_session_id=NEW.anonymous_session_id
      AND e.play_session_id=NEW.play_session_id
      AND (e.track_id<>NEW.track_id OR e.revision_no<>NEW.revision_no OR e.variant<>NEW.variant));
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_START_REQUIRED') WHERE
    NEW.event_type IN ('qualified_play','play_complete','preview_end') AND NOT EXISTS (
      SELECT 1 FROM music_analytics_events e WHERE e.anonymous_session_id=NEW.anonymous_session_id
        AND e.play_session_id=NEW.play_session_id AND e.event_type='play_start');
  -- Validate first, then suppress. Never depend on SQLite trigger ordering.
  -- The rolling window uses server receive time, not a client minute bucket.
  SELECT RAISE(IGNORE) WHERE NEW.event_type='qualified_play' AND EXISTS (
    SELECT 1 FROM music_analytics_events e WHERE e.anonymous_session_id=NEW.anonymous_session_id
      AND e.track_id=NEW.track_id AND e.variant=NEW.variant AND e.event_type='qualified_play'
      AND e.received_at>NEW.received_at-1800000);
END;
CREATE TRIGGER music_analytics_rate_insert BEFORE INSERT ON music_analytics_rates
WHEN (NEW.scope='session' AND NEW.hits>60) OR (NEW.scope='source' AND NEW.hits>600)
  OR (NEW.scope='global' AND NEW.hits>12000)
BEGIN SELECT RAISE(ABORT,'MUSIC_ANALYTICS_RATE_LIMITED'); END;
CREATE TRIGGER music_analytics_rate_update BEFORE UPDATE ON music_analytics_rates
WHEN (NEW.scope='session' AND NEW.hits>60) OR (NEW.scope='source' AND NEW.hits>600)
  OR (NEW.scope='global' AND NEW.hits>12000)
BEGIN SELECT RAISE(ABORT,'MUSIC_ANALYTICS_RATE_LIMITED'); END;
CREATE TRIGGER music_asset_identity BEFORE UPDATE OF id, owner_track_id, kind, object_key ON music_assets
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_IDENTITY'); END;
CREATE TRIGGER music_asset_immutable BEFORE UPDATE ON music_assets
WHEN OLD.state = 'validated' BEGIN SELECT RAISE(ABORT, 'MUSIC_VALIDATED_ASSET'); END;
CREATE TRIGGER music_asset_replace BEFORE INSERT ON music_assets
WHEN EXISTS (SELECT 1 FROM music_assets WHERE id = NEW.id OR object_key = NEW.object_key)
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_IDENTITY'); END;
CREATE TRIGGER music_asset_source_insert BEFORE INSERT ON music_assets
WHEN NEW.derived_from_asset_id IS NOT NULL AND NOT EXISTS
  (SELECT 1 FROM music_assets WHERE id = NEW.derived_from_asset_id AND kind = 'audio' AND owner_track_id = NEW.owner_track_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_PREVIEW_SOURCE'); END;
CREATE TRIGGER music_asset_source_update BEFORE UPDATE OF derived_from_asset_id ON music_assets
WHEN NEW.derived_from_asset_id IS NOT NULL AND NOT EXISTS
  (SELECT 1 FROM music_assets WHERE id = NEW.derived_from_asset_id AND kind = 'audio' AND owner_track_id = NEW.owner_track_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_PREVIEW_SOURCE'); END;
CREATE TRIGGER music_audit_delete BEFORE DELETE ON music_admin_audit_logs
BEGIN SELECT RAISE(ABORT, 'MUSIC_APPEND_ONLY_AUDIT'); END;
CREATE TRIGGER music_audit_replace BEFORE INSERT ON music_admin_audit_logs
WHEN EXISTS (SELECT 1 FROM music_admin_audit_logs WHERE id = NEW.id OR request_id = NEW.request_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_APPEND_ONLY_AUDIT'); END;
CREATE TRIGGER music_audit_update BEFORE UPDATE ON music_admin_audit_logs
BEGIN SELECT RAISE(ABORT, 'MUSIC_APPEND_ONLY_AUDIT'); END;
CREATE TRIGGER music_cleanup_asset_delete BEFORE DELETE ON music_assets
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=OLD.id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_asset_update BEFORE UPDATE ON music_assets
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id IN (NEW.id,NEW.derived_from_asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_audit BEFORE INSERT ON music_admin_audit_logs
WHEN NEW.action NOT IN ('music.upload.reserve','music.upload.start','music.upload.reject','music.upload.complete',
  'music.cleanup.claim','music.cleanup.prove','music.cleanup.release') AND EXISTS
  (SELECT 1 FROM music_upload_cleanup c WHERE NEW.target_id=c.asset_id
    OR EXISTS (SELECT 1 FROM json_tree(NEW.summary_json) j WHERE j.atom=c.asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_claim BEFORE INSERT ON music_upload_cleanup
WHEN NEW.proof_json IS NOT NULL OR NEW.released_at IS NOT NULL OR NOT EXISTS
  (SELECT 1 FROM music_upload_sessions u JOIN music_asset_references r ON r.id=u.asset_id
   WHERE u.id=NEW.upload_id AND u.asset_id=NEW.asset_id AND u.expires_at<=NEW.claimed_at-604800000
   AND r.revision_ref=0 AND r.evidence_ref=0 AND r.rights_ref=0 AND r.derived_ref=0 AND r.audit_ref=0)
  OR EXISTS (SELECT 1 FROM music_upload_cleanup WHERE upload_id=NEW.upload_id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_CLEANUP_CONFLICT'); END;
CREATE TRIGGER music_cleanup_delete BEFORE DELETE ON music_upload_cleanup
BEGIN SELECT RAISE(ABORT,'MUSIC_CLEANUP_IMMUTABLE'); END;
CREATE TRIGGER music_cleanup_evidence BEFORE INSERT ON music_rights_evidence
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_revision_insert BEFORE INSERT ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id IN
  (NEW.audio_asset_id,NEW.preview_asset_id,NEW.cover_asset_id,NEW.lyrics_asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_revision_update BEFORE UPDATE ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id IN
  (NEW.audio_asset_id,NEW.preview_asset_id,NEW.cover_asset_id,NEW.lyrics_asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_rights_insert BEFORE INSERT ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup c,json_tree(NEW.review_json) j WHERE j.atom=c.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_rights_update BEFORE UPDATE ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup c,json_tree(NEW.review_json) j WHERE j.atom=c.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_source_insert BEFORE INSERT ON music_assets
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.derived_from_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_update BEFORE UPDATE ON music_upload_cleanup
WHEN NEW.upload_id<>OLD.upload_id OR NEW.asset_id<>OLD.asset_id OR NEW.actor_id<>OLD.actor_id
  OR NEW.reason<>OLD.reason OR NEW.plan_hash<>OLD.plan_hash OR NEW.claimed_at<>OLD.claimed_at
  OR (OLD.proof_json IS NOT NULL AND (NEW.proof_json IS NOT OLD.proof_json OR NEW.proved_at IS NOT OLD.proved_at))
  OR (OLD.proof_json IS NULL AND NEW.released_at IS NOT NULL)
  OR OLD.released_at IS NOT NULL
BEGIN SELECT RAISE(ABORT,'MUSIC_CLEANUP_IMMUTABLE'); END;
CREATE TRIGGER music_cleanup_upload_update BEFORE UPDATE ON music_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE upload_id=OLD.id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_collection_asset_delete BEFORE DELETE ON music_collection_assets
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETAINED'); END;
CREATE TRIGGER music_collection_asset_identity BEFORE UPDATE OF id,owner_collection_id,kind,object_key,format,content_type ON music_collection_assets
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_IDENTITY'); END;
CREATE TRIGGER music_collection_asset_immutable BEFORE UPDATE ON music_collection_assets WHEN OLD.state='validated'
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_IMMUTABLE'); END;
CREATE TRIGGER music_collection_asset_owner BEFORE INSERT ON music_collection_assets
WHEN NOT EXISTS(SELECT 1 FROM music_collections WHERE id=NEW.owner_collection_id AND collection_type='album' AND status='draft')
BEGIN SELECT RAISE(ABORT,'MUSIC_DRAFT_REQUIRED'); END;
CREATE TRIGGER music_collection_asset_replace BEFORE INSERT ON music_collection_assets WHEN EXISTS(SELECT 1 FROM music_collection_assets WHERE id=NEW.id OR object_key=NEW.object_key)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_IMMUTABLE'); END;
CREATE TRIGGER music_collection_type_immutable BEFORE UPDATE OF collection_type ON music_collections
WHEN NEW.collection_type<>OLD.collection_type
BEGIN SELECT RAISE(ABORT,'MUSIC_COLLECTION_IDENTITY'); END;
CREATE TRIGGER music_collection_type_replace BEFORE INSERT ON music_collections
WHEN EXISTS (SELECT 1 FROM music_collections
  WHERE (id=NEW.id OR slug=NEW.slug) AND collection_type<>NEW.collection_type)
BEGIN SELECT RAISE(ABORT,'MUSIC_COLLECTION_IDENTITY'); END;
CREATE TRIGGER music_collection_upload_identity BEFORE UPDATE ON music_collection_upload_sessions
WHEN NEW.id<>OLD.id OR NEW.asset_id<>OLD.asset_id OR NEW.actor_id<>OLD.actor_id
  OR NEW.declared_bytes<>OLD.declared_bytes OR NEW.expected_sha256 IS NOT OLD.expected_sha256
  OR NEW.created_at<>OLD.created_at OR NEW.expires_at<>OLD.expires_at
  OR (OLD.write_token IS NOT NULL AND NEW.write_token IS NOT OLD.write_token)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_collection_upload_no_delete BEFORE DELETE ON music_collection_upload_sessions
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_collection_upload_no_replace BEFORE INSERT ON music_collection_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_collection_upload_sessions WHERE id=NEW.id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_collection_upload_terminal BEFORE UPDATE ON music_collection_upload_sessions WHEN OLD.status IN ('completed','rejected','expired')
BEGIN SELECT RAISE(ABORT,'MUSIC_UPLOAD_TERMINAL'); END;
CREATE TRIGGER music_collection_upload_transition BEFORE UPDATE OF status ON music_collection_upload_sessions
WHEN NOT ((OLD.status='reserved' AND NEW.status IN ('uploading','expired','rejected'))
  OR (OLD.status='uploading' AND NEW.status IN ('completed','rejected','expired')))
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_STATE'); END;
CREATE TRIGGER music_evidence_delete BEFORE DELETE ON music_rights_evidence
WHEN EXISTS (SELECT 1 FROM music_rights_reviews rr JOIN music_track_revisions r ON r.id = rr.revision_id
  WHERE rr.id = OLD.review_id AND r.state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_evidence_insert BEFORE INSERT ON music_rights_evidence
WHEN NOT EXISTS (SELECT 1 FROM music_rights_reviews rr JOIN music_track_revisions r ON r.id = rr.revision_id
  JOIN music_assets a ON a.id = NEW.asset_id WHERE rr.id = NEW.review_id AND r.state = 'draft'
  AND a.owner_track_id = r.track_id AND a.kind = 'evidence' AND a.state = 'validated')
BEGIN SELECT RAISE(ABORT, 'MUSIC_EVIDENCE_REFERENCE'); END;
CREATE TRIGGER music_evidence_update BEFORE UPDATE ON music_rights_evidence
BEGIN SELECT RAISE(ABORT, 'MUSIC_EVIDENCE_REPLACE'); END;
CREATE TRIGGER music_featured_collection_insert BEFORE INSERT ON music_featured_items
WHEN NEW.collection_id IS NOT NULL AND NOT EXISTS (
  SELECT 1 FROM music_collections WHERE id=NEW.collection_id AND status='published'
)
BEGIN SELECT RAISE(ABORT,'MUSIC_FEATURED_COLLECTION_UNAVAILABLE'); END;
CREATE TRIGGER music_featured_track_insert BEFORE INSERT ON music_featured_items
WHEN NEW.track_id IS NOT NULL AND NOT EXISTS (
  SELECT 1 FROM music_tracks WHERE id=NEW.track_id AND lifecycle='published'
)
BEGIN SELECT RAISE(ABORT,'MUSIC_FEATURED_TRACK_UNAVAILABLE'); END;
CREATE TRIGGER music_mutation_delete BEFORE DELETE ON music_mutations
BEGIN SELECT RAISE(ABORT, 'MUSIC_IMMUTABLE_MUTATION'); END;
CREATE TRIGGER music_mutation_replace BEFORE INSERT ON music_mutations
WHEN EXISTS (SELECT 1 FROM music_mutations WHERE actor_id = NEW.actor_id
  AND route = NEW.route AND idempotency_key = NEW.idempotency_key)
BEGIN SELECT RAISE(ABORT, 'MUSIC_IMMUTABLE_MUTATION'); END;
CREATE TRIGGER music_mutation_update BEFORE UPDATE ON music_mutations
BEGIN SELECT RAISE(ABORT, 'MUSIC_IMMUTABLE_MUTATION'); END;
CREATE TRIGGER music_rate_source_identity BEFORE UPDATE ON music_rate_sources
WHEN NEW.category<>OLD.category OR NEW.window_start<>OLD.window_start OR NEW.source_hash<>OLD.source_hash OR NEW.hits<>OLD.hits+1
BEGIN SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID'); END;
CREATE TRIGGER music_rate_source_insert AFTER INSERT ON music_rate_sources
BEGIN
  INSERT INTO music_rate_windows(category,window_start,hits) VALUES(NEW.category,NEW.window_start,1)
  ON CONFLICT(category,window_start) DO UPDATE SET hits=hits+1;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_rate_source_update AFTER UPDATE ON music_rate_sources
BEGIN
  UPDATE music_rate_windows SET hits=hits+1 WHERE category=NEW.category AND window_start=NEW.window_start;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_revision_assets_insert AFTER INSERT ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_invalid_revision_assets WHERE id = NEW.id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_REFERENCE'); END;
CREATE TRIGGER music_revision_assets_update AFTER UPDATE ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_invalid_revision_assets WHERE id = NEW.id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_REFERENCE'); END;
CREATE TRIGGER music_revision_identity BEFORE UPDATE OF id, track_id, revision_no ON music_track_revisions
BEGIN SELECT RAISE(ABORT, 'MUSIC_REVISION_IDENTITY'); END;
CREATE TRIGGER music_revision_immutable BEFORE UPDATE ON music_track_revisions
WHEN OLD.state = 'sealed' BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVISION'); END;
CREATE TRIGGER music_revision_replace BEFORE INSERT ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_track_revisions WHERE state = 'sealed'
  AND (id = NEW.id OR (track_id = NEW.track_id AND revision_no = NEW.revision_no)))
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVISION'); END;
CREATE TRIGGER music_revision_retained BEFORE DELETE ON music_track_revisions
WHEN OLD.state = 'sealed' BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVISION'); END;
CREATE TRIGGER music_rights_delete BEFORE DELETE ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_track_revisions WHERE id = OLD.revision_id AND state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_rights_insert BEFORE INSERT ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.revision_id AND state = 'sealed') OR
  EXISTS (SELECT 1 FROM music_rights_reviews rr JOIN music_track_revisions r ON r.id = rr.revision_id
    WHERE rr.id = NEW.id AND r.state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_rights_update BEFORE UPDATE ON music_rights_reviews
WHEN NEW.revision_id <> OLD.revision_id OR EXISTS (SELECT 1 FROM music_track_revisions WHERE id = OLD.revision_id AND state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_share_rate_source_identity BEFORE UPDATE ON music_share_rate_sources
WHEN NEW.category<>OLD.category OR NEW.window_start<>OLD.window_start OR NEW.source_hash<>OLD.source_hash OR NEW.hits<>OLD.hits+1
BEGIN SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID'); END;
CREATE TRIGGER music_share_rate_source_insert AFTER INSERT ON music_share_rate_sources
BEGIN
  INSERT INTO music_share_rate_windows(category,window_start,hits) VALUES(NEW.category,NEW.window_start,1)
  ON CONFLICT(category,window_start) DO UPDATE SET hits=hits+1;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_share_rate_source_update AFTER UPDATE ON music_share_rate_sources
BEGIN
  UPDATE music_share_rate_windows SET hits=hits+1 WHERE category=NEW.category AND window_start=NEW.window_start;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_track_archive BEFORE UPDATE OF lifecycle ON music_tracks
WHEN OLD.lifecycle = 'published' AND NEW.lifecycle = 'archived'
BEGIN SELECT RAISE(ABORT, 'MUSIC_UNPUBLISH_FIRST'); END;
CREATE TRIGGER music_track_identity BEFORE UPDATE OF id ON music_tracks
BEGIN SELECT RAISE(ABORT, 'MUSIC_TRACK_IDENTITY'); END;
CREATE TRIGGER music_track_pointers_insert AFTER INSERT ON music_tracks
WHEN (NEW.published_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.published_revision_id AND state = 'sealed'))
  OR (NEW.draft_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.draft_revision_id AND state = 'draft'))
BEGIN SELECT RAISE(ABORT, 'MUSIC_REVISION_POINTER'); END;
CREATE TRIGGER music_track_pointers_update AFTER UPDATE ON music_tracks
WHEN (NEW.published_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.published_revision_id AND state = 'sealed'))
  OR (NEW.draft_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.draft_revision_id AND state = 'draft'))
BEGIN SELECT RAISE(ABORT, 'MUSIC_REVISION_POINTER'); END;
CREATE TRIGGER music_track_replace BEFORE INSERT ON music_tracks
WHEN EXISTS (SELECT 1 FROM music_tracks WHERE id = NEW.id OR slug = NEW.slug)
BEGIN SELECT RAISE(ABORT, 'MUSIC_TRACK_IDENTITY'); END;
CREATE TRIGGER music_track_slug BEFORE UPDATE OF slug, first_published_at ON music_tracks
WHEN OLD.first_published_at IS NOT NULL AND (NEW.slug <> OLD.slug OR NEW.first_published_at IS NOT OLD.first_published_at)
BEGIN SELECT RAISE(ABORT, 'MUSIC_PUBLISHED_IDENTITY'); END;
CREATE TRIGGER music_upload_identity BEFORE UPDATE ON music_upload_sessions
WHEN NEW.id<>OLD.id OR NEW.asset_id<>OLD.asset_id OR NEW.actor_id<>OLD.actor_id
  OR NEW.declared_bytes<>OLD.declared_bytes OR NEW.expected_sha256 IS NOT OLD.expected_sha256
  OR NEW.created_at<>OLD.created_at OR NEW.expires_at<>OLD.expires_at
  OR (OLD.write_token IS NOT NULL AND NEW.write_token IS NOT OLD.write_token)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_upload_no_delete BEFORE DELETE ON music_upload_sessions
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_upload_no_replace BEFORE INSERT ON music_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_upload_sessions WHERE id=NEW.id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_upload_replace BEFORE INSERT ON music_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_upload_sessions WHERE status IN ('completed','rejected','expired')
  AND (id = NEW.id OR asset_id = NEW.asset_id))
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_TERMINAL'); END;
CREATE TRIGGER music_upload_terminal BEFORE UPDATE ON music_upload_sessions
WHEN OLD.status IN ('completed','rejected','expired')
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_TERMINAL'); END;
CREATE TRIGGER music_upload_transition BEFORE UPDATE OF status ON music_upload_sessions
WHEN NOT ((OLD.status='reserved' AND NEW.status IN ('uploading','expired','rejected'))
  OR (OLD.status='uploading' AND NEW.status IN ('completed','rejected','expired')))
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_STATE'); END;
CREATE VIEW music_analytics_public_variants AS
SELECT t.id AS track_id,r.revision_no,'full' AS variant,a.duration_ms,t.published_at
FROM music_tracks t JOIN music_track_revisions r ON r.id=t.published_revision_id AND r.track_id=t.id
JOIN music_assets a ON a.id=r.audio_asset_id AND a.owner_track_id=t.id
WHERE t.lifecycle='published' AND r.state='sealed' AND a.state='validated' AND a.kind='audio' AND a.duration_ms>0
UNION ALL
SELECT t.id,r.revision_no,'preview',a.duration_ms,t.published_at
FROM music_tracks t JOIN music_track_revisions r ON r.id=t.published_revision_id AND r.track_id=t.id
JOIN music_assets a ON a.id=r.preview_asset_id AND a.owner_track_id=t.id
WHERE t.lifecycle='published' AND r.state='sealed' AND a.state='validated' AND a.kind='preview' AND a.duration_ms>0;
CREATE VIEW music_asset_references AS
SELECT a.id,
  EXISTS (SELECT 1 FROM music_track_revisions r WHERE a.id IN
    (r.audio_asset_id,r.preview_asset_id,r.cover_asset_id,r.lyrics_asset_id)) AS revision_ref,
  EXISTS (SELECT 1 FROM music_rights_evidence e WHERE e.asset_id=a.id) AS evidence_ref,
  EXISTS (SELECT 1 FROM music_rights_reviews r,json_tree(r.review_json) j WHERE j.atom=a.id) AS rights_ref,
  EXISTS (SELECT 1 FROM music_assets d WHERE d.derived_from_asset_id=a.id
    AND NOT EXISTS (SELECT 1 FROM music_upload_cleanup c WHERE c.asset_id=d.id)) AS derived_ref,
  EXISTS (SELECT 1 FROM music_admin_audit_logs l WHERE l.action NOT IN
    ('music.upload.reserve','music.upload.start','music.upload.reject','music.upload.complete',
     'music.cleanup.claim','music.cleanup.prove','music.cleanup.release')
    AND (l.target_id=a.id OR EXISTS (SELECT 1 FROM json_tree(l.summary_json) j WHERE j.atom=a.id))) AS audit_ref
FROM music_assets a;
CREATE VIEW music_invalid_revision_assets AS
SELECT r.id FROM music_track_revisions r WHERE EXISTS (
  SELECT 1 FROM music_assets a WHERE
    (a.id = r.audio_asset_id AND a.kind <> 'audio') OR
    (a.id = r.cover_asset_id AND a.kind <> 'cover') OR
    (a.id = r.lyrics_asset_id AND a.kind <> 'lyrics') OR
    (a.id = r.preview_asset_id AND (a.kind <> 'preview' OR a.derived_from_asset_id IS NOT r.audio_asset_id)) OR
    (r.state = 'sealed' AND a.id IN (r.audio_asset_id, r.preview_asset_id, r.cover_asset_id, r.lyrics_asset_id) AND a.state <> 'validated')
);
CREATE VIEW music_storage_charges AS
SELECT u.asset_id,u.declared_bytes AS charged_bytes FROM music_upload_sessions u
WHERE NOT EXISTS(SELECT 1 FROM music_upload_cleanup c WHERE c.upload_id=u.id AND c.released_at IS NOT NULL)
UNION ALL SELECT a.id,a.byte_size FROM music_assets a WHERE NOT EXISTS(SELECT 1 FROM music_upload_sessions u WHERE u.asset_id=a.id)
UNION ALL SELECT u.asset_id,u.declared_bytes FROM music_collection_upload_sessions u
UNION ALL SELECT a.id,a.byte_size FROM music_collection_assets a WHERE NOT EXISTS(SELECT 1 FROM music_collection_upload_sessions u WHERE u.asset_id=a.id);
