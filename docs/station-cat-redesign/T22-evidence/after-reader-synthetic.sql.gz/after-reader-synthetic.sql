PRAGMA defer_foreign_keys=ON;;
CREATE TABLE admin_audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_email TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL,
  target_type TEXT NOT NULL DEFAULT '',
  target_id TEXT NOT NULL DEFAULT '',
  target_slug TEXT NOT NULL DEFAULT '',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE admin_content_settings (
  setting_key TEXT PRIMARY KEY,
  setting_json TEXT NOT NULL DEFAULT '{}',
  updated_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE content_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_type TEXT NOT NULL,
  locale TEXT NOT NULL DEFAULT 'zh-Hant',
  slug TEXT NOT NULL,
  parent_slug TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  excerpt TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft',
  visibility TEXT NOT NULL DEFAULT 'public',
  access_level TEXT NOT NULL DEFAULT 'free',
  author_name TEXT NOT NULL DEFAULT 'Station Cat',
  featured INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  chapter_number INTEGER,
  volume_title TEXT NOT NULL DEFAULT '',
  tags_json TEXT NOT NULL DEFAULT '[]',
  seo_json TEXT NOT NULL DEFAULT '{}',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  pricing_json TEXT NOT NULL DEFAULT '{}',
  body_format TEXT NOT NULL DEFAULT 'markdown',
  markdown_r2_key TEXT NOT NULL DEFAULT '',
  html_r2_key TEXT NOT NULL DEFAULT '',
  import_r2_key TEXT NOT NULL DEFAULT '',
  cover_r2_key TEXT NOT NULL DEFAULT '',
  cover_alt TEXT NOT NULL DEFAULT '',
  word_count INTEGER NOT NULL DEFAULT 0,
  reading_minutes INTEGER NOT NULL DEFAULT 0,
  source_kind TEXT NOT NULL DEFAULT 'backend',
  source_ref TEXT NOT NULL DEFAULT '',
  scheduled_at TEXT,
  published_at TEXT,
  archived_at TEXT,
  created_by TEXT NOT NULL DEFAULT '',
  updated_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (entry_type, locale, parent_slug, slug)
);
CREATE TABLE content_imports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  import_type TEXT NOT NULL,
  filename TEXT NOT NULL DEFAULT '',
  r2_key TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'received',
  entries_created INTEGER NOT NULL DEFAULT 0,
  entries_updated INTEGER NOT NULL DEFAULT 0,
  warnings_json TEXT NOT NULL DEFAULT '[]',
  errors_json TEXT NOT NULL DEFAULT '[]',
  created_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE content_pricing_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_id INTEGER,
  scope_type TEXT NOT NULL DEFAULT 'entry',
  entry_type TEXT NOT NULL DEFAULT '',
  series_slug TEXT NOT NULL DEFAULT '',
  chapter_slug TEXT NOT NULL DEFAULT '',
  rule_type TEXT NOT NULL,
  label TEXT NOT NULL DEFAULT '',
  amount TEXT NOT NULL DEFAULT '',
  currency TEXT NOT NULL DEFAULT 'USD',
  credits INTEGER NOT NULL DEFAULT 0,
  discount_percent INTEGER NOT NULL DEFAULT 0,
  minimum_chapters INTEGER NOT NULL DEFAULT 0,
  is_enabled INTEGER NOT NULL DEFAULT 1,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (entry_id) REFERENCES content_entries(id) ON DELETE CASCADE
);
CREATE TABLE content_revisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_id INTEGER NOT NULL,
  revision_number INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  title TEXT NOT NULL DEFAULT '',
  summary TEXT NOT NULL DEFAULT '',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  pricing_json TEXT NOT NULL DEFAULT '{}',
  markdown_r2_key TEXT NOT NULL DEFAULT '',
  html_r2_key TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (entry_id) REFERENCES content_entries(id) ON DELETE CASCADE,
  UNIQUE (entry_id, revision_number)
);
CREATE TABLE download_rate_limits (
  download_key TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  day_key TEXT NOT NULL,
  window_key INTEGER NOT NULL,
  daily_count INTEGER NOT NULL DEFAULT 0,
  window_count INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (download_key, ip_hash, day_key)
);
CREATE TABLE game_commerce_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  purchase_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  event_key TEXT NOT NULL,
  product_id TEXT NOT NULL,
  entitlement_key TEXT NOT NULL,
  points_delta INTEGER NOT NULL DEFAULT 0,
  metadata_json TEXT NOT NULL DEFAULT '{}'
    CHECK (json_valid(metadata_json)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE RESTRICT,
  FOREIGN KEY (purchase_id) REFERENCES game_purchases(id) ON DELETE RESTRICT,
  UNIQUE (event_key),
  UNIQUE (purchase_id, event_type)
);
CREATE TABLE game_commerce_rate_limits (
  account_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  window_started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  request_count INTEGER NOT NULL DEFAULT 0 CHECK (request_count >= 0),
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (account_id, action)
);
CREATE TABLE game_entitlement_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  entitlement_id INTEGER NOT NULL,
  event_type TEXT NOT NULL
    CHECK (event_type IN ('entitlement.granted', 'entitlement.revoked')),
  event_key TEXT NOT NULL UNIQUE,
  product_id TEXT NOT NULL,
  entitlement_key TEXT NOT NULL,
  actor_email TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
    CHECK (json_valid(metadata_json)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE RESTRICT,
  FOREIGN KEY (entitlement_id) REFERENCES game_entitlements(id) ON DELETE RESTRICT,
  FOREIGN KEY (product_id) REFERENCES game_products(product_id) ON DELETE RESTRICT
);
CREATE TABLE "game_entitlements" (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  game_key TEXT NOT NULL,
  entitlement_key TEXT NOT NULL,
  product_id TEXT NOT NULL,
  purchase_id TEXT,
  grant_source TEXT NOT NULL DEFAULT 'station-points',
  source_ref TEXT NOT NULL,
  grant_reason TEXT NOT NULL DEFAULT '',
  granted_by TEXT NOT NULL DEFAULT '',
  metadata_json TEXT NOT NULL DEFAULT '{}'
    CHECK (json_valid(metadata_json)),
  granted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT,
  revoked_at TEXT,
  revoke_reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (purchase_id IS NOT NULL OR grant_source = 'admin'),
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE RESTRICT,
  FOREIGN KEY (product_id) REFERENCES game_products(product_id) ON DELETE RESTRICT,
  FOREIGN KEY (purchase_id) REFERENCES game_purchases(id) ON DELETE RESTRICT
);
CREATE TABLE game_products (
  product_id TEXT PRIMARY KEY NOT NULL,
  game_key TEXT NOT NULL,
  product_type TEXT NOT NULL,
  points_price INTEGER NOT NULL CHECK (points_price > 0),
  lifecycle_status TEXT NOT NULL DEFAULT 'planned'
    CHECK (lifecycle_status IN ('planned', 'active', 'paused', 'retired')),
  entitlement_key TEXT NOT NULL UNIQUE,
  catalog_revision INTEGER NOT NULL DEFAULT 1 CHECK (catalog_revision > 0),
  names_json TEXT NOT NULL DEFAULT '{}'
    CHECK (json_valid(names_json)),
  metadata_json TEXT NOT NULL DEFAULT '{}'
    CHECK (json_valid(metadata_json)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE game_purchases (
  id TEXT PRIMARY KEY NOT NULL,
  account_id INTEGER NOT NULL,
  game_key TEXT NOT NULL,
  product_id TEXT NOT NULL,
  product_type TEXT NOT NULL,
  entitlement_key TEXT NOT NULL,
  points_spent INTEGER NOT NULL CHECK (points_spent > 0),
  balance_before INTEGER NOT NULL,
  balance_after INTEGER,
  catalog_revision INTEGER NOT NULL CHECK (catalog_revision > 0),
  product_snapshot_json TEXT NOT NULL DEFAULT '{}'
    CHECK (json_valid(product_snapshot_json)),
  idempotency_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'completed', 'reversing', 'reversed')),
  ledger_id INTEGER,
  ledger_source TEXT NOT NULL DEFAULT 'cat-life-game',
  ledger_source_ref TEXT NOT NULL,
  reversal_id TEXT NOT NULL DEFAULT '',
  reversal_reason TEXT NOT NULL DEFAULT '',
  reversal_ledger_id INTEGER,
  completed_at TEXT,
  reversed_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE RESTRICT,
  FOREIGN KEY (product_id) REFERENCES game_products(product_id) ON DELETE RESTRICT,
  FOREIGN KEY (ledger_id) REFERENCES reader_credit_ledger(id) ON DELETE RESTRICT,
  FOREIGN KEY (reversal_ledger_id) REFERENCES reader_credit_ledger(id) ON DELETE RESTRICT,
  UNIQUE (account_id, idempotency_key)
);
CREATE TABLE membership_refund_review_items (
  redemption_ledger_id INTEGER PRIMARY KEY REFERENCES reader_credit_ledger(id),
  reversal_id INTEGER NOT NULL REFERENCES membership_refund_reviews(reversal_id),
  removed_seconds INTEGER NOT NULL CHECK (removed_seconds > 0)
);
CREATE TABLE membership_refund_reviews (
  reversal_id INTEGER PRIMARY KEY REFERENCES reader_credit_ledger(id),
  account_id INTEGER NOT NULL REFERENCES reader_accounts(id),
  operation_token TEXT NOT NULL UNIQUE,
  intent_hash TEXT NOT NULL,
  decision TEXT NOT NULL CHECK (decision IN ('keep', 'revoke')),
  actor_email TEXT NOT NULL,
  reason TEXT NOT NULL,
  before_json TEXT NOT NULL,
  after_expires_at TEXT,
  removed_seconds INTEGER NOT NULL CHECK (removed_seconds >= 0),
  applied INTEGER NOT NULL DEFAULT 0 CHECK (applied IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE novel_entitlements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  series_slug TEXT NOT NULL,
  chapter_slug TEXT NOT NULL DEFAULT '',
  scope TEXT NOT NULL DEFAULT 'chapter',
  access_level TEXT NOT NULL DEFAULT 'paid',
  source TEXT NOT NULL DEFAULT 'manual',
  source_ref TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  granted_by TEXT NOT NULL DEFAULT 'admin',
  granted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT,
  revoked_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  UNIQUE (account_id, series_slug, chapter_slug, scope, access_level, source)
);
CREATE TABLE novel_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_token TEXT NOT NULL UNIQUE,
  account_id INTEGER,
  provider TEXT NOT NULL DEFAULT 'nowpayments',
  provider_order_id TEXT NOT NULL DEFAULT '',
  provider_payment_id TEXT NOT NULL DEFAULT '',
  provider_invoice_id TEXT NOT NULL DEFAULT '',
  order_type TEXT NOT NULL DEFAULT 'chapter',
  series_slug TEXT NOT NULL DEFAULT '',
  chapter_slug TEXT NOT NULL DEFAULT '',
  entitlement_scope TEXT NOT NULL DEFAULT 'chapter',
  entitlement_access_level TEXT NOT NULL DEFAULT 'paid',
  price_amount TEXT NOT NULL DEFAULT '',
  price_currency TEXT NOT NULL DEFAULT 'USD',
  pay_amount TEXT NOT NULL DEFAULT '',
  pay_currency TEXT NOT NULL DEFAULT '',
  payment_url TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft',
  provider_status TEXT NOT NULL DEFAULT '',
  customer_email TEXT NOT NULL DEFAULT '',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  expires_at TEXT,
  confirmed_at TEXT,
  finished_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE SET NULL
);
CREATE TABLE novel_payment_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL DEFAULT 'nowpayments',
  order_id INTEGER,
  provider_order_id TEXT NOT NULL DEFAULT '',
  provider_payment_id TEXT NOT NULL DEFAULT '',
  event_type TEXT NOT NULL DEFAULT 'ipn',
  status TEXT NOT NULL DEFAULT '',
  signature_valid INTEGER NOT NULL DEFAULT 0,
  payload_json TEXT NOT NULL,
  received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, provider_event_id TEXT NOT NULL DEFAULT '',
  FOREIGN KEY (order_id) REFERENCES novel_orders(id) ON DELETE SET NULL
);
CREATE TABLE novel_tips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER,
  account_id INTEGER,
  provider TEXT NOT NULL DEFAULT 'nowpayments',
  provider_order_id TEXT NOT NULL DEFAULT '',
  provider_payment_id TEXT NOT NULL DEFAULT '',
  series_slug TEXT NOT NULL DEFAULT '',
  amount TEXT NOT NULL DEFAULT '',
  currency TEXT NOT NULL DEFAULT 'USD',
  message TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES novel_orders(id) ON DELETE SET NULL,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE SET NULL
);
CREATE TABLE reader_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL,
  normalized_email TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  last_login_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE reader_bookmarks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  series_slug TEXT NOT NULL,
  chapter_slug TEXT NOT NULL,
  series_title TEXT NOT NULL DEFAULT '',
  chapter_title TEXT NOT NULL DEFAULT '',
  locale TEXT NOT NULL DEFAULT 'zh-Hant',
  source_path TEXT NOT NULL DEFAULT '',
  progress_percent INTEGER NOT NULL DEFAULT 0,
  position_label TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  UNIQUE (account_id, series_slug, chapter_slug)
);
CREATE TABLE reader_credit_accounts (
  account_id INTEGER PRIMARY KEY,
  balance_credits INTEGER NOT NULL DEFAULT 0,
  lifetime_purchased_credits INTEGER NOT NULL DEFAULT 0,
  lifetime_spent_credits INTEGER NOT NULL DEFAULT 0,
  currency_label TEXT NOT NULL DEFAULT 'SC Credits',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_credit_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  entry_type TEXT NOT NULL,
  credits_delta INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  source TEXT NOT NULL DEFAULT '',
  source_ref TEXT NOT NULL DEFAULT '',
  series_slug TEXT NOT NULL DEFAULT '',
  chapter_slug TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_game_save_backups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  game_key TEXT NOT NULL,
  save_version TEXT NOT NULL DEFAULT '',
  save_json TEXT NOT NULL,
  save_hash TEXT NOT NULL,
  save_bytes INTEGER NOT NULL DEFAULT 0,
  revision INTEGER NOT NULL,
  client_updated_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, schema_version INTEGER NOT NULL DEFAULT 0 CHECK (schema_version >= 0),
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  UNIQUE (account_id, game_key, revision),
  CHECK (revision > 0),
  CHECK (save_bytes >= 0 AND save_bytes <= 750000)
);
CREATE TABLE reader_game_save_rate_limits (
  account_id INTEGER NOT NULL,
  game_key TEXT NOT NULL,
  window_started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  write_count INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (account_id, game_key),
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  CHECK (write_count >= 0)
);
CREATE TABLE reader_game_save_recovery_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  game_key TEXT NOT NULL,
  source_backup_revision INTEGER NOT NULL,
  previous_revision INTEGER NOT NULL,
  restored_revision INTEGER NOT NULL,
  restored_save_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  CHECK (source_backup_revision > 0),
  CHECK (previous_revision > 0),
  CHECK (restored_revision > previous_revision)
);
CREATE TABLE reader_game_saves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  game_key TEXT NOT NULL,
  save_version TEXT NOT NULL DEFAULT '',
  save_json TEXT NOT NULL,
  save_hash TEXT NOT NULL,
  save_bytes INTEGER NOT NULL DEFAULT 0,
  revision INTEGER NOT NULL DEFAULT 1,
  client_updated_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, schema_version INTEGER NOT NULL DEFAULT 0 CHECK (schema_version >= 0),
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  UNIQUE (account_id, game_key),
  CHECK (revision > 0),
  CHECK (save_bytes >= 0 AND save_bytes <= 750000)
);
CREATE TABLE reader_login_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  normalized_email TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  purpose TEXT NOT NULL DEFAULT 'login',
  expires_at TEXT NOT NULL,
  consumed_at TEXT,
  request_ip_hash TEXT NOT NULL DEFAULT '',
  user_agent TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_membership_redemptions (
  account_id INTEGER NOT NULL,
  request_key TEXT NOT NULL,
  operation_token TEXT NOT NULL UNIQUE,
  cost_credits INTEGER NOT NULL CHECK (cost_credits > 0),
  duration_months INTEGER NOT NULL CHECK (duration_months > 0),
  unit_label TEXT NOT NULL,
  covers_paid INTEGER NOT NULL,
  balance_before INTEGER NOT NULL,
  previous_expires_at TEXT,
  membership_json TEXT,
  ledger_id INTEGER,
  applied INTEGER NOT NULL DEFAULT 0 CHECK (applied IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (account_id, request_key),
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE,
  FOREIGN KEY (ledger_id) REFERENCES reader_credit_ledger(id)
);
CREATE TABLE reader_memberships (
  account_id INTEGER PRIMARY KEY,
  membership_level TEXT NOT NULL DEFAULT 'member',
  source TEXT NOT NULL DEFAULT '',
  source_ref TEXT NOT NULL DEFAULT '',
  started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT NOT NULL,
  last_redeemed_at TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_password_credentials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL UNIQUE,
  username TEXT NOT NULL,
  normalized_username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  password_iterations INTEGER NOT NULL DEFAULT 100000,
  password_algorithm TEXT NOT NULL DEFAULT 'PBKDF2-SHA256',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_password_change_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL,
  session_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  user_agent TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_totp_credentials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL UNIQUE,
  secret_base32 TEXT NOT NULL,
  issuer TEXT NOT NULL DEFAULT 'Station Cat',
  label TEXT NOT NULL DEFAULT '',
  verified_at TEXT,
  enabled_at TEXT,
  disabled_at TEXT,
  last_used_step INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES reader_accounts(id) ON DELETE CASCADE
);
CREATE TABLE reader_totp_reset_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL,
  scope_key TEXT NOT NULL,
  failure_count INTEGER NOT NULL DEFAULT 0,
  locked_until_epoch INTEGER NOT NULL DEFAULT 0,
  last_failed_epoch INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(scope, scope_key)
);
CREATE TABLE waitlist_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product TEXT NOT NULL,
  platform TEXT NOT NULL,
  locale TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL,
  normalized_email TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT '',
  landing_path TEXT NOT NULL DEFAULT '',
  utm_source TEXT NOT NULL DEFAULT '',
  utm_medium TEXT NOT NULL DEFAULT '',
  utm_campaign TEXT NOT NULL DEFAULT '',
  utm_content TEXT NOT NULL DEFAULT '',
  invite_status TEXT NOT NULL DEFAULT 'waitlisted',
  invite_url TEXT NOT NULL DEFAULT '',
  invite_delivered_at TEXT,
  user_agent TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (product, platform, normalized_email)
);
CREATE TABLE waitlist_settings (
  product TEXT NOT NULL,
  platform TEXT NOT NULL,
  public_link TEXT NOT NULL DEFAULT '',
  capacity INTEGER NOT NULL DEFAULT 0,
  distributed_count INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (product, platform)
);
INSERT INTO "game_products"("product_id","game_key","product_type","points_price","lifecycle_status","entitlement_key","catalog_revision","names_json","metadata_json","created_at","updated_at") VALUES('cat-life.skin.moonlit-tabby','cat-life','cat_skin',10,'planned','cat-life.cosmetic.skin.moonlit-tabby.v1',1,'{"en":"Moonlit Tabby","ja":"月夜のキジトラ","zh-Hans":"月夜虎斑皮肤","zh-Hant":"月夜虎斑皮膚"}','{"ownershipScope":"account","entitlementMode":"perpetual","transferable":false}','2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "game_products"("product_id","game_key","product_type","points_price","lifecycle_status","entitlement_key","catalog_revision","names_json","metadata_json","created_at","updated_at") VALUES('cat-life.bundle.station-room','cat-life','furniture_bundle',25,'planned','cat-life.content.furniture.station-room.v1',1,'{"en":"Station Room Set","ja":"ステーション・ルームセット","zh-Hans":"车站小屋家具套装","zh-Hant":"車站小屋家具組"}','{"ownershipScope":"account","entitlementMode":"perpetual","transferable":false}','2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "novel_entitlements"("id","account_id","series_slug","chapter_slug","scope","access_level","source","source_ref","note","granted_by","granted_at","expires_at","revoked_at","created_at","updated_at") VALUES(1,2,'t22-history','','series','all','synthetic','before-migration','','admin','2026-10-10 12:59:19',NULL,NULL,'2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "novel_orders"("id","order_token","account_id","provider","provider_order_id","provider_payment_id","provider_invoice_id","order_type","series_slug","chapter_slug","entitlement_scope","entitlement_access_level","price_amount","price_currency","pay_amount","pay_currency","payment_url","status","provider_status","customer_email","metadata_json","expires_at","confirmed_at","finished_at","created_at","updated_at") VALUES(1,'T22-BEFORE-ORDER',2,'nowpayments','','','','tip','','','chapter','paid','2.00','USD','','','','finished','','','{}',NULL,NULL,NULL,'2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "novel_orders"("id","order_token","account_id","provider","provider_order_id","provider_payment_id","provider_invoice_id","order_type","series_slug","chapter_slug","entitlement_scope","entitlement_access_level","price_amount","price_currency","pay_amount","pay_currency","payment_url","status","provider_status","customer_email","metadata_json","expires_at","confirmed_at","finished_at","created_at","updated_at") VALUES(3,'T22-AFTER-ORDER',2,'creem','','','','credit_pack','','','chapter','paid','10.00','USD','','','','finished','','','{}',NULL,NULL,NULL,'2026-10-10 12:59:26','2026-10-10 12:59:26');;
INSERT INTO "reader_accounts"("id","email","normalized_email","display_name","status","last_login_at","created_at","updated_at") VALUES(1,'t22-1@example.test','t22-1@example.test','T22 Synthetic 1','active',NULL,'2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "reader_accounts"("id","email","normalized_email","display_name","status","last_login_at","created_at","updated_at") VALUES(2,'t22-2@example.test','t22-2@example.test','T22 Synthetic 2','active',NULL,'2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "reader_credit_accounts"("account_id","balance_credits","lifetime_purchased_credits","lifetime_spent_credits","currency_label","created_at","updated_at") VALUES(1,125,0,0,'Station Points','2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "reader_credit_accounts"("account_id","balance_credits","lifetime_purchased_credits","lifetime_spent_credits","currency_label","created_at","updated_at") VALUES(2,225,100,0,'Station Points','2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "reader_credit_ledger"("id","account_id","entry_type","credits_delta","balance_after","source","source_ref","series_slug","chapter_slug","note","metadata_json","created_at") VALUES(1,2,'purchase',100,225,'creem','T22-AFTER-ORDER','','','','{}','2026-10-10 12:59:26');;
INSERT INTO "reader_game_save_backups"("id","account_id","game_key","save_version","save_json","save_hash","save_bytes","revision","client_updated_at","created_at","schema_version") VALUES(1,2,'cat-life','1.28.0','{"version":"1.28.0","schemaVersion":3,"meta":{"createdAt":"2026-10-10T12:59:19.741Z","lastSavedAt":"2026-10-10T12:59:19.741Z"},"player":{"gold":87,"energy":80},"cats":[{"id":"t22-synthetic-cat","name":"Fixture","careStatus":"sheltered","intimacy":61}],"inventory":{"food":2},"settings":{"language":"en"}}','dc6197c22f75b065966ca2bb47b65444bd5347b6f98673f1579b8e4bb3899172',304,4,'2026-10-10T12:59:18.481Z','2026-10-10 12:59:26',0);;
INSERT INTO "reader_game_save_backups"("id","account_id","game_key","save_version","save_json","save_hash","save_bytes","revision","client_updated_at","created_at","schema_version") VALUES(2,2,'cat-life','1.28.0','{"version":"1.28.0","schemaVersion":3,"meta":{"createdAt":"2026-10-10T12:59:26.126Z"},"player":{"gold":187,"energy":80},"cats":[{"id":"t22-synthetic-cat","name":"Fixture","careStatus":"sheltered","intimacy":61}],"inventory":{"food":2},"settings":{"language":"en","customMusicData":"","customMusicName":"","customMusicEnabled":false}}','65c9b2c40178347635c79d53a39c2f35f0ca22c7a170e2297d96ad423f5f5623',333,5,'2026-10-10T12:59:26.138Z','2026-10-10 12:59:28',3);;
INSERT INTO "reader_game_save_rate_limits"("account_id","game_key","window_started_at","write_count","updated_at") VALUES(2,'cat-life','2026-10-10 12:59:26',2,'2026-10-10 12:59:28');;
INSERT INTO "reader_game_saves"("id","account_id","game_key","save_version","save_json","save_hash","save_bytes","revision","client_updated_at","created_at","updated_at","schema_version") VALUES(1,2,'cat-life','1.28.0','{"version":"1.28.0","schemaVersion":3,"meta":{"createdAt":"2026-10-10T12:59:28.436Z"},"player":{"gold":287,"energy":80},"cats":[{"id":"t22-synthetic-cat","name":"Fixture","careStatus":"sheltered","intimacy":61}],"inventory":{"food":2},"settings":{"language":"en","customMusicData":"","customMusicName":"","customMusicEnabled":false}}','31ff0a8f0cfa7bee5beb2042ce1f2bb251b3e357063422a94eef3643be46fa05',333,6,'2026-10-10T12:59:28.441Z','2026-10-10 12:59:19','2026-10-10 12:59:28',3);;
INSERT INTO "reader_memberships"("account_id","membership_level","source","source_ref","started_at","expires_at","last_redeemed_at","metadata_json","created_at","updated_at") VALUES(1,'member','','','2026-10-10T12:58:18.481Z','2026-10-11T12:59:18.481Z',NULL,'{}','2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "reader_sessions"("id","account_id","session_hash","expires_at","revoked_at","user_agent","created_at","last_seen_at") VALUES(1,1,'2b05c1d96606418f32fe3e0cf4bb0b96106c35f4d1712d08887570802f626357','2026-10-11T12:59:18.481Z',NULL,'','2026-10-10 12:59:19','2026-10-10 12:59:19');;
INSERT INTO "reader_sessions"("id","account_id","session_hash","expires_at","revoked_at","user_agent","created_at","last_seen_at") VALUES(2,2,'b66d18edcbba8f005b503b9a0c79c99a2f68c998c56601ee81c6b7779fcc16f5','2026-10-11T12:59:18.481Z',NULL,'','2026-10-10 12:59:19','2026-10-10 12:59:28');;
INSERT INTO "waitlist_settings"("product","platform","public_link","capacity","distributed_count","is_active","updated_at") VALUES('snapcopy','ios','',0,0,0,'2026-10-10 12:59:18');;
INSERT INTO "waitlist_settings"("product","platform","public_link","capacity","distributed_count","is_active","updated_at") VALUES('snapcopy','android','',0,0,0,'2026-10-10 12:59:18');;
DELETE FROM sqlite_sequence;;
INSERT INTO sqlite_sequence(name,seq) VALUES('game_entitlements',0);;
INSERT INTO sqlite_sequence(name,seq) VALUES('novel_entitlements',1);;
INSERT INTO sqlite_sequence(name,seq) VALUES('novel_orders',3);;
INSERT INTO sqlite_sequence(name,seq) VALUES('reader_accounts',2);;
INSERT INTO sqlite_sequence(name,seq) VALUES('reader_credit_ledger',1);;
INSERT INTO sqlite_sequence(name,seq) VALUES('reader_game_save_backups',2);;
INSERT INTO sqlite_sequence(name,seq) VALUES('reader_game_saves',1);;
INSERT INTO sqlite_sequence(name,seq) VALUES('reader_sessions',2);;
CREATE INDEX idx_admin_audit_logs_actor
  ON admin_audit_logs (actor_email, created_at);
CREATE INDEX idx_admin_audit_logs_target
  ON admin_audit_logs (target_type, target_id, created_at);
CREATE INDEX idx_content_entries_parent
  ON content_entries (entry_type, locale, parent_slug, chapter_number, sort_order);
CREATE INDEX idx_content_entries_slug
  ON content_entries (entry_type, locale, slug);
CREATE INDEX idx_content_entries_type_status
  ON content_entries (entry_type, status, published_at);
CREATE INDEX idx_content_entries_updated
  ON content_entries (updated_at);
CREATE INDEX idx_content_imports_status
  ON content_imports (import_type, status, created_at);
CREATE INDEX idx_content_pricing_rules_entry
  ON content_pricing_rules (entry_id, is_enabled);
CREATE INDEX idx_content_pricing_rules_scope
  ON content_pricing_rules (scope_type, entry_type, series_slug, chapter_slug, is_enabled);
CREATE INDEX idx_content_revisions_entry
  ON content_revisions (entry_id, revision_number DESC);
CREATE INDEX idx_download_rate_limits_updated
  ON download_rate_limits (updated_at);
CREATE INDEX idx_game_commerce_events_account
  ON game_commerce_events (account_id, created_at DESC);
CREATE INDEX idx_game_commerce_rate_limits_updated
  ON game_commerce_rate_limits (updated_at);
CREATE INDEX idx_game_entitlement_events_account
  ON game_entitlement_events (account_id, created_at DESC);
CREATE INDEX idx_game_entitlement_events_entitlement
  ON game_entitlement_events (entitlement_id, created_at DESC);
CREATE INDEX idx_game_entitlements_account
  ON game_entitlements (account_id, game_key, granted_at DESC);
CREATE UNIQUE INDEX idx_game_entitlements_active_grant
  ON game_entitlements (account_id, game_key, entitlement_key)
  WHERE revoked_at IS NULL;
CREATE UNIQUE INDEX idx_game_entitlements_source
  ON game_entitlements (account_id, game_key, grant_source, source_ref);
CREATE INDEX idx_game_products_catalog
  ON game_products (game_key, lifecycle_status, product_type, product_id);
CREATE INDEX idx_game_purchases_account_created
  ON game_purchases (account_id, created_at DESC);
CREATE UNIQUE INDEX idx_game_purchases_completed_product
  ON game_purchases (account_id, product_id)
  WHERE status IN ('completed', 'reversing');
CREATE INDEX idx_membership_refund_reviews_account
  ON membership_refund_reviews(account_id, reversal_id);
CREATE INDEX idx_novel_entitlements_account
  ON novel_entitlements (account_id, revoked_at, expires_at);
CREATE INDEX idx_novel_entitlements_target
  ON novel_entitlements (series_slug, chapter_slug, scope, access_level);
CREATE INDEX idx_novel_entitlements_updated
  ON novel_entitlements (updated_at);
CREATE INDEX idx_novel_orders_account
  ON novel_orders (account_id, status, updated_at);
CREATE INDEX idx_novel_orders_provider_order
  ON novel_orders (provider, provider_order_id);
CREATE INDEX idx_novel_orders_provider_payment
  ON novel_orders (provider, provider_payment_id);
CREATE INDEX idx_novel_orders_target
  ON novel_orders (series_slug, chapter_slug, order_type, status);
CREATE UNIQUE INDEX idx_novel_payment_events_creem_event_unique
  ON novel_payment_events (provider, provider_event_id)
  WHERE provider = 'creem'
    AND provider_event_id <> '';
CREATE INDEX idx_novel_payment_events_order
  ON novel_payment_events (order_id, received_at);
CREATE INDEX idx_novel_payment_events_provider_payment
  ON novel_payment_events (provider, provider_payment_id, received_at);
CREATE INDEX idx_novel_tips_order
  ON novel_tips (order_id);
CREATE INDEX idx_novel_tips_provider_payment
  ON novel_tips (provider, provider_payment_id);
CREATE INDEX idx_novel_tips_series
  ON novel_tips (series_slug, status, updated_at);
CREATE INDEX idx_reader_bookmarks_account_series
  ON reader_bookmarks (account_id, series_slug, chapter_slug);
CREATE INDEX idx_reader_bookmarks_account_updated
  ON reader_bookmarks (account_id, updated_at DESC);
CREATE INDEX idx_reader_credit_ledger_account
  ON reader_credit_ledger (account_id, created_at);
CREATE UNIQUE INDEX idx_reader_credit_ledger_cat_life_game_unique
  ON reader_credit_ledger (account_id, entry_type, source, source_ref)
  WHERE source = 'cat-life-game';
CREATE UNIQUE INDEX idx_reader_credit_ledger_creem_reversal_unique
  ON reader_credit_ledger (account_id, source, source_ref)
  WHERE entry_type = 'reversal'
    AND source = 'creem-credit-pack';
CREATE UNIQUE INDEX idx_reader_credit_ledger_creem_topup_unique
  ON reader_credit_ledger (account_id, source, source_ref)
  WHERE entry_type = 'topup'
    AND source = 'creem-credit-pack';
CREATE INDEX idx_reader_credit_ledger_source
  ON reader_credit_ledger (source, source_ref);
CREATE INDEX idx_reader_game_save_backups_account_game_revision
  ON reader_game_save_backups (account_id, game_key, revision DESC);
CREATE INDEX idx_reader_game_save_recovery_events_account_game
  ON reader_game_save_recovery_events (account_id, game_key, created_at DESC);
CREATE INDEX idx_reader_game_saves_account_updated
  ON reader_game_saves (account_id, updated_at DESC);
CREATE INDEX idx_reader_login_tokens_account
  ON reader_login_tokens (account_id, consumed_at, expires_at);
CREATE INDEX idx_reader_login_tokens_email_created
  ON reader_login_tokens (normalized_email, created_at);
CREATE INDEX idx_reader_memberships_expires
  ON reader_memberships (expires_at);
CREATE INDEX idx_reader_password_credentials_account
  ON reader_password_credentials (account_id);
CREATE INDEX idx_reader_sessions_account
  ON reader_sessions (account_id, revoked_at, expires_at);
CREATE INDEX idx_reader_totp_credentials_account
  ON reader_totp_credentials (account_id, enabled_at, disabled_at);
CREATE INDEX idx_reader_totp_reset_attempts_scope
  ON reader_totp_reset_attempts (scope, scope_key, locked_until_epoch);
CREATE INDEX idx_reader_totp_reset_attempts_updated_at
  ON reader_totp_reset_attempts (updated_at);
CREATE INDEX idx_waitlist_entries_invite_status
  ON waitlist_entries (product, platform, invite_status);
CREATE INDEX idx_waitlist_entries_product_platform
  ON waitlist_entries (product, platform, created_at);
