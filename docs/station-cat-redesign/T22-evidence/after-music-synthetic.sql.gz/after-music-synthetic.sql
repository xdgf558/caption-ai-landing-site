PRAGMA defer_foreign_keys=ON;;
CREATE TABLE d1_migrations(id INTEGER PRIMARY KEY,name TEXT UNIQUE,applied_at TEXT);
CREATE TABLE music_admin_audit_logs (
  id TEXT PRIMARY KEY NOT NULL,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  target_id TEXT NOT NULL,
  summary_json TEXT NOT NULL CHECK (json_valid(summary_json) AND json_type(summary_json) = 'object'),
  request_id TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL CHECK (created_at >= 0)
) STRICT;
CREATE TABLE music_analytics_admission_guard (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  passed INTEGER NOT NULL CHECK(passed=1)
) STRICT;
CREATE TABLE music_analytics_daily (
  day_start_ms INTEGER NOT NULL CHECK(day_start_ms>=0 AND day_start_ms%86400000=0),
  metric TEXT NOT NULL CHECK(metric IN ('play_start','qualified_play','play_complete','preview_end','vip_cta_click','membership_center_open','vip_grant_confirmed','vip_grant_reversed')),
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  variant TEXT NOT NULL CHECK(variant IN ('full','preview')),
  access_kind TEXT NOT NULL CHECK(access_kind IN ('free','vip','unknown')),
  value INTEGER NOT NULL CHECK(value>=0),
  PRIMARY KEY(day_start_ms,metric,track_id,variant,access_kind)
) STRICT;
CREATE TABLE music_analytics_events (
  event_id TEXT PRIMARY KEY NOT NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('play_start','qualified_play','play_complete','preview_end','vip_cta_click','membership_center_open','vip_grant_confirmed','vip_grant_reversed')),
  play_session_id TEXT,
  anonymous_session_id TEXT NOT NULL,
  track_id TEXT NOT NULL,
  revision_no INTEGER NOT NULL,
  variant TEXT NOT NULL CHECK (variant IN ('full','preview')),
  occurred_at INTEGER NOT NULL CHECK (occurred_at >= 0),
  received_at INTEGER NOT NULL CHECK (received_at >= 0),
  listened_ms INTEGER NOT NULL DEFAULT 0 CHECK (listened_ms >= 0),
  entry_source TEXT NOT NULL CHECK (entry_source IN ('catalog','collection','detail','player','membership')), consent_version TEXT,
  FOREIGN KEY (track_id, revision_no) REFERENCES music_track_revisions(track_id, revision_no)
) STRICT;
CREATE TABLE music_analytics_health (
  id INTEGER PRIMARY KEY CHECK(id=1),
  last_sweep_at INTEGER NOT NULL CHECK(last_sweep_at>=0)
) STRICT;
CREATE TABLE music_analytics_rates (
  scope TEXT NOT NULL CHECK(scope IN ('session','source','global')),
  window_start INTEGER NOT NULL CHECK(window_start>=0 AND window_start%60000=0),
  subject TEXT NOT NULL CHECK(length(subject)=64),
  hits INTEGER NOT NULL CHECK(hits>0),
  PRIMARY KEY(scope,window_start,subject)
) STRICT;
CREATE TABLE music_assets (
  id TEXT PRIMARY KEY NOT NULL,
  owner_track_id TEXT NOT NULL REFERENCES music_tracks(id),
  kind TEXT NOT NULL CHECK (kind IN ('audio','preview','cover','lyrics','evidence')),
  object_key TEXT NOT NULL UNIQUE CHECK (length(object_key) BETWEEN 1 AND 512),
  state TEXT NOT NULL DEFAULT 'reserved' CHECK (state IN ('reserved','uploading','uploaded','validated','rejected')),
  content_type TEXT NOT NULL,
  format TEXT NOT NULL CHECK (format IN ('mp3','jpeg','png','webp','txt','lrc','pdf')),
  byte_size INTEGER CHECK (byte_size > 0),
  duration_ms INTEGER CHECK (duration_ms > 0),
  derived_from_asset_id TEXT,
  source_start_ms INTEGER,
  source_end_ms INTEGER,
  sha256 TEXT CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
  etag TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  UNIQUE (owner_track_id, id),
  FOREIGN KEY (owner_track_id, derived_from_asset_id) REFERENCES music_assets(owner_track_id, id),
  CHECK (derived_from_asset_id IS NULL OR derived_from_asset_id <> id),
  CHECK (kind = 'preview' OR (derived_from_asset_id IS NULL AND source_start_ms IS NULL AND source_end_ms IS NULL)),
  CHECK (state NOT IN ('uploaded','validated') OR (byte_size IS NOT NULL AND sha256 IS NOT NULL)),
  CHECK (kind NOT IN ('audio','preview') OR state <> 'validated' OR duration_ms IS NOT NULL),
  CHECK (kind <> 'preview' OR state <> 'validated' OR
    (derived_from_asset_id IS NOT NULL AND source_start_ms IS NOT NULL AND source_end_ms IS NOT NULL AND source_start_ms >= 0 AND source_end_ms > source_start_ms)),
  CHECK ((kind IN ('audio','preview') AND format = 'mp3' AND content_type = 'audio/mpeg') OR
    (kind = 'cover' AND ((format = 'jpeg' AND content_type = 'image/jpeg') OR (format = 'png' AND content_type = 'image/png') OR (format = 'webp' AND content_type = 'image/webp'))) OR
    (kind = 'lyrics' AND format IN ('txt','lrc') AND content_type = 'text/plain') OR
    (kind = 'evidence' AND ((format = 'pdf' AND content_type = 'application/pdf') OR (format = 'jpeg' AND content_type = 'image/jpeg') OR (format = 'png' AND content_type = 'image/png')))),
  CHECK (byte_size IS NULL OR byte_size <= CASE kind WHEN 'audio' THEN 33554432 WHEN 'preview' THEN 4194304 WHEN 'cover' THEN 5242880 WHEN 'lyrics' THEN 131072 WHEN 'evidence' THEN 10485760 END)
) STRICT;
CREATE TABLE music_collection_assets (
  id TEXT PRIMARY KEY NOT NULL,
  owner_collection_id TEXT NOT NULL REFERENCES music_collections(id),
  kind TEXT NOT NULL CHECK (kind = 'cover'),
  object_key TEXT NOT NULL UNIQUE CHECK (length(object_key) BETWEEN 1 AND 512),
  state TEXT NOT NULL DEFAULT 'reserved' CHECK (state IN ('reserved','uploading','uploaded','validated','rejected')),
  content_type TEXT NOT NULL,
  format TEXT NOT NULL CHECK (format IN ('jpeg','png','webp')),
  byte_size INTEGER CHECK (byte_size > 0 AND byte_size <= 5242880),
  sha256 TEXT CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
  etag TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  CHECK (state NOT IN ('uploaded','validated') OR (byte_size IS NOT NULL AND sha256 IS NOT NULL AND etag IS NOT NULL)),
  CHECK ((format = 'jpeg' AND content_type = 'image/jpeg') OR
    (format = 'png' AND content_type = 'image/png') OR
    (format = 'webp' AND content_type = 'image/webp'))
) STRICT;
CREATE TABLE music_collection_tracks (
  collection_id TEXT NOT NULL REFERENCES music_collections(id),
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  position INTEGER NOT NULL CHECK (position >= 0),
  PRIMARY KEY (collection_id, track_id),
  UNIQUE (collection_id, position)
) STRICT;
CREATE TABLE music_collection_upload_sessions (
  id TEXT PRIMARY KEY NOT NULL,
  asset_id TEXT NOT NULL UNIQUE REFERENCES music_collection_assets(id),
  actor_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','uploading','completed','rejected','expired')),
  declared_bytes INTEGER NOT NULL CHECK (declared_bytes > 0 AND declared_bytes <= 5242880),
  actual_bytes INTEGER CHECK (actual_bytes >= 0 AND actual_bytes <= declared_bytes),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), expected_sha256 TEXT
  CHECK (expected_sha256 IS NULL OR (length(expected_sha256)=64 AND expected_sha256 NOT GLOB '*[^0-9a-f]*')), write_token TEXT,
  CHECK (status <> 'completed' OR actual_bytes = declared_bytes AND actual_bytes IS NOT NULL)
) STRICT;
CREATE TABLE music_collections (
  id TEXT PRIMARY KEY NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  original_locale TEXT NOT NULL CHECK (original_locale IN ('zh-Hant','zh-Hans','en','ja')),
  title_json TEXT NOT NULL CHECK (json_valid(title_json) AND json_type(title_json) = 'object'),
  description_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(description_json) AND json_type(description_json) = 'object'),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at)
, collection_type TEXT NOT NULL DEFAULT 'playlist'
  CHECK (collection_type IN ('playlist','album')), listening_mode TEXT NOT NULL DEFAULT 'mixed'
  CHECK (listening_mode IN ('mixed','free','vip') AND (collection_type='album' OR listening_mode='mixed')), cover_track_id TEXT REFERENCES music_tracks(id)
  CHECK (collection_type='album' OR cover_track_id IS NULL), cover_asset_id TEXT REFERENCES music_collection_assets(id)) STRICT;
CREATE TABLE music_featured_home (
  id INTEGER PRIMARY KEY NOT NULL CHECK (id = 1),
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= 0)
) STRICT;
CREATE TABLE music_featured_items (
  slot_kind TEXT NOT NULL CHECK (slot_kind IN ('primary','secondary','collection')),
  position INTEGER NOT NULL CHECK (position >= 0 AND
    ((slot_kind = 'primary' AND position = 0) OR (slot_kind IN ('secondary','collection') AND position < 6))),
  track_id TEXT REFERENCES music_tracks(id),
  collection_id TEXT REFERENCES music_collections(id),
  PRIMARY KEY (slot_kind, position),
  UNIQUE (track_id),
  UNIQUE (collection_id),
  CHECK ((slot_kind IN ('primary','secondary') AND track_id IS NOT NULL AND collection_id IS NULL) OR
    (slot_kind = 'collection' AND collection_id IS NOT NULL AND track_id IS NULL))
) STRICT;
CREATE TABLE music_membership_attributions (
  verified_grant_ref TEXT PRIMARY KEY NOT NULL,
  anonymous_session_id TEXT NOT NULL,
  entry_track_id TEXT NOT NULL REFERENCES music_tracks(id),
  observed_at INTEGER NOT NULL CHECK (observed_at >= 0),
  qualification TEXT NOT NULL CHECK (qualification IN ('verified_new','unavailable')),
  reversed_at INTEGER CHECK (reversed_at >= observed_at)
) STRICT;
CREATE TABLE music_mutations (
  actor_id TEXT NOT NULL,
  route TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  request_hash TEXT NOT NULL CHECK (length(request_hash) = 64),
  result_json TEXT NOT NULL CHECK (json_valid(result_json) AND json_type(result_json) = 'object'),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (actor_id, route, idempotency_key)
) STRICT;
CREATE TABLE music_publication_guards (
  operation_token TEXT PRIMARY KEY NOT NULL,
  passed INTEGER NOT NULL CHECK (passed = 1)
) STRICT;
CREATE TABLE music_rate_sources (
  category TEXT NOT NULL CHECK (category IN ('catalog','artwork','audio')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  source_hash TEXT NOT NULL CHECK (length(source_hash)=64 AND source_hash NOT GLOB '*[^0-9a-f]*'),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start,source_hash)
) STRICT;
CREATE TABLE music_rate_windows (
  category TEXT NOT NULL CHECK (category IN ('catalog','artwork','audio')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start)
) STRICT;
CREATE TABLE music_rights_evidence (
  review_id TEXT NOT NULL REFERENCES music_rights_reviews(id),
  asset_id TEXT NOT NULL REFERENCES music_assets(id),
  PRIMARY KEY (review_id, asset_id)
) STRICT;
CREATE TABLE music_rights_reviews (
  id TEXT PRIMARY KEY NOT NULL,
  revision_id TEXT NOT NULL UNIQUE REFERENCES music_track_revisions(id),
  review_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(review_json) AND json_type(review_json) = 'object'),
  review_status TEXT NOT NULL DEFAULT 'pending' CHECK (review_status IN ('pending','approved','blocked')),
  reviewer_id TEXT,
  reviewed_at INTEGER CHECK (reviewed_at >= 0), revision_fingerprint TEXT
  CHECK (revision_fingerprint IS NULL OR (length(revision_fingerprint) = 64 AND revision_fingerprint NOT GLOB '*[^0-9a-f]*')),
  CHECK (review_status = 'pending' OR (reviewer_id IS NOT NULL AND length(reviewer_id) > 0 AND reviewed_at IS NOT NULL))
) STRICT;
CREATE TABLE music_settings (
  key TEXT PRIMARY KEY NOT NULL,
  value_json TEXT NOT NULL CHECK (json_valid(value_json)),
  updated_at INTEGER NOT NULL CHECK (updated_at >= 0)
) STRICT;
CREATE TABLE music_share_rate_sources (
  category TEXT NOT NULL CHECK (category IN ('share')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  source_hash TEXT NOT NULL CHECK (length(source_hash)=64 AND source_hash NOT GLOB '*[^0-9a-f]*'),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start,source_hash)
) STRICT;
CREATE TABLE music_share_rate_windows (
  category TEXT NOT NULL CHECK (category IN ('share')),
  window_start INTEGER NOT NULL CHECK (window_start>=0 AND window_start%60000=0),
  hits INTEGER NOT NULL CHECK (hits BETWEEN 1 AND 1000000),
  PRIMARY KEY (category,window_start)
) STRICT;
CREATE TABLE music_track_revisions (
  id TEXT PRIMARY KEY NOT NULL,
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  revision_no INTEGER NOT NULL CHECK (revision_no > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json) AND json_type(metadata_json) = 'object'),
  audio_asset_id TEXT,
  preview_asset_id TEXT,
  cover_asset_id TEXT,
  lyrics_asset_id TEXT,
  access_mode TEXT NOT NULL DEFAULT 'vip' CHECK (access_mode IN ('free','vip','early_access')),
  early_access_until INTEGER CHECK (early_access_until >= 0),
  post_early_access_mode TEXT CHECK (post_early_access_mode IN ('free','vip')),
  policy_version INTEGER NOT NULL DEFAULT 1 CHECK (policy_version > 0),
  technical_reviewed_at INTEGER CHECK (technical_reviewed_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), technical_fingerprint TEXT
  CHECK (technical_fingerprint IS NULL OR (length(technical_fingerprint) = 64 AND technical_fingerprint NOT GLOB '*[^0-9a-f]*')), free_until INTEGER
  CHECK (free_until IS NULL OR (free_until>=0 AND access_mode='vip')),
  UNIQUE (track_id, id),
  UNIQUE (track_id, revision_no),
  FOREIGN KEY (track_id, audio_asset_id) REFERENCES music_assets(owner_track_id, id),
  FOREIGN KEY (track_id, preview_asset_id) REFERENCES music_assets(owner_track_id, id),
  FOREIGN KEY (track_id, cover_asset_id) REFERENCES music_assets(owner_track_id, id),
  FOREIGN KEY (track_id, lyrics_asset_id) REFERENCES music_assets(owner_track_id, id),
  CHECK ((access_mode = 'early_access' AND early_access_until IS NOT NULL AND post_early_access_mode IS NOT NULL) OR
    (access_mode IN ('free','vip') AND early_access_until IS NULL AND post_early_access_mode IS NULL)),
  CHECK (state <> 'sealed' OR (audio_asset_id IS NOT NULL AND technical_reviewed_at IS NOT NULL))
) STRICT;
CREATE TABLE music_tracks (
  id TEXT PRIMARY KEY NOT NULL,
  slug TEXT NOT NULL UNIQUE CHECK (length(slug) BETWEEN 1 AND 100),
  lifecycle TEXT NOT NULL DEFAULT 'draft' CHECK (lifecycle IN ('draft','published','unpublished','archived')),
  draft_revision_id TEXT,
  published_revision_id TEXT,
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  first_published_at INTEGER CHECK (first_published_at >= 0),
  published_at INTEGER CHECK (published_at >= first_published_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  UNIQUE (id, slug),
  FOREIGN KEY (id, draft_revision_id) REFERENCES music_track_revisions(track_id, id),
  FOREIGN KEY (id, published_revision_id) REFERENCES music_track_revisions(track_id, id),
  CHECK (lifecycle <> 'published' OR (published_revision_id IS NOT NULL AND first_published_at IS NOT NULL AND published_at IS NOT NULL)),
  CHECK (lifecycle NOT IN ('draft','archived') OR published_revision_id IS NULL)
) STRICT;
CREATE TABLE music_upload_cleanup (
  upload_id TEXT PRIMARY KEY NOT NULL REFERENCES music_upload_sessions(id),
  asset_id TEXT NOT NULL UNIQUE REFERENCES music_assets(id),
  actor_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  plan_hash TEXT NOT NULL CHECK (length(plan_hash)=64),
  claimed_at INTEGER NOT NULL CHECK (claimed_at>=0),
  proof_json TEXT CHECK (proof_json IS NULL OR
    (json_valid(proof_json) AND json_type(proof_json)='object' AND
      COALESCE(json_extract(proof_json,'$.kind') IN ('never_started','object_observed'),0))),
  proved_at INTEGER CHECK (proved_at>=claimed_at),
  released_at INTEGER CHECK (released_at>=proved_at),
  CHECK ((proof_json IS NULL)=(proved_at IS NULL)),
  CHECK (released_at IS NULL OR proved_at IS NOT NULL)
) STRICT;
CREATE TABLE music_upload_sessions (
  id TEXT PRIMARY KEY NOT NULL,
  asset_id TEXT NOT NULL UNIQUE REFERENCES music_assets(id),
  actor_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','uploading','completed','rejected','expired')),
  declared_bytes INTEGER NOT NULL CHECK (declared_bytes > 0 AND declared_bytes <= 33554432),
  actual_bytes INTEGER CHECK (actual_bytes >= 0 AND actual_bytes <= declared_bytes),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), expected_sha256 TEXT
  CHECK (expected_sha256 IS NULL OR (length(expected_sha256)=64 AND expected_sha256 NOT GLOB '*[^0-9a-f]*')), write_token TEXT,
  CHECK (status <> 'completed' OR actual_bytes = declared_bytes AND actual_bytes IS NOT NULL)
) STRICT;
CREATE TABLE station_analytics_events (
  event_id TEXT PRIMARY KEY NOT NULL,
  event_name TEXT NOT NULL CHECK (event_name IN ('track_view','preview_start','full_audio_start','preview_qualified','platform_click','clip_start','clip_complete','game_launch_request','game_ready','save_success')),
  occurred_at INTEGER NOT NULL CHECK (occurred_at >= 0),
  received_at INTEGER NOT NULL CHECK (received_at >= 0),
  track_id TEXT REFERENCES music_tracks(id),
  clip_id TEXT,
  game_id TEXT REFERENCES station_games(id),
  campaign_id TEXT REFERENCES station_campaigns(id),
  platform_link_id TEXT,
  session_id TEXT NOT NULL CHECK (length(session_id) BETWEEN 1 AND 128),
  playback_id TEXT CHECK (length(playback_id) BETWEEN 1 AND 128),
  interaction_id TEXT CHECK (length(interaction_id) BETWEEN 1 AND 128),
  launch_id TEXT CHECK (length(launch_id) BETWEEN 1 AND 128),
  save_operation_id TEXT CHECK (length(save_operation_id) BETWEEN 1 AND 128), context_id TEXT, session_scope TEXT CHECK(session_scope IN ('session_storage','memory')), attribution_kind TEXT CHECK(attribution_kind IN ('campaign','direct_or_unknown','unknown')), campaign_source TEXT, campaign_medium TEXT, first_campaign_id TEXT, device_class TEXT CHECK(device_class IN ('mobile','desktop','unknown')), listened_ms INTEGER NOT NULL DEFAULT 0 CHECK(listened_ms BETWEEN 0 AND 86400000), media_ended INTEGER NOT NULL DEFAULT 0 CHECK(media_ended IN (0,1)), time_anomaly INTEGER NOT NULL DEFAULT 0 CHECK(time_anomaly IN (0,1)), consent_version TEXT, expires_at INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (track_id,clip_id) REFERENCES station_clips(track_id,id),
  FOREIGN KEY (track_id,platform_link_id) REFERENCES station_platform_links(track_id,id),
  CHECK (clip_id IS NULL OR track_id IS NOT NULL),
  CHECK (platform_link_id IS NULL OR track_id IS NOT NULL),
  CHECK (event_name NOT IN ('track_view','preview_start','full_audio_start','preview_qualified','platform_click','clip_start','clip_complete') OR track_id IS NOT NULL),
  CHECK (event_name NOT IN ('preview_start','full_audio_start','preview_qualified','clip_start','clip_complete') OR playback_id IS NOT NULL),
  CHECK (event_name NOT IN ('clip_start','clip_complete') OR clip_id IS NOT NULL),
  CHECK (event_name<>'platform_click' OR (platform_link_id IS NOT NULL AND interaction_id IS NOT NULL)),
  CHECK (event_name NOT IN ('game_launch_request','game_ready','save_success') OR game_id IS NOT NULL),
  CHECK (event_name NOT IN ('game_launch_request','game_ready') OR launch_id IS NOT NULL),
  CHECK (event_name<>'save_success' OR save_operation_id IS NOT NULL)
) STRICT;
CREATE TABLE station_asset_rights (
  id TEXT PRIMARY KEY NOT NULL,
  music_asset_id TEXT REFERENCES music_assets(id),
  media_asset_id TEXT REFERENCES station_media_assets(id),
  scope TEXT NOT NULL CHECK (scope IN ('cover','preview','lyrics','short_video','mv','poster','game_screenshot')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','blocked')),
  basis TEXT,
  reviewer_id TEXT,
  reviewed_at INTEGER CHECK (reviewed_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0), edit_version INTEGER NOT NULL DEFAULT 1 CHECK(edit_version>0),
  UNIQUE (music_asset_id,scope),
  UNIQUE (media_asset_id,scope),
  CHECK ((music_asset_id IS NOT NULL AND media_asset_id IS NULL) OR (music_asset_id IS NULL AND media_asset_id IS NOT NULL)),
  CHECK (status='pending' OR (basis IS NOT NULL AND length(trim(basis))>0 AND reviewer_id IS NOT NULL AND length(trim(reviewer_id))>0 AND reviewed_at IS NOT NULL))
) STRICT;
CREATE TABLE station_campaign_legacy_sources (
  source_key TEXT PRIMARY KEY NOT NULL CHECK (length(source_key) BETWEEN 1 AND 64),
  campaign_id TEXT NOT NULL REFERENCES station_campaigns(id),
  created_at INTEGER NOT NULL CHECK (created_at >= 0)
) STRICT;
CREATE TABLE station_campaigns (
  id TEXT PRIMARY KEY NOT NULL,
  source TEXT NOT NULL,
  medium TEXT NOT NULL,
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  clip_id TEXT,
  landing_path TEXT NOT NULL CHECK (landing_path LIKE '/%' AND landing_path NOT LIKE '//%' AND length(landing_path)<=1024),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','active','archived')),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at), content_value TEXT NOT NULL DEFAULT '', edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version >= 1),
  FOREIGN KEY (track_id,clip_id) REFERENCES station_clips(track_id,id)
) STRICT;
CREATE TABLE station_clip_publications (
  id TEXT PRIMARY KEY NOT NULL,
  clip_id TEXT NOT NULL REFERENCES station_clips(id),
  channel TEXT NOT NULL,
  post_id TEXT NOT NULL,
  post_url TEXT NOT NULL CHECK (post_url LIKE 'https://%' AND length(post_url)<=2048),
  external_published_at INTEGER NOT NULL CHECK (external_published_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  UNIQUE (channel,post_id),
  UNIQUE (clip_id,channel,post_id)
) STRICT;
CREATE TABLE station_clip_revisions (
  id TEXT NOT NULL REFERENCES station_clips(id),
  revision INTEGER NOT NULL CHECK (revision > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json) AND json_type(metadata_json)='object'),
  media_asset_id TEXT,
  poster_asset_id TEXT,
  duration_ms INTEGER CHECK (duration_ms > 0),
  subtitles_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(subtitles_json) AND json_type(subtitles_json)='object'),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  FOREIGN KEY (id,media_asset_id) REFERENCES station_media_assets(owner_clip_id,id),
  FOREIGN KEY (id,poster_asset_id) REFERENCES station_media_assets(owner_clip_id,id),
  PRIMARY KEY (id,revision)
) STRICT;
CREATE TABLE station_clips (
  id TEXT PRIMARY KEY NOT NULL,
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  type TEXT NOT NULL CHECK (type IN ('short_video','mv')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  draft_revision INTEGER CHECK (draft_revision > 0),
  published_revision INTEGER CHECK (published_revision > 0),
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  scheduled_at INTEGER CHECK (scheduled_at >= 0),
  published_at INTEGER CHECK (published_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  UNIQUE (track_id,id),
  FOREIGN KEY (id,draft_revision) REFERENCES station_clip_revisions(id,revision),
  FOREIGN KEY (id,published_revision) REFERENCES station_clip_revisions(id,revision),
  CHECK (status <> 'scheduled' OR scheduled_at IS NOT NULL),
  CHECK (status <> 'published' OR (published_revision IS NOT NULL AND published_at IS NOT NULL))
) STRICT;
CREATE TABLE station_event_inflight (
  token TEXT PRIMARY KEY CHECK(length(token)=36),
  received_at INTEGER NOT NULL CHECK(received_at>=0),
  expires_at INTEGER NOT NULL CHECK(expires_at=received_at+60000)
) STRICT;
CREATE TABLE station_event_rates (
  scope TEXT NOT NULL CHECK(scope IN ('session','source','global')),
  window_start INTEGER NOT NULL CHECK(window_start>=0),
  subject TEXT NOT NULL CHECK(length(subject) BETWEEN 36 AND 64),
  hits INTEGER NOT NULL CHECK(hits>=1),
  PRIMARY KEY(scope,window_start,subject)
) STRICT;
CREATE TABLE station_event_retention_guard (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1), cutoff INTEGER NOT NULL CHECK(cutoff>=0)
) STRICT;
CREATE TABLE station_event_retention_health (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1), last_sweep_at INTEGER NOT NULL CHECK(last_sweep_at>=0)
) STRICT;
CREATE TABLE station_external_metrics (
  id TEXT PRIMARY KEY,
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  clip_id TEXT,
  campaign_id TEXT REFERENCES station_campaigns(id),
  metric TEXT NOT NULL CHECK(metric IN ('impressions','platform_plays')),
  provider TEXT NOT NULL CHECK(provider IN ('netease','qishui','apple_music','spotify','youtube','douyin','xiaohongshu','bilibili','instagram')),
  value INTEGER NOT NULL CHECK(value BETWEEN 0 AND 2147483647),
  source_kind TEXT NOT NULL CHECK(source_kind IN ('platform_dashboard','platform_export')),
  source_label TEXT NOT NULL CHECK(length(source_label) BETWEEN 3 AND 160),
  window_start INTEGER NOT NULL,
  window_end INTEGER NOT NULL CHECK(window_end>window_start AND window_end-window_start<=2678400000),
  observed_at INTEGER NOT NULL CHECK(observed_at>=window_end),
  updated_at INTEGER NOT NULL CHECK(updated_at>=observed_at),
  status TEXT NOT NULL CHECK(status IN ('active','withdrawn')),
  edit_version INTEGER NOT NULL CHECK(edit_version>=1),
  expires_at INTEGER NOT NULL CHECK(expires_at>window_end),
  FOREIGN KEY(track_id,clip_id) REFERENCES station_clips(track_id,id),
  CHECK(metric<>'platform_plays' OR provider IN ('netease','qishui','apple_music','spotify','youtube'))
) STRICT;
CREATE TABLE station_game_revisions (
  id TEXT NOT NULL REFERENCES station_games(id),
  revision INTEGER NOT NULL CHECK (revision > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json) AND json_type(metadata_json)='object'),
  launch_url TEXT CHECK (launch_url IS NULL OR (launch_url LIKE '/games/%/' AND launch_url NOT GLOB '*[^a-z0-9/_-]*' AND instr(launch_url,'//')=0)),
  supported_devices_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(supported_devices_json) AND json_type(supported_devices_json)='array'),
  screenshot_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(screenshot_ids_json) AND json_type(screenshot_ids_json)='array'),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (id,revision)
) STRICT;
CREATE TABLE station_games (
  id TEXT PRIMARY KEY NOT NULL,
  slug TEXT NOT NULL UNIQUE CHECK (length(slug) BETWEEN 1 AND 100 AND slug<>'cat-life' AND slug NOT GLOB '*[^a-z0-9-]*' AND slug NOT LIKE '-%' AND slug NOT LIKE '%-' AND instr(slug,'--')=0),
  runtime_key TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  draft_revision INTEGER CHECK (draft_revision > 0),
  published_revision INTEGER CHECK (published_revision > 0),
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  scheduled_at INTEGER CHECK (scheduled_at >= 0),
  published_at INTEGER CHECK (published_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  FOREIGN KEY (id,draft_revision) REFERENCES station_game_revisions(id,revision),
  FOREIGN KEY (id,published_revision) REFERENCES station_game_revisions(id,revision),
  CHECK (status <> 'scheduled' OR scheduled_at IS NOT NULL),
  CHECK (status <> 'published' OR (published_revision IS NOT NULL AND published_at IS NOT NULL))
) STRICT;
CREATE TABLE station_home_configs (
  id TEXT PRIMARY KEY NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  draft_revision INTEGER CHECK (draft_revision > 0),
  published_revision INTEGER CHECK (published_revision > 0),
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  scheduled_at INTEGER CHECK (scheduled_at >= 0),
  published_at INTEGER CHECK (published_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  FOREIGN KEY (id,draft_revision) REFERENCES station_home_revisions(id,revision),
  FOREIGN KEY (id,published_revision) REFERENCES station_home_revisions(id,revision),
  CHECK (status <> 'scheduled' OR scheduled_at IS NOT NULL),
  CHECK (status <> 'published' OR (published_revision IS NOT NULL AND published_at IS NOT NULL))
) STRICT;
CREATE TABLE station_home_revisions (
  id TEXT NOT NULL REFERENCES station_home_configs(id),
  revision INTEGER NOT NULL CHECK (revision > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  featured_track_id TEXT REFERENCES station_promotions(track_id),
  featured_game_id TEXT REFERENCES station_games(id),
  selected_track_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(selected_track_ids_json) AND json_type(selected_track_ids_json)='array' AND json_array_length(selected_track_ids_json)<=3),
  selected_clip_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(selected_clip_ids_json) AND json_type(selected_clip_ids_json)='array' AND json_array_length(selected_clip_ids_json)<=4),
  selected_update_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(selected_update_ids_json) AND json_type(selected_update_ids_json)='array' AND json_array_length(selected_update_ids_json)<=3),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (id,revision)
) STRICT;
CREATE TABLE station_media_assets (
  id TEXT PRIMARY KEY NOT NULL,
  owner_clip_id TEXT REFERENCES station_clips(id),
  owner_game_id TEXT REFERENCES station_games(id),
  kind TEXT NOT NULL CHECK (kind IN ('short_video','mv','poster','game_screenshot')),
  object_key TEXT NOT NULL UNIQUE CHECK (length(object_key) BETWEEN 1 AND 512),
  content_type TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'reserved' CHECK (state IN ('reserved','uploading','uploaded','validated','rejected','revoked')),
  byte_size INTEGER CHECK (byte_size > 0),
  duration_ms INTEGER CHECK (duration_ms > 0),
  width INTEGER CHECK (width > 0),
  height INTEGER CHECK (height > 0),
  sha256 TEXT CHECK (length(sha256)=64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
  etag TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  UNIQUE (owner_clip_id,id),
  UNIQUE (owner_game_id,id),
  CHECK ((kind='game_screenshot' AND owner_game_id IS NOT NULL AND owner_clip_id IS NULL) OR
    (kind<>'game_screenshot' AND owner_clip_id IS NOT NULL AND owner_game_id IS NULL)),
  CHECK ((kind IN ('short_video','mv') AND content_type IN ('video/mp4','video/webm')) OR
    (kind IN ('poster','game_screenshot') AND content_type IN ('image/jpeg','image/png','image/webp'))),
  CHECK (state NOT IN ('uploaded','validated') OR (byte_size IS NOT NULL AND sha256 IS NOT NULL)),
  CHECK (state<>'validated' OR (kind IN ('short_video','mv') AND duration_ms IS NOT NULL) OR
    (kind IN ('poster','game_screenshot') AND width IS NOT NULL AND height IS NOT NULL))
) STRICT;
CREATE TABLE station_media_upload_sessions (
  id TEXT PRIMARY KEY NOT NULL,
  asset_id TEXT NOT NULL UNIQUE REFERENCES station_media_assets(id),
  actor_id TEXT NOT NULL CHECK (length(actor_id) BETWEEN 1 AND 200),
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','uploading','uploaded','validating','completed','rejected','expired')),
  declared_bytes INTEGER NOT NULL CHECK (declared_bytes > 0 AND declared_bytes <= 268435456),
  expected_sha256 TEXT NOT NULL CHECK (length(expected_sha256)=64 AND expected_sha256 NOT GLOB '*[^0-9a-f]*'),
  actual_bytes INTEGER CHECK (actual_bytes=declared_bytes),
  write_token TEXT,
  validation_started_at INTEGER CHECK (validation_started_at >= created_at),
  error_code TEXT CHECK (length(error_code) BETWEEN 1 AND 80),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  CHECK (status='reserved' OR write_token IS NOT NULL OR status IN ('rejected','expired')),
  CHECK (status<>'completed' OR (actual_bytes IS NOT NULL AND validation_started_at IS NOT NULL AND error_code IS NULL))
) STRICT;
CREATE TABLE station_platform_links (
  id TEXT PRIMARY KEY NOT NULL,
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  provider TEXT NOT NULL CHECK (provider IN ('netease','qishui','apple_music','youtube','spotify')),
  territories_json TEXT NOT NULL DEFAULT '["*"]' CHECK (json_valid(territories_json) AND json_type(territories_json)='array' AND json_array_length(territories_json)>0),
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','live','unavailable','removed')),
  url TEXT CHECK (url IS NULL OR (length(url) BETWEEN 10 AND 2048 AND url LIKE 'https://%')),
  verified_at INTEGER CHECK (verified_at >= 0),
  external_released_at INTEGER CHECK (external_released_at >= 0),
  sort_order INTEGER NOT NULL DEFAULT 0 CHECK (sort_order >= 0),
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  UNIQUE (track_id,provider,territories_json),
  UNIQUE (track_id,id),
  CHECK (status<>'live' OR (url IS NOT NULL AND verified_at IS NOT NULL))
) STRICT;
CREATE TABLE station_promotion_revisions (
  track_id TEXT NOT NULL REFERENCES station_promotions(track_id),
  revision INTEGER NOT NULL CHECK (revision > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0,1)),
  preview_enabled INTEGER NOT NULL DEFAULT 0 CHECK (preview_enabled IN (0,1)),
  preview_asset_id TEXT,
  selected_platform_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(selected_platform_ids_json) AND json_type(selected_platform_ids_json)='array'),
  selected_clip_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(selected_clip_ids_json) AND json_type(selected_clip_ids_json)='array'),
  sort_order INTEGER NOT NULL DEFAULT 0 CHECK (sort_order >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  FOREIGN KEY (track_id,preview_asset_id) REFERENCES music_assets(owner_track_id,id),
  CHECK (preview_enabled=0 OR preview_asset_id IS NOT NULL),
  PRIMARY KEY (track_id,revision)
) STRICT;
CREATE TABLE station_promotions (
  track_id TEXT PRIMARY KEY NOT NULL REFERENCES station_track_publications(track_id),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  draft_revision INTEGER CHECK (draft_revision > 0),
  published_revision INTEGER CHECK (published_revision > 0),
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  scheduled_at INTEGER CHECK (scheduled_at >= 0),
  published_at INTEGER CHECK (published_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  FOREIGN KEY (track_id,draft_revision) REFERENCES station_promotion_revisions(track_id,revision),
  FOREIGN KEY (track_id,published_revision) REFERENCES station_promotion_revisions(track_id,revision),
  CHECK (status <> 'scheduled' OR scheduled_at IS NOT NULL),
  CHECK (status <> 'published' OR (published_revision IS NOT NULL AND published_at IS NOT NULL))
) STRICT;
CREATE TABLE station_publish_jobs (
  id TEXT PRIMARY KEY NOT NULL,
  object_type TEXT NOT NULL CHECK(object_type IN ('tracks','promotions','clips','games','home')),
  object_id TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK(revision>0),
  edit_version INTEGER NOT NULL CHECK(edit_version>0),
  actor_id TEXT NOT NULL CHECK(length(actor_id) BETWEEN 1 AND 200),
  due_at INTEGER NOT NULL CHECK(due_at>=0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','succeeded','failed','cancelled')),
  error_code TEXT,
  created_at INTEGER NOT NULL CHECK(created_at>=0),
  finished_at INTEGER CHECK(finished_at>=created_at),
  CHECK((status='pending' AND finished_at IS NULL AND error_code IS NULL) OR
    (status<>'pending' AND finished_at IS NOT NULL)),
  CHECK(status<>'failed' OR error_code IS NOT NULL)
) STRICT;
CREATE TABLE station_report_health (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  coverage_start INTEGER,
  next_day INTEGER,
  last_sweep_at INTEGER NOT NULL DEFAULT 0,
  last_aggregate_at INTEGER NOT NULL DEFAULT 0
) STRICT;
CREATE TABLE station_report_jobs (
  window_start INTEGER PRIMARY KEY,
  window_end INTEGER NOT NULL CHECK(window_end=window_start+86400000),
  keys_json TEXT NOT NULL CHECK(json_valid(keys_json) AND json_type(keys_json)='array' AND json_array_length(keys_json) BETWEEN 1 AND 512),
  cursor INTEGER NOT NULL DEFAULT 0 CHECK(cursor>=0 AND cursor<=json_array_length(keys_json)),
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK(edit_version>=1),
  status TEXT NOT NULL CHECK(status IN ('pending','complete')),
  expires_at INTEGER NOT NULL
) STRICT;
CREATE TABLE station_report_operations (
  actor_id TEXT NOT NULL,
  route TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  result_json TEXT NOT NULL CHECK(json_valid(result_json)),
  expires_at INTEGER NOT NULL,
  PRIMARY KEY(actor_id,route,idempotency_key)
) STRICT;
CREATE TABLE station_report_retention_guard (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1), cutoff INTEGER NOT NULL
) STRICT;
CREATE TABLE station_report_snapshots (
  id TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  window_end INTEGER NOT NULL CHECK(window_end>window_start),
  query_key TEXT NOT NULL CHECK(length(query_key)<=768),
  stats_json TEXT NOT NULL CHECK(json_valid(stats_json) AND json_type(stats_json)='object'),
  generated_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at>window_end),
  UNIQUE(window_start,window_end,query_key)
) STRICT;
CREATE TABLE station_report_window_seal (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  sealed_before INTEGER NOT NULL CHECK(sealed_before>=0 AND sealed_before%86400000=0),
  updated_at INTEGER NOT NULL CHECK(updated_at>=sealed_before)
) STRICT;
CREATE TABLE station_route_migrations (
  old_path TEXT PRIMARY KEY NOT NULL CHECK (old_path LIKE '/%' AND old_path NOT LIKE '//%'),
  action TEXT NOT NULL CHECK (action IN ('keep','redirect','retire','service')),
  new_path TEXT CHECK (new_path IS NULL OR (new_path LIKE '/%' AND new_path NOT LIKE '//%')),
  reason TEXT NOT NULL CHECK (length(trim(reason))>0),
  approved_at INTEGER CHECK (approved_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  CHECK (action<>'redirect' OR (new_path IS NOT NULL AND new_path<>old_path)),
  CHECK (action IN ('redirect','keep') OR new_path IS NULL)
) STRICT;
CREATE TABLE station_track_publications (
  track_id TEXT PRIMARY KEY NOT NULL REFERENCES music_tracks(id),
  origin TEXT NOT NULL DEFAULT 'manual' CHECK (origin IN ('manual','legacy_backfill')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  draft_revision INTEGER CHECK (draft_revision > 0),
  published_revision INTEGER CHECK (published_revision > 0),
  edit_version INTEGER NOT NULL DEFAULT 1 CHECK (edit_version > 0),
  scheduled_at INTEGER CHECK (scheduled_at >= 0),
  published_at INTEGER CHECK (published_at >= 0),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  FOREIGN KEY (track_id,draft_revision) REFERENCES station_track_revisions(track_id,revision),
  FOREIGN KEY (track_id,published_revision) REFERENCES station_track_revisions(track_id,revision),
  CHECK (status <> 'scheduled' OR scheduled_at IS NOT NULL),
  CHECK (status <> 'published' OR (published_revision IS NOT NULL AND published_at IS NOT NULL))
) STRICT;
CREATE TABLE station_track_revisions (
  track_id TEXT NOT NULL REFERENCES station_track_publications(track_id),
  revision INTEGER NOT NULL CHECK (revision > 0),
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','sealed')),
  metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json) AND json_type(metadata_json)='object'),
  legacy_revision_id TEXT,
  site_audio_mode TEXT NOT NULL DEFAULT 'none' CHECK (site_audio_mode IN ('none','preview','free_full','existing_entitlement')),
  duration_ms INTEGER CHECK (duration_ms > 0),
  cover_asset_id TEXT,
  lyrics_asset_id TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  FOREIGN KEY (track_id,legacy_revision_id) REFERENCES music_track_revisions(track_id,id),
  FOREIGN KEY (track_id,cover_asset_id) REFERENCES music_assets(owner_track_id,id),
  FOREIGN KEY (track_id,lyrics_asset_id) REFERENCES music_assets(owner_track_id,id),
  CHECK (site_audio_mode NOT IN ('free_full','existing_entitlement') OR legacy_revision_id IS NOT NULL),
  PRIMARY KEY (track_id,revision)
) STRICT;
CREATE TABLE station_track_routes (
  slug TEXT PRIMARY KEY NOT NULL CHECK (length(slug) BETWEEN 1 AND 100),
  track_id TEXT NOT NULL REFERENCES music_tracks(id),
  role TEXT NOT NULL CHECK (role IN ('canonical','alias')),
  origin TEXT NOT NULL DEFAULT 'managed' CHECK (origin IN ('managed','legacy_backfill')),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  CHECK (origin='legacy_backfill' OR (slug NOT GLOB '*[^a-z0-9-]*' AND slug NOT LIKE '-%' AND slug NOT LIKE '%-' AND instr(slug,'--')=0))
) STRICT;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(1,'0001_music_foundation.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(2,'0002_music_publication.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(3,'0003_music_uploads.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(4,'0004_music_cleanup.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(5,'0005_music_rate_limits.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(6,'0006_music_analytics.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(7,'0007_music_albums.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(8,'0008_music_featured.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(9,'0009_music_album_covers.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(10,'0010_music_limited_free.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(11,'0011_music_share_rate_limits.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(12,'0012_station_redesign.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(13,'0013_station_media_uploads.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(14,'0014_station_content_operations.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(15,'0015_station_campaign_links.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(16,'0016_station_event_collection.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(17,'0017_station_reports.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "d1_migrations"("id","name","applied_at") VALUES(18,'0018_station_report_window_seals.sql','2026-10-10T12:59:18.481Z');;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('ca760000-0000-4000-8000-000000000091','isolated-fixture','fixture.seed','ca760000-0000-4000-8000-000000000010','{"fixture":true}','ca760000-0000-4000-8000-000000000092',1791158400000);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('31e594ab-46ed-45c8-a4bb-3492cf32847a','t22-synthetic-publisher@example.test','station.rights.review','ca760000-0000-4000-8000-000000000014','{"scope":"cover","status":"approved","previousStatus":"pending","reason":"本机演练"}','31e594ab-46ed-45c8-a4bb-3492cf32847a',1791637164244);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('d2f9fbd9-4f63-4083-8c82-00934ce5b18a','t22-synthetic-publisher@example.test','station.content.save','ca760000-0000-4000-8000-000000000010','{"type":"tracks","revision":2,"previousRevision":1,"reason":"合成网站作品"}','d2f9fbd9-4f63-4083-8c82-00934ce5b18a',1791637164367);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('03328186-a751-416d-a83d-3706f82089f2','t22-synthetic-publisher@example.test','station.content.publish','ca760000-0000-4000-8000-000000000010','{"type":"tracks","revision":2,"sourceRevision":2,"reason":"隔离发布","jobId":null}','03328186-a751-416d-a83d-3706f82089f2',1791637164558);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('a36d3753-aa28-4f55-8c75-ec6c1bc57106','t22-synthetic-publisher@example.test','station.content.save','ca760000-0000-4000-8000-000000000010','{"type":"tracks","revision":3,"previousRevision":2,"reason":"迁移后编辑"}','a36d3753-aa28-4f55-8c75-ec6c1bc57106',1791637164835);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('d8d8cc84-9fea-4f53-a949-589441905dc8','t22-synthetic-publisher@example.test','station.content.publish','ca760000-0000-4000-8000-000000000010','{"type":"tracks","revision":3,"sourceRevision":3,"reason":"迁移后发布","jobId":null}','d8d8cc84-9fea-4f53-a949-589441905dc8',1791637165006);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('1b80fb72-3b26-4aa1-85c7-fa279e090af5','t22-synthetic-publisher@example.test','station.content.create','7dce6ed2-c3fa-40fd-9d23-bc237fa08464','{"type":"tracks","revision":1,"reason":"迁移后新草稿"}','1b80fb72-3b26-4aa1-85c7-fa279e090af5',1791637165292);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('58740586-1699-42ab-857f-876355e2ac28','t22-synthetic-publisher@example.test','station.platform.save','23a8f566-295b-4b29-9c5c-56655165866d','{"trackId":"ca760000-0000-4000-8000-000000000010","provider":"netease","status":"planned","previousStatus":null}','58740586-1699-42ab-857f-876355e2ac28',1791637165483);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('633c5fdb-efba-41a0-a4e8-2b3a2bcb4a0d','t22-synthetic-publisher@example.test','station.content.create','bca9cded-7e55-4bed-adfa-389bec0c504f','{"type":"games","revision":1,"reason":"本机介绍"}','633c5fdb-efba-41a0-a4e8-2b3a2bcb4a0d',1791637165575);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('4ad466fc-e09e-40b2-99c8-69efe3dd0130','t22-synthetic-publisher@example.test','station.content.save','bca9cded-7e55-4bed-adfa-389bec0c504f','{"type":"games","revision":2,"previousRevision":1,"reason":"合成截图"}','4ad466fc-e09e-40b2-99c8-69efe3dd0130',1791637165718);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('e633d428-4ff2-426a-bdc2-5b461a2f7a15','t22-synthetic-publisher@example.test','station.content.publish','bca9cded-7e55-4bed-adfa-389bec0c504f','{"type":"games","revision":2,"sourceRevision":2,"reason":"隔离介绍","jobId":null}','e633d428-4ff2-426a-bdc2-5b461a2f7a15',1791637165895);;
INSERT INTO "music_admin_audit_logs"("id","actor_id","action","target_id","summary_json","request_id","created_at") VALUES('a08c97fd-e760-4462-b8e5-a972bd64baee','t22-synthetic-publisher@example.test','station.content.rollback','ca760000-0000-4000-8000-000000000010','{"type":"tracks","revision":4,"sourceRevision":2,"reason":"隔离恢复旧内容","jobId":null}','a08c97fd-e760-4462-b8e5-a972bd64baee',1791637168084);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000012','ca760000-0000-4000-8000-000000000010','audio','music/audio/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000012.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000013','ca760000-0000-4000-8000-000000000010','preview','music/previews/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000013.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000012',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000014','ca760000-0000-4000-8000-000000000010','cover','music/covers/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000014.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000015','ca760000-0000-4000-8000-000000000010','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000010/ca760000-0000-4000-8000-000000000015.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000022','ca760000-0000-4000-8000-000000000020','audio','music/audio/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000022.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000023','ca760000-0000-4000-8000-000000000020','preview','music/previews/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000023.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000022',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000024','ca760000-0000-4000-8000-000000000020','cover','music/covers/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000024.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000025','ca760000-0000-4000-8000-000000000020','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000020/ca760000-0000-4000-8000-000000000025.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000032','ca760000-0000-4000-8000-000000000030','audio','music/audio/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000032.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000033','ca760000-0000-4000-8000-000000000030','preview','music/previews/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000033.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000032',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000034','ca760000-0000-4000-8000-000000000030','cover','music/covers/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000034.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000035','ca760000-0000-4000-8000-000000000030','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000030/ca760000-0000-4000-8000-000000000035.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000042','ca760000-0000-4000-8000-000000000040','audio','music/audio/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000042.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000043','ca760000-0000-4000-8000-000000000040','preview','music/previews/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000043.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000042',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000044','ca760000-0000-4000-8000-000000000040','cover','music/covers/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000044.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000045','ca760000-0000-4000-8000-000000000040','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000040/ca760000-0000-4000-8000-000000000045.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000052','ca760000-0000-4000-8000-000000000050','audio','music/audio/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000052.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000053','ca760000-0000-4000-8000-000000000050','preview','music/previews/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000053.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000052',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000054','ca760000-0000-4000-8000-000000000050','cover','music/covers/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000054.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000055','ca760000-0000-4000-8000-000000000050','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000050/ca760000-0000-4000-8000-000000000055.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000062','ca760000-0000-4000-8000-000000000060','audio','music/audio/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000062.mp3','validated','audio/mpeg','mp3',100,120000,NULL,NULL,NULL,'7d465ba69bcd711a850a8af37e79f328c512980e9845b7ffa30dc3a84dfd6ae8','4673d721c9b2001c6aa6e0e776afa3c1',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000063','ca760000-0000-4000-8000-000000000060','preview','music/previews/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000063.mp3','validated','audio/mpeg','mp3',100,30000,'ca760000-0000-4000-8000-000000000062',0,30000,'de577cc8152fad5ddc31d41026a136384d24a6e0c44f2033dc30819652b94a73','966542c8eafb5697d5f2ff1ef3fdb463',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000064','ca760000-0000-4000-8000-000000000060','cover','music/covers/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000064.png','validated','image/png','png',100,NULL,NULL,NULL,NULL,'0226d7097f3413312690e76e1fe1b9e0aaac1dd7010b656827ad27f01fee66db','20924d5cb3fbda14201647d3d62582a2',1791158380000);;
INSERT INTO "music_assets"("id","owner_track_id","kind","object_key","state","content_type","format","byte_size","duration_ms","derived_from_asset_id","source_start_ms","source_end_ms","sha256","etag","created_at") VALUES('ca760000-0000-4000-8000-000000000065','ca760000-0000-4000-8000-000000000060','lyrics','music/lyrics/ca760000-0000-4000-8000-000000000060/ca760000-0000-4000-8000-000000000065.lrc','validated','text/plain','lrc',100,NULL,NULL,NULL,NULL,'9427b82dcd09ce70f9de9c9677c460f18a86aec076fbdc79d8e9709f58127d22','ea031c7513f98bda45ea90b53ec0d5a9',1791158380000);;
INSERT INTO "music_collection_tracks"("collection_id","track_id","position") VALUES('ca760000-0000-4000-8000-000000000090','ca760000-0000-4000-8000-000000000010',0);;
INSERT INTO "music_collections"("id","slug","original_locale","title_json","description_json","status","version","created_at","updated_at","collection_type","listening_mode","cover_track_id","cover_asset_id") VALUES('ca760000-0000-4000-8000-000000000090','old-collection','en','{"en":"Old collection"}','{}','published',1,1791158390000,1791158390000,'playlist','mixed',NULL,NULL);;
INSERT INTO "music_featured_home"("id","version","updated_at") VALUES(1,1,0);;
INSERT INTO "music_featured_items"("slot_kind","position","track_id","collection_id") VALUES('primary',0,'ca760000-0000-4000-8000-000000000010',NULL);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/assets/ca760000-0000-4000-8000-000000000014/rights','e0bf06fd-0189-4ea4-a2cd-c0d8c28be8b3','9ec2f03b63a5ee34e48882dcaaf6cba24f0819cd0feb7d420a33c3b6213e6601','{"id":"ca760000-0000-4000-8000-000000000014","editVersion":1,"status":"approved"}',1791723564244,1791637164244);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/tracks/ca760000-0000-4000-8000-000000000010','afd0d292-555f-410a-923d-8d73be97ad43','af505c00b76e87826763dbbe4a5f9fd1d0632e5775763405b02e94251756ee47','{"type":"tracks","id":"ca760000-0000-4000-8000-000000000010","revision":2,"editVersion":2,"cachePolicy":"no-store"}',1791723564367,1791637164367);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/tracks/ca760000-0000-4000-8000-000000000010/publish','177bda56-98f2-4f80-85bb-60faf3a3fe62','ca4f66fb17539b0bdcc3e51226af1e77cdbbb6210c32b238776322a7ed499a2b','{"type":"tracks","id":"ca760000-0000-4000-8000-000000000010","revision":2,"editVersion":3,"cachePolicy":"no-store","status":"published"}',1791723564558,1791637164558);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/tracks/ca760000-0000-4000-8000-000000000010','8236d440-5c26-450e-9d1f-70f36bbb3388','e341dfa94c9f9bc3c8a7b0187b2a54846f37cab4da265bd3d03ad1bd961196f2','{"type":"tracks","id":"ca760000-0000-4000-8000-000000000010","revision":3,"editVersion":4,"cachePolicy":"no-store"}',1791723564835,1791637164835);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/tracks/ca760000-0000-4000-8000-000000000010/publish','6db8925d-1b9c-4b57-a6e2-80897cfb6625','3ea9337b3a2be0b2fe551663b319800af1fec72ea2ca438f900b070a16be1834','{"type":"tracks","id":"ca760000-0000-4000-8000-000000000010","revision":3,"editVersion":5,"cachePolicy":"no-store","status":"published"}',1791723565006,1791637165006);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/tracks','3b514b2a-fbdb-401b-9da8-c42d4ee4054d','ee2ddd88020d2517656f06fa81d32ccdb28af3b29cae57490b69f55c0fc4ac0e','{"type":"tracks","id":"7dce6ed2-c3fa-40fd-9d23-bc237fa08464","revision":1,"editVersion":1,"cachePolicy":"no-store"}',1791723565292,1791637165292);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/platforms','a1f3d544-fa81-4054-89ad-510237ca0ea9','8c0a9caea0ba3701e471efe51b3c68fbd9708989aaca44ef8d55ffdd09f9aac5','{"id":"23a8f566-295b-4b29-9c5c-56655165866d","editVersion":1,"cachePolicy":"no-store"}',1791723565483,1791637165483);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/games','3b596648-b428-4aad-8857-1da9d5aef5c1','811d461358ebd5e60e314cc3d2fddd004abbcd564d1a5497a0927549d9d41c3b','{"type":"games","id":"bca9cded-7e55-4bed-adfa-389bec0c504f","revision":1,"editVersion":1,"cachePolicy":"no-store"}',1791723565575,1791637165575);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/games/bca9cded-7e55-4bed-adfa-389bec0c504f','efa265b3-fd88-4edf-9599-7b7238cedd64','92fd77e36bac31ab2b734d49716c0e6f3bb7144e6ed22c43af19db0c0651a5e8','{"type":"games","id":"bca9cded-7e55-4bed-adfa-389bec0c504f","revision":2,"editVersion":2,"cachePolicy":"no-store"}',1791723565718,1791637165718);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/games/bca9cded-7e55-4bed-adfa-389bec0c504f/publish','97829537-9dc5-455f-a769-16f9c6199c1c','183ace2958f1a0ae891d28ec2a7d77d76301b71c5a408138b77d45aa706f567f','{"type":"games","id":"bca9cded-7e55-4bed-adfa-389bec0c504f","revision":2,"editVersion":3,"cachePolicy":"no-store","status":"published"}',1791723565895,1791637165895);;
INSERT INTO "music_mutations"("actor_id","route","idempotency_key","request_hash","result_json","expires_at","created_at") VALUES('t22-synthetic-publisher@example.test','/admin/api/music/site-content/tracks/ca760000-0000-4000-8000-000000000010/rollback','0b46ae77-d308-4c1a-8eab-5f7019485bc9','d507b868aaa56df2f8983189439aa64c5994d78276b30a95032f3daa048abdb0','{"type":"tracks","id":"ca760000-0000-4000-8000-000000000010","revision":4,"editVersion":6,"cachePolicy":"no-store","status":"published"}',1791723568084,1791637168084);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'05d5aa266fcfc9bd7fa7a6add4bdf9b974f5746cca6208091d76b594ed89dc22',1);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'d13519f490242446389074fff84cec372a8a7dd34ec4fdca0e375637304dd182',1);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'db001a853899a756f7aada48e49490fe0fa2a2f79634bcf038fbceefa8a60405',1);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'14f8da6d38d0fe1902e65da0de443cc354964966d8e291d081bc217fa3e6e7a2',1);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'744e5d42dbfa8550eb69fd4d75dbf6f7ae6ee532c95d028622056a960aec9e2b',1);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'41857ff8502bba9ac8f87a1c4fee0e97ab55f00f349c18d6c879cecf6cabbb9a',2);;
INSERT INTO "music_rate_sources"("category","window_start","source_hash","hits") VALUES('catalog',1791637140000,'49b5dc7821a89391a772cee453c330fa5c078f48a29821c3f35f5a4d688b9305',2);;
INSERT INTO "music_rate_windows"("category","window_start","hits") VALUES('catalog',1791637140000,9);;
INSERT INTO "music_settings"("key","value_json","updated_at") VALUES('catalogVersion','0',0);;
INSERT INTO "music_settings"("key","value_json","updated_at") VALUES('previewLimitMs','45000',0);;
INSERT INTO "music_settings"("key","value_json","updated_at") VALUES('storageQuotaBytes','0',0);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000011','ca760000-0000-4000-8000-000000000010',1,'sealed','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000012','ca760000-0000-4000-8000-000000000013','ca760000-0000-4000-8000-000000000014','ca760000-0000-4000-8000-000000000015','free',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000021','ca760000-0000-4000-8000-000000000020',1,'sealed','{"originalLocale":"en","title":{"en":"vip","zh-Hant":"夾具 vip"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000022','ca760000-0000-4000-8000-000000000023','ca760000-0000-4000-8000-000000000024','ca760000-0000-4000-8000-000000000025','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000031','ca760000-0000-4000-8000-000000000030',1,'sealed','{"originalLocale":"en","title":{"en":"limited-active","zh-Hant":"夾具 limited-active"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000032','ca760000-0000-4000-8000-000000000033','ca760000-0000-4000-8000-000000000034','ca760000-0000-4000-8000-000000000035','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',1791158460000);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000041','ca760000-0000-4000-8000-000000000040',1,'sealed','{"originalLocale":"en","title":{"en":"limited-expired","zh-Hant":"夾具 limited-expired"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000042','ca760000-0000-4000-8000-000000000043','ca760000-0000-4000-8000-000000000044','ca760000-0000-4000-8000-000000000045','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',1791158340000);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000051','ca760000-0000-4000-8000-000000000050',1,'sealed','{"originalLocale":"en","title":{"en":"early-access","zh-Hant":"夾具 early-access"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000052','ca760000-0000-4000-8000-000000000053','ca760000-0000-4000-8000-000000000054','ca760000-0000-4000-8000-000000000055','early_access',1791158460000,'vip',1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('ca760000-0000-4000-8000-000000000061','ca760000-0000-4000-8000-000000000060',1,'sealed','{"originalLocale":"en","title":{"en":"unpublished","zh-Hant":"夾具 unpublished"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000062','ca760000-0000-4000-8000-000000000063','ca760000-0000-4000-8000-000000000064','ca760000-0000-4000-8000-000000000065','vip',NULL,NULL,1,1791158388000,1791158385000,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',NULL);;
INSERT INTO "music_track_revisions"("id","track_id","revision_no","state","metadata_json","audio_asset_id","preview_asset_id","cover_asset_id","lyrics_asset_id","access_mode","early_access_until","post_early_access_mode","policy_version","technical_reviewed_at","created_at","technical_fingerprint","free_until") VALUES('8a41361a-935f-450e-9883-f1bb34937e97','7dce6ed2-c3fa-40fd-9d23-bc237fa08464',1,'draft','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"story":"Synthetic metadata, no actual release or license.","creatorName":"Station Cat fixture","instrumental":true,"language":"instrumental","genres":[],"moods":[]}',NULL,NULL,NULL,NULL,'vip',NULL,NULL,1,NULL,1791637165292,NULL,NULL);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000010','permanent-free','published',NULL,'ca760000-0000-4000-8000-000000000011',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000020','vip','published',NULL,'ca760000-0000-4000-8000-000000000021',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000030','limited-active','published',NULL,'ca760000-0000-4000-8000-000000000031',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000040','limited-expired','published',NULL,'ca760000-0000-4000-8000-000000000041',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000050','early-access','published',NULL,'ca760000-0000-4000-8000-000000000051',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000060','unpublished','unpublished',NULL,'ca760000-0000-4000-8000-000000000061',1,1791158390000,1791158390000,1791158370000,1791158390000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000070','draft-no-audio','draft',NULL,NULL,1,NULL,NULL,1791158380000,1791158380000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000080','archived-no-audio','archived',NULL,NULL,1,NULL,NULL,1791158380000,1791158380000);;
INSERT INTO "music_tracks"("id","slug","lifecycle","draft_revision_id","published_revision_id","edit_version","first_published_at","published_at","created_at","updated_at") VALUES('7dce6ed2-c3fa-40fd-9d23-bc237fa08464','t22-post-migration','draft','8a41361a-935f-450e-9883-f1bb34937e97',NULL,1,NULL,NULL,1791637165292,1791637165292);;
INSERT INTO "station_analytics_events"("event_id","event_name","occurred_at","received_at","track_id","clip_id","game_id","campaign_id","platform_link_id","session_id","playback_id","interaction_id","launch_id","save_operation_id","context_id","session_scope","attribution_kind","campaign_source","campaign_medium","first_campaign_id","device_class","listened_ms","media_ended","time_anomaly","consent_version","expires_at") VALUES('d076e90f-87de-4c3d-987b-40036e5c6b7b','track_view',1791637166144,1791637166146,'ca760000-0000-4000-8000-000000000010',NULL,NULL,NULL,NULL,'d3d7dc94-d55c-4899-ab72-6172ac916045',NULL,NULL,NULL,NULL,'77b667ef-2fcb-420c-bb8b-bdbb358c5f36','session_storage','direct_or_unknown',NULL,NULL,NULL,'desktop',0,0,0,'station-events-v1',1799413166146);;
INSERT INTO "station_asset_rights"("id","music_asset_id","media_asset_id","scope","status","basis","reviewer_id","reviewed_at","created_at","edit_version") VALUES('518e602c-d3dc-4846-88b4-9d7deddb8058','ca760000-0000-4000-8000-000000000014',NULL,'cover','approved','T22 合成校验记录，非真实权利','t22-synthetic-publisher@example.test',1791637164244,1791637164244,1);;
INSERT INTO "station_asset_rights"("id","music_asset_id","media_asset_id","scope","status","basis","reviewer_id","reviewed_at","created_at","edit_version") VALUES('252f7210-107e-43c0-ace3-781f64422ae0',NULL,'66fc7a4a-bff2-46a2-86c1-9b11456ee532','game_screenshot','approved','Synthetic test license only','local-fixture',1791158399000,1791158399000,1);;
INSERT INTO "station_event_rates"("scope","window_start","subject","hits") VALUES('session',1791637140000,'d3d7dc94-d55c-4899-ab72-6172ac916045',1);;
INSERT INTO "station_event_rates"("scope","window_start","subject","hits") VALUES('source',1791637140000,'a2923dc14ab85a64bc7726f15aee2d80dce4eca5cd697276bd138b0783b76bab',1);;
INSERT INTO "station_event_rates"("scope","window_start","subject","hits") VALUES('global',1791637140000,'0000000000000000000000000000000000000000000000000000000000000000',1);;
INSERT INTO "station_event_retention_health"("singleton","last_sweep_at") VALUES(1,1791637164058);;
INSERT INTO "station_game_revisions"("id","revision","state","metadata_json","launch_url","supported_devices_json","screenshot_ids_json","created_at") VALUES('bca9cded-7e55-4bed-adfa-389bec0c504f',1,'draft','{"originalLocale":"en","title":{"en":"T22 synthetic game"},"summary":{"en":"Local rollback fixture only"}}','/games/cat-life/','["desktop","ios","android"]','[]',1791637165575);;
INSERT INTO "station_game_revisions"("id","revision","state","metadata_json","launch_url","supported_devices_json","screenshot_ids_json","created_at") VALUES('bca9cded-7e55-4bed-adfa-389bec0c504f',2,'sealed','{"originalLocale":"en","title":{"en":"T22 synthetic game"},"summary":{"en":"Local rollback fixture only"}}','/games/cat-life/','["desktop","ios","android"]','["66fc7a4a-bff2-46a2-86c1-9b11456ee532"]',1791637165718);;
INSERT INTO "station_games"("id","slug","runtime_key","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('bca9cded-7e55-4bed-adfa-389bec0c504f','cat-life-game','cat-life','published',NULL,2,3,NULL,1791637165895,1791637165575,1791637165895);;
INSERT INTO "station_home_configs"("id","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca710000-0000-4000-8000-000000000001','draft',1,NULL,1,NULL,NULL,0,0);;
INSERT INTO "station_home_revisions"("id","revision","state","featured_track_id","featured_game_id","selected_track_ids_json","selected_clip_ids_json","selected_update_ids_json","created_at") VALUES('ca710000-0000-4000-8000-000000000001',1,'draft',NULL,NULL,'[]','[]','[]',0);;
INSERT INTO "station_media_assets"("id","owner_clip_id","owner_game_id","kind","object_key","content_type","state","byte_size","duration_ms","width","height","sha256","etag","created_at") VALUES('66fc7a4a-bff2-46a2-86c1-9b11456ee532',NULL,'bca9cded-7e55-4bed-adfa-389bec0c504f','game_screenshot','station-test-only/bca9cded-7e55-4bed-adfa-389bec0c504f/66fc7a4a-bff2-46a2-86c1-9b11456ee532','image/png','validated',100,NULL,1280,720,'44cda1bce4e2de527d02384782e8a15163dfb7eb9cf651b0cbc8c282ac53287a','415c76b7d1eb4452216e082b74d5db4f',1791158400000);;
INSERT INTO "station_platform_links"("id","track_id","provider","territories_json","status","url","verified_at","external_released_at","sort_order","version","created_at","updated_at") VALUES('23a8f566-295b-4b29-9c5c-56655165866d','ca760000-0000-4000-8000-000000000010','netease','["*"]','planned',NULL,NULL,NULL,0,1,1791637165483,1791637165483);;
INSERT INTO "station_report_health"("singleton","coverage_start","next_day","last_sweep_at","last_aggregate_at") VALUES(1,NULL,NULL,1791637164145,0);;
INSERT INTO "station_report_window_seal"("singleton","sealed_before","updated_at") VALUES(1,0,0);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000010','legacy_backfill','published',NULL,4,6,NULL,1791637168084,1791158370000,1791637168084);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000020','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158370000,1791158390000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000030','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158370000,1791158390000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000040','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158370000,1791158390000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000050','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158370000,1791158390000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000060','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158370000,1791158390000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000070','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158380000,1791158380000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('ca760000-0000-4000-8000-000000000080','legacy_backfill','draft',1,NULL,1,NULL,NULL,1791158380000,1791158380000);;
INSERT INTO "station_track_publications"("track_id","origin","status","draft_revision","published_revision","edit_version","scheduled_at","published_at","created_at","updated_at") VALUES('7dce6ed2-c3fa-40fd-9d23-bc237fa08464','manual','draft',1,NULL,1,NULL,NULL,1791637165292,1791637165292);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000010',1,'draft','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000011','free_full',120000,'ca760000-0000-4000-8000-000000000014','ca760000-0000-4000-8000-000000000015',1791158370000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000020',1,'draft','{"originalLocale":"en","title":{"en":"vip","zh-Hant":"夾具 vip"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000021','existing_entitlement',120000,'ca760000-0000-4000-8000-000000000024','ca760000-0000-4000-8000-000000000025',1791158370000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000030',1,'draft','{"originalLocale":"en","title":{"en":"limited-active","zh-Hant":"夾具 limited-active"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000031','existing_entitlement',120000,'ca760000-0000-4000-8000-000000000034','ca760000-0000-4000-8000-000000000035',1791158370000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000040',1,'draft','{"originalLocale":"en","title":{"en":"limited-expired","zh-Hant":"夾具 limited-expired"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000041','existing_entitlement',120000,'ca760000-0000-4000-8000-000000000044','ca760000-0000-4000-8000-000000000045',1791158370000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000050',1,'draft','{"originalLocale":"en","title":{"en":"early-access","zh-Hant":"夾具 early-access"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000051','existing_entitlement',120000,'ca760000-0000-4000-8000-000000000054','ca760000-0000-4000-8000-000000000055',1791158370000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000060',1,'draft','{"originalLocale":"en","title":{"en":"unpublished","zh-Hant":"夾具 unpublished"},"summary":{"en":"Isolated fixture."},"creatorName":"Station Cat fixture","instrumental":false,"language":"en","genres":["ambient"],"moods":["calm"],"story":"Synthetic metadata, no actual release or license."}','ca760000-0000-4000-8000-000000000061','existing_entitlement',120000,'ca760000-0000-4000-8000-000000000064','ca760000-0000-4000-8000-000000000065',1791158370000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000070',1,'draft','{}',NULL,'none',NULL,NULL,NULL,1791158380000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000080',1,'draft','{}',NULL,'none',NULL,NULL,NULL,1791158380000);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000010',2,'sealed','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"story":"Synthetic metadata, no actual release or license.","creatorName":"Station Cat fixture"}',NULL,'none',120000,'ca760000-0000-4000-8000-000000000014',NULL,1791637164367);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000010',3,'sealed','{"originalLocale":"en","title":{"en":"T22 after migration","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"story":"Synthetic metadata, no actual release or license.","creatorName":"Station Cat fixture"}',NULL,'none',120000,'ca760000-0000-4000-8000-000000000014',NULL,1791637164835);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('7dce6ed2-c3fa-40fd-9d23-bc237fa08464',1,'draft','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"story":"Synthetic metadata, no actual release or license.","creatorName":"Station Cat fixture"}',NULL,'none',120000,NULL,NULL,1791637165292);;
INSERT INTO "station_track_revisions"("track_id","revision","state","metadata_json","legacy_revision_id","site_audio_mode","duration_ms","cover_asset_id","lyrics_asset_id","created_at") VALUES('ca760000-0000-4000-8000-000000000010',4,'sealed','{"originalLocale":"en","title":{"en":"permanent-free","zh-Hant":"夾具 permanent-free"},"summary":{"en":"Isolated fixture."},"story":"Synthetic metadata, no actual release or license.","creatorName":"Station Cat fixture"}',NULL,'none',120000,'ca760000-0000-4000-8000-000000000014',NULL,1791637168084);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('permanent-free','ca760000-0000-4000-8000-000000000010','canonical','legacy_backfill',1791158370000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('vip','ca760000-0000-4000-8000-000000000020','canonical','legacy_backfill',1791158370000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('limited-active','ca760000-0000-4000-8000-000000000030','canonical','legacy_backfill',1791158370000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('limited-expired','ca760000-0000-4000-8000-000000000040','canonical','legacy_backfill',1791158370000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('early-access','ca760000-0000-4000-8000-000000000050','canonical','legacy_backfill',1791158370000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('unpublished','ca760000-0000-4000-8000-000000000060','canonical','legacy_backfill',1791158370000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('draft-no-audio','ca760000-0000-4000-8000-000000000070','canonical','legacy_backfill',1791158380000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('archived-no-audio','ca760000-0000-4000-8000-000000000080','canonical','legacy_backfill',1791158380000);;
INSERT INTO "station_track_routes"("slug","track_id","role","origin","created_at") VALUES('t22-post-migration','7dce6ed2-c3fa-40fd-9d23-bc237fa08464','canonical','managed',1791637165292);;
CREATE INDEX music_analytics_rates_expiry ON music_analytics_rates(window_start);
CREATE INDEX music_assets_derived ON music_assets(derived_from_asset_id);
CREATE INDEX music_assets_owner ON music_assets(owner_track_id, state, kind);
CREATE INDEX music_attribution_retention ON music_membership_attributions(observed_at);
CREATE INDEX music_audit_time ON music_admin_audit_logs(created_at, id);
CREATE INDEX music_collection_track ON music_collection_tracks(track_id);
CREATE INDEX music_collections_type_status ON music_collections(collection_type,status,slug);
CREATE UNIQUE INDEX music_events_play_once
  ON music_analytics_events(anonymous_session_id,play_session_id,event_type);
CREATE INDEX music_events_retention ON music_analytics_events(received_at);
CREATE INDEX music_events_session ON music_analytics_events(anonymous_session_id, track_id, variant, event_type, occurred_at);
CREATE INDEX music_mutations_expiry ON music_mutations(expires_at);
CREATE INDEX music_rate_sources_expiry ON music_rate_sources(window_start);
CREATE INDEX music_rate_windows_expiry ON music_rate_windows(window_start);
CREATE INDEX music_share_rate_sources_expiry ON music_share_rate_sources(window_start);
CREATE INDEX music_share_rate_windows_expiry ON music_share_rate_windows(window_start);
CREATE INDEX music_tracks_public ON music_tracks(lifecycle, published_at DESC, id);
CREATE INDEX music_upload_expiry ON music_upload_sessions(status, expires_at);
CREATE INDEX station_campaign_legacy_owner ON station_campaign_legacy_sources(campaign_id);
CREATE INDEX station_campaign_track_created ON station_campaigns(track_id,created_at);
CREATE INDEX station_clip_status ON station_clips(track_id,status,published_at,id);
CREATE INDEX station_event_inflight_expiry ON station_event_inflight(expires_at);
CREATE INDEX station_event_inflight_window ON station_event_inflight(received_at);
CREATE INDEX station_event_received ON station_analytics_events(received_at,event_id);
CREATE UNIQUE INDEX station_events_click_once ON station_analytics_events(event_name,interaction_id) WHERE interaction_id IS NOT NULL;
CREATE INDEX station_events_expiry ON station_analytics_events(expires_at,event_id);
CREATE UNIQUE INDEX station_events_launch_once ON station_analytics_events(event_name,launch_id) WHERE event_name IN ('game_launch_request','game_ready');
CREATE UNIQUE INDEX station_events_play_once ON station_analytics_events(event_name,playback_id) WHERE playback_id IS NOT NULL;
CREATE UNIQUE INDEX station_events_save_once ON station_analytics_events(event_name,save_operation_id) WHERE save_operation_id IS NOT NULL;
CREATE INDEX station_events_track_visit ON station_analytics_events(session_id,track_id,event_name,received_at);
CREATE INDEX station_external_expiry ON station_external_metrics(expires_at);
CREATE INDEX station_external_window ON station_external_metrics(track_id,window_start,window_end);
CREATE INDEX station_game_public_status ON station_games(status,published_at,id);
CREATE INDEX station_media_upload_actor ON station_media_upload_sessions(actor_id,created_at,id);
CREATE UNIQUE INDEX station_one_pending_publish ON station_publish_jobs(object_type,object_id) WHERE status='pending';
CREATE INDEX station_platform_status ON station_platform_links(track_id,status,sort_order,id);
CREATE INDEX station_promotion_public_status ON station_promotions(status,published_at,track_id);
CREATE INDEX station_publish_due ON station_publish_jobs(status,due_at,id);
CREATE INDEX station_report_job_expiry ON station_report_jobs(expires_at);
CREATE INDEX station_report_operation_expiry ON station_report_operations(expires_at);
CREATE INDEX station_report_snapshot_expiry ON station_report_snapshots(expires_at);
CREATE UNIQUE INDEX station_track_one_canonical ON station_track_routes(track_id) WHERE role='canonical';
CREATE INDEX station_track_public_status ON station_track_publications(status,published_at,track_id);
CREATE TRIGGER music_album_cover_insert BEFORE INSERT ON music_collections WHEN NEW.cover_asset_id IS NOT NULL
BEGIN SELECT RAISE(ABORT,'MUSIC_ALBUM_COVER_INVALID'); END;
CREATE TRIGGER music_album_cover_update BEFORE UPDATE ON music_collections
WHEN NEW.cover_asset_id IS NOT NULL AND (NEW.collection_type<>'album' OR NOT EXISTS
 (SELECT 1 FROM music_collection_assets WHERE id=NEW.cover_asset_id AND owner_collection_id=NEW.id AND state='validated' AND kind='cover'))
BEGIN SELECT RAISE(ABORT,'MUSIC_ALBUM_COVER_INVALID'); END;
CREATE TRIGGER music_analytics_event_aggregate AFTER INSERT ON music_analytics_events
BEGIN
  INSERT INTO music_analytics_daily(day_start_ms,metric,track_id,variant,access_kind,value)
  SELECT NEW.received_at-NEW.received_at%86400000,NEW.event_type,NEW.track_id,NEW.variant,
    IIF(r.access_mode='free' OR (r.free_until IS NOT NULL AND NEW.received_at<r.free_until)
      OR (r.access_mode='early_access' AND r.early_access_until<=NEW.received_at
      AND r.post_early_access_mode='free'),'free','vip'),1
  FROM music_track_revisions r WHERE r.track_id=NEW.track_id AND r.revision_no=NEW.revision_no
  ON CONFLICT(day_start_ms,metric,track_id,variant,access_kind) DO UPDATE SET value=value+1;
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_AGGREGATE_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_analytics_event_validate BEFORE INSERT ON music_analytics_events
BEGIN
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_INVALID_EVENT') WHERE
    NEW.event_type NOT IN ('play_start','qualified_play','play_complete','preview_end','vip_cta_click')
    OR NEW.consent_version IS NOT 'music-analytics-v1' OR NEW.play_session_id IS NULL;
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_INVALID_TRACK') WHERE NOT EXISTS (
    SELECT 1 FROM music_analytics_public_variants p WHERE p.track_id=NEW.track_id
      AND p.revision_no=NEW.revision_no AND p.variant=NEW.variant AND p.published_at<=NEW.received_at
      AND NEW.listened_ms<=p.duration_ms+1000
      AND (NEW.event_type<>'qualified_play' OR NEW.listened_ms>=MIN(30000,p.duration_ms/2.0))
      AND (NEW.event_type<>'play_complete' OR NEW.listened_ms>=p.duration_ms*0.9));
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_INVALID_EVENT') WHERE
    (NEW.event_type='preview_end' AND NEW.variant<>'preview')
    OR (NEW.event_type IN ('play_start','vip_cta_click') AND NEW.listened_ms<>0);
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_SESSION_CONFLICT') WHERE EXISTS (
    SELECT 1 FROM music_analytics_events e WHERE e.anonymous_session_id=NEW.anonymous_session_id
      AND e.play_session_id=NEW.play_session_id
      AND (e.track_id<>NEW.track_id OR e.revision_no<>NEW.revision_no OR e.variant<>NEW.variant));
  SELECT RAISE(ABORT,'MUSIC_ANALYTICS_START_REQUIRED') WHERE
    NEW.event_type IN ('qualified_play','play_complete','preview_end') AND NOT EXISTS (
      SELECT 1 FROM music_analytics_events e WHERE e.anonymous_session_id=NEW.anonymous_session_id
        AND e.play_session_id=NEW.play_session_id AND e.event_type='play_start');
  -- Validate first, then suppress. Never depend on SQLite trigger ordering.
  -- The rolling window uses server receive time, not a client minute bucket.
  SELECT RAISE(IGNORE) WHERE NEW.event_type='qualified_play' AND EXISTS (
    SELECT 1 FROM music_analytics_events e WHERE e.anonymous_session_id=NEW.anonymous_session_id
      AND e.track_id=NEW.track_id AND e.variant=NEW.variant AND e.event_type='qualified_play'
      AND e.received_at>NEW.received_at-1800000);
END;
CREATE TRIGGER music_analytics_rate_insert BEFORE INSERT ON music_analytics_rates
WHEN (NEW.scope='session' AND NEW.hits>60) OR (NEW.scope='source' AND NEW.hits>600)
  OR (NEW.scope='global' AND NEW.hits>12000)
BEGIN SELECT RAISE(ABORT,'MUSIC_ANALYTICS_RATE_LIMITED'); END;
CREATE TRIGGER music_analytics_rate_update BEFORE UPDATE ON music_analytics_rates
WHEN (NEW.scope='session' AND NEW.hits>60) OR (NEW.scope='source' AND NEW.hits>600)
  OR (NEW.scope='global' AND NEW.hits>12000)
BEGIN SELECT RAISE(ABORT,'MUSIC_ANALYTICS_RATE_LIMITED'); END;
CREATE TRIGGER music_asset_identity BEFORE UPDATE OF id, owner_track_id, kind, object_key ON music_assets
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_IDENTITY'); END;
CREATE TRIGGER music_asset_immutable BEFORE UPDATE ON music_assets
WHEN OLD.state = 'validated' BEGIN SELECT RAISE(ABORT, 'MUSIC_VALIDATED_ASSET'); END;
CREATE TRIGGER music_asset_replace BEFORE INSERT ON music_assets
WHEN EXISTS (SELECT 1 FROM music_assets WHERE id = NEW.id OR object_key = NEW.object_key)
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_IDENTITY'); END;
CREATE TRIGGER music_asset_source_insert BEFORE INSERT ON music_assets
WHEN NEW.derived_from_asset_id IS NOT NULL AND NOT EXISTS
  (SELECT 1 FROM music_assets WHERE id = NEW.derived_from_asset_id AND kind = 'audio' AND owner_track_id = NEW.owner_track_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_PREVIEW_SOURCE'); END;
CREATE TRIGGER music_asset_source_update BEFORE UPDATE OF derived_from_asset_id ON music_assets
WHEN NEW.derived_from_asset_id IS NOT NULL AND NOT EXISTS
  (SELECT 1 FROM music_assets WHERE id = NEW.derived_from_asset_id AND kind = 'audio' AND owner_track_id = NEW.owner_track_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_PREVIEW_SOURCE'); END;
CREATE TRIGGER music_audit_delete BEFORE DELETE ON music_admin_audit_logs
BEGIN SELECT RAISE(ABORT, 'MUSIC_APPEND_ONLY_AUDIT'); END;
CREATE TRIGGER music_audit_replace BEFORE INSERT ON music_admin_audit_logs
WHEN EXISTS (SELECT 1 FROM music_admin_audit_logs WHERE id = NEW.id OR request_id = NEW.request_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_APPEND_ONLY_AUDIT'); END;
CREATE TRIGGER music_audit_update BEFORE UPDATE ON music_admin_audit_logs
BEGIN SELECT RAISE(ABORT, 'MUSIC_APPEND_ONLY_AUDIT'); END;
CREATE TRIGGER music_cleanup_asset_delete BEFORE DELETE ON music_assets
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=OLD.id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_asset_update BEFORE UPDATE ON music_assets
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id IN (NEW.id,NEW.derived_from_asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_audit BEFORE INSERT ON music_admin_audit_logs
WHEN NEW.action NOT IN ('music.upload.reserve','music.upload.start','music.upload.reject','music.upload.complete',
  'music.cleanup.claim','music.cleanup.prove','music.cleanup.release') AND EXISTS
  (SELECT 1 FROM music_upload_cleanup c WHERE NEW.target_id=c.asset_id
    OR EXISTS (SELECT 1 FROM json_tree(NEW.summary_json) j WHERE j.atom=c.asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_claim BEFORE INSERT ON music_upload_cleanup
WHEN NEW.proof_json IS NOT NULL OR NEW.released_at IS NOT NULL OR NOT EXISTS
  (SELECT 1 FROM music_upload_sessions u JOIN music_asset_references r ON r.id=u.asset_id
   WHERE u.id=NEW.upload_id AND u.asset_id=NEW.asset_id AND u.expires_at<=NEW.claimed_at-604800000
   AND r.revision_ref=0 AND r.evidence_ref=0 AND r.rights_ref=0 AND r.derived_ref=0 AND r.audit_ref=0)
  OR EXISTS (SELECT 1 FROM music_upload_cleanup WHERE upload_id=NEW.upload_id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_CLEANUP_CONFLICT'); END;
CREATE TRIGGER music_cleanup_delete BEFORE DELETE ON music_upload_cleanup
BEGIN SELECT RAISE(ABORT,'MUSIC_CLEANUP_IMMUTABLE'); END;
CREATE TRIGGER music_cleanup_evidence BEFORE INSERT ON music_rights_evidence
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_revision_insert BEFORE INSERT ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id IN
  (NEW.audio_asset_id,NEW.preview_asset_id,NEW.cover_asset_id,NEW.lyrics_asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_revision_update BEFORE UPDATE ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id IN
  (NEW.audio_asset_id,NEW.preview_asset_id,NEW.cover_asset_id,NEW.lyrics_asset_id))
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_rights_insert BEFORE INSERT ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup c,json_tree(NEW.review_json) j WHERE j.atom=c.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_rights_update BEFORE UPDATE ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup c,json_tree(NEW.review_json) j WHERE j.atom=c.asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_source_insert BEFORE INSERT ON music_assets
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.derived_from_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_cleanup_update BEFORE UPDATE ON music_upload_cleanup
WHEN NEW.upload_id<>OLD.upload_id OR NEW.asset_id<>OLD.asset_id OR NEW.actor_id<>OLD.actor_id
  OR NEW.reason<>OLD.reason OR NEW.plan_hash<>OLD.plan_hash OR NEW.claimed_at<>OLD.claimed_at
  OR (OLD.proof_json IS NOT NULL AND (NEW.proof_json IS NOT OLD.proof_json OR NEW.proved_at IS NOT OLD.proved_at))
  OR (OLD.proof_json IS NULL AND NEW.released_at IS NOT NULL)
  OR OLD.released_at IS NOT NULL
BEGIN SELECT RAISE(ABORT,'MUSIC_CLEANUP_IMMUTABLE'); END;
CREATE TRIGGER music_cleanup_upload_update BEFORE UPDATE ON music_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE upload_id=OLD.id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER music_collection_asset_delete BEFORE DELETE ON music_collection_assets
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETAINED'); END;
CREATE TRIGGER music_collection_asset_identity BEFORE UPDATE OF id,owner_collection_id,kind,object_key,format,content_type ON music_collection_assets
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_IDENTITY'); END;
CREATE TRIGGER music_collection_asset_immutable BEFORE UPDATE ON music_collection_assets WHEN OLD.state='validated'
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_IMMUTABLE'); END;
CREATE TRIGGER music_collection_asset_owner BEFORE INSERT ON music_collection_assets
WHEN NOT EXISTS(SELECT 1 FROM music_collections WHERE id=NEW.owner_collection_id AND collection_type='album' AND status='draft')
BEGIN SELECT RAISE(ABORT,'MUSIC_DRAFT_REQUIRED'); END;
CREATE TRIGGER music_collection_asset_replace BEFORE INSERT ON music_collection_assets WHEN EXISTS(SELECT 1 FROM music_collection_assets WHERE id=NEW.id OR object_key=NEW.object_key)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_IMMUTABLE'); END;
CREATE TRIGGER music_collection_type_immutable BEFORE UPDATE OF collection_type ON music_collections
WHEN NEW.collection_type<>OLD.collection_type
BEGIN SELECT RAISE(ABORT,'MUSIC_COLLECTION_IDENTITY'); END;
CREATE TRIGGER music_collection_type_replace BEFORE INSERT ON music_collections
WHEN EXISTS (SELECT 1 FROM music_collections
  WHERE (id=NEW.id OR slug=NEW.slug) AND collection_type<>NEW.collection_type)
BEGIN SELECT RAISE(ABORT,'MUSIC_COLLECTION_IDENTITY'); END;
CREATE TRIGGER music_collection_upload_identity BEFORE UPDATE ON music_collection_upload_sessions
WHEN NEW.id<>OLD.id OR NEW.asset_id<>OLD.asset_id OR NEW.actor_id<>OLD.actor_id
  OR NEW.declared_bytes<>OLD.declared_bytes OR NEW.expected_sha256 IS NOT OLD.expected_sha256
  OR NEW.created_at<>OLD.created_at OR NEW.expires_at<>OLD.expires_at
  OR (OLD.write_token IS NOT NULL AND NEW.write_token IS NOT OLD.write_token)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_collection_upload_no_delete BEFORE DELETE ON music_collection_upload_sessions
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_collection_upload_no_replace BEFORE INSERT ON music_collection_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_collection_upload_sessions WHERE id=NEW.id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_collection_upload_terminal BEFORE UPDATE ON music_collection_upload_sessions WHEN OLD.status IN ('completed','rejected','expired')
BEGIN SELECT RAISE(ABORT,'MUSIC_UPLOAD_TERMINAL'); END;
CREATE TRIGGER music_collection_upload_transition BEFORE UPDATE OF status ON music_collection_upload_sessions
WHEN NOT ((OLD.status='reserved' AND NEW.status IN ('uploading','expired','rejected'))
  OR (OLD.status='uploading' AND NEW.status IN ('completed','rejected','expired')))
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_STATE'); END;
CREATE TRIGGER music_evidence_delete BEFORE DELETE ON music_rights_evidence
WHEN EXISTS (SELECT 1 FROM music_rights_reviews rr JOIN music_track_revisions r ON r.id = rr.revision_id
  WHERE rr.id = OLD.review_id AND r.state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_evidence_insert BEFORE INSERT ON music_rights_evidence
WHEN NOT EXISTS (SELECT 1 FROM music_rights_reviews rr JOIN music_track_revisions r ON r.id = rr.revision_id
  JOIN music_assets a ON a.id = NEW.asset_id WHERE rr.id = NEW.review_id AND r.state = 'draft'
  AND a.owner_track_id = r.track_id AND a.kind = 'evidence' AND a.state = 'validated')
BEGIN SELECT RAISE(ABORT, 'MUSIC_EVIDENCE_REFERENCE'); END;
CREATE TRIGGER music_evidence_update BEFORE UPDATE ON music_rights_evidence
BEGIN SELECT RAISE(ABORT, 'MUSIC_EVIDENCE_REPLACE'); END;
CREATE TRIGGER music_featured_collection_insert BEFORE INSERT ON music_featured_items
WHEN NEW.collection_id IS NOT NULL AND NOT EXISTS (
  SELECT 1 FROM music_collections WHERE id=NEW.collection_id AND status='published'
)
BEGIN SELECT RAISE(ABORT,'MUSIC_FEATURED_COLLECTION_UNAVAILABLE'); END;
CREATE TRIGGER music_featured_track_insert BEFORE INSERT ON music_featured_items
WHEN NEW.track_id IS NOT NULL AND NOT EXISTS (
  SELECT 1 FROM music_tracks WHERE id=NEW.track_id AND lifecycle='published'
)
BEGIN SELECT RAISE(ABORT,'MUSIC_FEATURED_TRACK_UNAVAILABLE'); END;
CREATE TRIGGER music_mutation_delete BEFORE DELETE ON music_mutations
BEGIN SELECT RAISE(ABORT, 'MUSIC_IMMUTABLE_MUTATION'); END;
CREATE TRIGGER music_mutation_replace BEFORE INSERT ON music_mutations
WHEN EXISTS (SELECT 1 FROM music_mutations WHERE actor_id = NEW.actor_id
  AND route = NEW.route AND idempotency_key = NEW.idempotency_key)
BEGIN SELECT RAISE(ABORT, 'MUSIC_IMMUTABLE_MUTATION'); END;
CREATE TRIGGER music_mutation_update BEFORE UPDATE ON music_mutations
BEGIN SELECT RAISE(ABORT, 'MUSIC_IMMUTABLE_MUTATION'); END;
CREATE TRIGGER music_rate_source_identity BEFORE UPDATE ON music_rate_sources
WHEN NEW.category<>OLD.category OR NEW.window_start<>OLD.window_start OR NEW.source_hash<>OLD.source_hash OR NEW.hits<>OLD.hits+1
BEGIN SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID'); END;
CREATE TRIGGER music_rate_source_insert AFTER INSERT ON music_rate_sources
BEGIN
  INSERT INTO music_rate_windows(category,window_start,hits) VALUES(NEW.category,NEW.window_start,1)
  ON CONFLICT(category,window_start) DO UPDATE SET hits=hits+1;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_rate_source_update AFTER UPDATE ON music_rate_sources
BEGIN
  UPDATE music_rate_windows SET hits=hits+1 WHERE category=NEW.category AND window_start=NEW.window_start;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_revision_assets_insert AFTER INSERT ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_invalid_revision_assets WHERE id = NEW.id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_REFERENCE'); END;
CREATE TRIGGER music_revision_assets_update AFTER UPDATE ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_invalid_revision_assets WHERE id = NEW.id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_ASSET_REFERENCE'); END;
CREATE TRIGGER music_revision_identity BEFORE UPDATE OF id, track_id, revision_no ON music_track_revisions
BEGIN SELECT RAISE(ABORT, 'MUSIC_REVISION_IDENTITY'); END;
CREATE TRIGGER music_revision_immutable BEFORE UPDATE ON music_track_revisions
WHEN OLD.state = 'sealed' BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVISION'); END;
CREATE TRIGGER music_revision_replace BEFORE INSERT ON music_track_revisions
WHEN EXISTS (SELECT 1 FROM music_track_revisions WHERE state = 'sealed'
  AND (id = NEW.id OR (track_id = NEW.track_id AND revision_no = NEW.revision_no)))
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVISION'); END;
CREATE TRIGGER music_revision_retained BEFORE DELETE ON music_track_revisions
WHEN OLD.state = 'sealed' BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVISION'); END;
CREATE TRIGGER music_rights_delete BEFORE DELETE ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_track_revisions WHERE id = OLD.revision_id AND state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_rights_insert BEFORE INSERT ON music_rights_reviews
WHEN EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.revision_id AND state = 'sealed') OR
  EXISTS (SELECT 1 FROM music_rights_reviews rr JOIN music_track_revisions r ON r.id = rr.revision_id
    WHERE rr.id = NEW.id AND r.state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_rights_update BEFORE UPDATE ON music_rights_reviews
WHEN NEW.revision_id <> OLD.revision_id OR EXISTS (SELECT 1 FROM music_track_revisions WHERE id = OLD.revision_id AND state = 'sealed')
BEGIN SELECT RAISE(ABORT, 'MUSIC_SEALED_REVIEW'); END;
CREATE TRIGGER music_share_rate_source_identity BEFORE UPDATE ON music_share_rate_sources
WHEN NEW.category<>OLD.category OR NEW.window_start<>OLD.window_start OR NEW.source_hash<>OLD.source_hash OR NEW.hits<>OLD.hits+1
BEGIN SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID'); END;
CREATE TRIGGER music_share_rate_source_insert AFTER INSERT ON music_share_rate_sources
BEGIN
  INSERT INTO music_share_rate_windows(category,window_start,hits) VALUES(NEW.category,NEW.window_start,1)
  ON CONFLICT(category,window_start) DO UPDATE SET hits=hits+1;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_share_rate_source_update AFTER UPDATE ON music_share_rate_sources
BEGIN
  UPDATE music_share_rate_windows SET hits=hits+1 WHERE category=NEW.category AND window_start=NEW.window_start;
  SELECT RAISE(ABORT,'MUSIC_RATE_COUNTER_INVALID') WHERE changes()<>1;
END;
CREATE TRIGGER music_track_archive BEFORE UPDATE OF lifecycle ON music_tracks
WHEN OLD.lifecycle = 'published' AND NEW.lifecycle = 'archived'
BEGIN SELECT RAISE(ABORT, 'MUSIC_UNPUBLISH_FIRST'); END;
CREATE TRIGGER music_track_identity BEFORE UPDATE OF id ON music_tracks
BEGIN SELECT RAISE(ABORT, 'MUSIC_TRACK_IDENTITY'); END;
CREATE TRIGGER music_track_pointers_insert AFTER INSERT ON music_tracks
WHEN (NEW.published_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.published_revision_id AND state = 'sealed'))
  OR (NEW.draft_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.draft_revision_id AND state = 'draft'))
BEGIN SELECT RAISE(ABORT, 'MUSIC_REVISION_POINTER'); END;
CREATE TRIGGER music_track_pointers_update AFTER UPDATE ON music_tracks
WHEN (NEW.published_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.published_revision_id AND state = 'sealed'))
  OR (NEW.draft_revision_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_track_revisions WHERE id = NEW.draft_revision_id AND state = 'draft'))
BEGIN SELECT RAISE(ABORT, 'MUSIC_REVISION_POINTER'); END;
CREATE TRIGGER music_track_replace BEFORE INSERT ON music_tracks
WHEN EXISTS (SELECT 1 FROM music_tracks WHERE id = NEW.id OR slug = NEW.slug)
BEGIN SELECT RAISE(ABORT, 'MUSIC_TRACK_IDENTITY'); END;
CREATE TRIGGER music_track_slug BEFORE UPDATE OF slug, first_published_at ON music_tracks
WHEN OLD.first_published_at IS NOT NULL AND (NEW.slug <> OLD.slug OR NEW.first_published_at IS NOT OLD.first_published_at)
BEGIN SELECT RAISE(ABORT, 'MUSIC_PUBLISHED_IDENTITY'); END;
CREATE TRIGGER music_upload_identity BEFORE UPDATE ON music_upload_sessions
WHEN NEW.id<>OLD.id OR NEW.asset_id<>OLD.asset_id OR NEW.actor_id<>OLD.actor_id
  OR NEW.declared_bytes<>OLD.declared_bytes OR NEW.expected_sha256 IS NOT OLD.expected_sha256
  OR NEW.created_at<>OLD.created_at OR NEW.expires_at<>OLD.expires_at
  OR (OLD.write_token IS NOT NULL AND NEW.write_token IS NOT OLD.write_token)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_upload_no_delete BEFORE DELETE ON music_upload_sessions
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_upload_no_replace BEFORE INSERT ON music_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_upload_sessions WHERE id=NEW.id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_IMMUTABLE'); END;
CREATE TRIGGER music_upload_replace BEFORE INSERT ON music_upload_sessions
WHEN EXISTS (SELECT 1 FROM music_upload_sessions WHERE status IN ('completed','rejected','expired')
  AND (id = NEW.id OR asset_id = NEW.asset_id))
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_TERMINAL'); END;
CREATE TRIGGER music_upload_terminal BEFORE UPDATE ON music_upload_sessions
WHEN OLD.status IN ('completed','rejected','expired')
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_TERMINAL'); END;
CREATE TRIGGER music_upload_transition BEFORE UPDATE OF status ON music_upload_sessions
WHEN NOT ((OLD.status='reserved' AND NEW.status IN ('uploading','expired','rejected'))
  OR (OLD.status='uploading' AND NEW.status IN ('completed','rejected','expired')))
BEGIN SELECT RAISE(ABORT, 'MUSIC_UPLOAD_STATE'); END;
CREATE TRIGGER station_analytics_events_append_only BEFORE UPDATE ON station_analytics_events
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_RETAINED'); END;
CREATE TRIGGER station_analytics_events_replace BEFORE INSERT ON station_analytics_events WHEN EXISTS (SELECT 1 FROM station_analytics_events WHERE event_id=NEW.event_id)
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_RETAINED'); END;
CREATE TRIGGER station_analytics_events_retained BEFORE DELETE ON station_analytics_events
WHEN NOT EXISTS(SELECT 1 FROM station_event_retention_guard WHERE singleton=1 AND OLD.expires_at<=cutoff)
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_RETAINED'); END;
CREATE TRIGGER station_asset_rights_identity BEFORE UPDATE OF id,music_asset_id,media_asset_id,scope ON station_asset_rights
WHEN NEW.id IS NOT OLD.id OR NEW.music_asset_id IS NOT OLD.music_asset_id OR NEW.media_asset_id IS NOT OLD.media_asset_id OR NEW.scope IS NOT OLD.scope
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_asset_rights_replace BEFORE INSERT ON station_asset_rights WHEN EXISTS (SELECT 1 FROM station_asset_rights WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_asset_rights_retained BEFORE DELETE ON station_asset_rights
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_asset_rights_retired_asset_insert BEFORE INSERT ON station_asset_rights
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.music_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_asset_rights_retired_asset_update BEFORE UPDATE ON station_asset_rights
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.music_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_campaign_dimensions_immutable
BEFORE UPDATE OF id,source,medium,track_id,clip_id,landing_path,content_value ON station_campaigns
BEGIN SELECT RAISE(ABORT,'STATION_CAMPAIGN_IMMUTABLE'); END;
CREATE TRIGGER station_campaign_legacy_immutable BEFORE UPDATE ON station_campaign_legacy_sources
BEGIN SELECT RAISE(ABORT,'STATION_CAMPAIGN_IMMUTABLE'); END;
CREATE TRIGGER station_campaign_legacy_replace BEFORE INSERT ON station_campaign_legacy_sources
WHEN EXISTS(SELECT 1 FROM station_campaign_legacy_sources WHERE source_key=NEW.source_key)
BEGIN SELECT RAISE(ABORT,'STATION_CAMPAIGN_IMMUTABLE'); END;
CREATE TRIGGER station_campaign_legacy_retained BEFORE DELETE ON station_campaign_legacy_sources
BEGIN SELECT RAISE(ABORT,'STATION_CAMPAIGN_RETAINED'); END;
CREATE TRIGGER station_campaigns_identity BEFORE UPDATE OF id,track_id,clip_id ON station_campaigns
WHEN NEW.id IS NOT OLD.id OR NEW.track_id IS NOT OLD.track_id OR NEW.clip_id IS NOT OLD.clip_id
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_campaigns_replace BEFORE INSERT ON station_campaigns WHEN EXISTS (SELECT 1 FROM station_campaigns WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_campaigns_retained BEFORE DELETE ON station_campaigns
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_clip_kind_insert BEFORE INSERT ON station_clip_revisions
WHEN (NEW.media_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_media_assets a JOIN station_clips c ON c.id=NEW.id WHERE a.id=NEW.media_asset_id AND a.owner_clip_id=c.id AND a.kind=c.type))
 OR (NEW.poster_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.poster_asset_id AND owner_clip_id=NEW.id AND kind='poster'))
BEGIN SELECT RAISE(ABORT,'STATION_CLIP_ASSET_REFERENCE'); END;
CREATE TRIGGER station_clip_kind_update BEFORE UPDATE ON station_clip_revisions
WHEN (NEW.media_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_media_assets a JOIN station_clips c ON c.id=NEW.id WHERE a.id=NEW.media_asset_id AND a.owner_clip_id=c.id AND a.kind=c.type))
 OR (NEW.poster_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.poster_asset_id AND owner_clip_id=NEW.id AND kind='poster'))
BEGIN SELECT RAISE(ABORT,'STATION_CLIP_ASSET_REFERENCE'); END;
CREATE TRIGGER station_clip_publications_identity BEFORE UPDATE OF id,clip_id,channel,post_id ON station_clip_publications
WHEN NEW.id IS NOT OLD.id OR NEW.clip_id IS NOT OLD.clip_id OR NEW.channel IS NOT OLD.channel OR NEW.post_id IS NOT OLD.post_id
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_clip_publications_replace BEFORE INSERT ON station_clip_publications WHEN EXISTS (SELECT 1 FROM station_clip_publications WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_clip_publications_retained BEFORE DELETE ON station_clip_publications
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_clip_revisions_identity BEFORE UPDATE OF id,revision ON station_clip_revisions
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_clip_revisions_immutable BEFORE UPDATE ON station_clip_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_clip_revisions_replace BEFORE INSERT ON station_clip_revisions
WHEN EXISTS (SELECT 1 FROM station_clip_revisions WHERE id=NEW.id AND revision=NEW.revision AND state='sealed')
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_clip_revisions_retained BEFORE DELETE ON station_clip_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_clips_identity BEFORE UPDATE OF id,track_id,type ON station_clips
WHEN NEW.id IS NOT OLD.id OR NEW.track_id IS NOT OLD.track_id OR NEW.type IS NOT OLD.type
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_clips_pointers_insert AFTER INSERT ON station_clips
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_clip_revisions WHERE id=NEW.id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_clip_revisions WHERE id=NEW.id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_clips_pointers_update AFTER UPDATE ON station_clips
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_clip_revisions WHERE id=NEW.id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_clip_revisions WHERE id=NEW.id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_clips_replace BEFORE INSERT ON station_clips WHEN EXISTS (SELECT 1 FROM station_clips WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_clips_retained BEFORE DELETE ON station_clips
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_cover_kind_insert BEFORE INSERT ON station_track_revisions
WHEN NEW.cover_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.cover_asset_id AND owner_track_id=NEW.track_id AND kind='cover')
BEGIN SELECT RAISE(ABORT,'STATION_COVER_REFERENCE'); END;
CREATE TRIGGER station_cover_kind_update BEFORE UPDATE ON station_track_revisions
WHEN NEW.cover_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.cover_asset_id AND owner_track_id=NEW.track_id AND kind='cover')
BEGIN SELECT RAISE(ABORT,'STATION_COVER_REFERENCE'); END;
CREATE TRIGGER station_event_inflight_budget BEFORE INSERT ON station_event_inflight
WHEN NOT EXISTS(SELECT 1 FROM station_report_window_seal WHERE singleton=1 AND sealed_before<=NEW.received_at)
 OR EXISTS(SELECT 1 FROM station_event_inflight LIMIT 1 OFFSET 4095)
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_WRITE_FENCED'); END;
CREATE TRIGGER station_event_inflight_immutable BEFORE UPDATE ON station_event_inflight
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_WRITE_FENCED'); END;
CREATE TRIGGER station_event_rates_budget BEFORE INSERT ON station_event_rates
WHEN NEW.hits>CASE NEW.scope WHEN 'session' THEN 120 WHEN 'source' THEN 600 ELSE 12000 END
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_RATE_LIMITED'); END;
CREATE TRIGGER station_event_rates_update_budget BEFORE UPDATE ON station_event_rates
WHEN NEW.hits>CASE NEW.scope WHEN 'session' THEN 120 WHEN 'source' THEN 600 ELSE 12000 END
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_RATE_LIMITED'); END;
CREATE TRIGGER station_event_sealed_window BEFORE INSERT ON station_analytics_events
WHEN NOT EXISTS(SELECT 1 FROM station_report_window_seal WHERE singleton=1 AND sealed_before<=NEW.received_at)
BEGIN SELECT RAISE(ABORT,'STATION_EVENT_WRITE_FENCED'); END;
CREATE TRIGGER station_external_delete BEFORE DELETE ON station_external_metrics
WHEN NOT EXISTS(SELECT 1 FROM station_report_retention_guard WHERE singleton=1 AND OLD.expires_at<=cutoff)
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_RETAINED'); END;
CREATE TRIGGER station_external_identity BEFORE UPDATE ON station_external_metrics
WHEN NEW.id<>OLD.id OR NEW.track_id<>OLD.track_id OR NEW.clip_id IS NOT OLD.clip_id
 OR NEW.campaign_id IS NOT OLD.campaign_id OR NEW.metric<>OLD.metric OR NEW.provider<>OLD.provider
 OR NEW.window_start<>OLD.window_start OR NEW.window_end<>OLD.window_end OR NEW.expires_at<>OLD.expires_at
 OR NEW.edit_version<>OLD.edit_version+1
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_EDIT_CONFLICT'); END;
CREATE TRIGGER station_game_revisions_identity BEFORE UPDATE OF id,revision ON station_game_revisions
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_game_revisions_immutable BEFORE UPDATE ON station_game_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_game_revisions_replace BEFORE INSERT ON station_game_revisions
WHEN EXISTS (SELECT 1 FROM station_game_revisions WHERE id=NEW.id AND revision=NEW.revision AND state='sealed')
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_game_revisions_retained BEFORE DELETE ON station_game_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_game_revisions_screenshot_ids_json_insert BEFORE INSERT ON station_game_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.screenshot_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=item.value AND owner_game_id=NEW.id AND kind='game_screenshot'))
  OR json_array_length(NEW.screenshot_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.screenshot_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_game_revisions_screenshot_ids_json_update BEFORE UPDATE ON station_game_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.screenshot_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=item.value AND owner_game_id=NEW.id AND kind='game_screenshot'))
  OR json_array_length(NEW.screenshot_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.screenshot_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_game_runtime_identity BEFORE UPDATE OF runtime_key ON station_games
WHEN NEW.runtime_key IS NOT OLD.runtime_key AND (OLD.runtime_key IS NOT NULL OR OLD.published_revision IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'STATION_GAME_RUNTIME_IDENTITY'); END;
CREATE TRIGGER station_games_identity BEFORE UPDATE OF id,slug ON station_games
WHEN NEW.id IS NOT OLD.id OR NEW.slug IS NOT OLD.slug
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_games_pointers_insert AFTER INSERT ON station_games
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_game_revisions WHERE id=NEW.id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_game_revisions WHERE id=NEW.id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_games_pointers_update AFTER UPDATE ON station_games
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_game_revisions WHERE id=NEW.id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_game_revisions WHERE id=NEW.id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_games_replace BEFORE INSERT ON station_games WHEN EXISTS (SELECT 1 FROM station_games WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_games_retained BEFORE DELETE ON station_games
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_home_configs_identity BEFORE UPDATE OF id ON station_home_configs
WHEN NEW.id IS NOT OLD.id
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_home_configs_pointers_insert AFTER INSERT ON station_home_configs
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_home_revisions WHERE id=NEW.id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_home_revisions WHERE id=NEW.id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_home_configs_pointers_update AFTER UPDATE ON station_home_configs
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_home_revisions WHERE id=NEW.id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_home_revisions WHERE id=NEW.id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_home_configs_replace BEFORE INSERT ON station_home_configs WHEN EXISTS (SELECT 1 FROM station_home_configs WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_home_configs_retained BEFORE DELETE ON station_home_configs
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_home_revisions_identity BEFORE UPDATE OF id,revision ON station_home_revisions
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_home_revisions_immutable BEFORE UPDATE ON station_home_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_home_revisions_replace BEFORE INSERT ON station_home_revisions
WHEN EXISTS (SELECT 1 FROM station_home_revisions WHERE id=NEW.id AND revision=NEW.revision AND state='sealed')
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_home_revisions_retained BEFORE DELETE ON station_home_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_home_revisions_selected_clip_ids_json_insert BEFORE INSERT ON station_home_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_clip_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_clips WHERE id=item.value))
  OR json_array_length(NEW.selected_clip_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_clip_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_home_revisions_selected_clip_ids_json_update BEFORE UPDATE ON station_home_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_clip_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_clips WHERE id=item.value))
  OR json_array_length(NEW.selected_clip_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_clip_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_home_revisions_selected_track_ids_json_insert BEFORE INSERT ON station_home_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_track_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM music_tracks WHERE id=item.value))
  OR json_array_length(NEW.selected_track_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_track_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_home_revisions_selected_track_ids_json_update BEFORE UPDATE ON station_home_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_track_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM music_tracks WHERE id=item.value))
  OR json_array_length(NEW.selected_track_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_track_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_legacy_track_slug_reservation BEFORE INSERT ON music_tracks
WHEN EXISTS (SELECT 1 FROM station_track_routes WHERE slug=NEW.slug AND track_id<>NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_SLUG_OWNERSHIP'); END;
CREATE TRIGGER station_legacy_track_slug_update BEFORE UPDATE OF slug ON music_tracks
WHEN EXISTS (SELECT 1 FROM station_track_routes WHERE slug=NEW.slug AND track_id<>NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_SLUG_OWNERSHIP'); END;
CREATE TRIGGER station_lyrics_kind_insert BEFORE INSERT ON station_track_revisions
WHEN NEW.lyrics_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.lyrics_asset_id AND owner_track_id=NEW.track_id AND kind='lyrics')
BEGIN SELECT RAISE(ABORT,'STATION_LYRICS_REFERENCE'); END;
CREATE TRIGGER station_lyrics_kind_update BEFORE UPDATE ON station_track_revisions
WHEN NEW.lyrics_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.lyrics_asset_id AND owner_track_id=NEW.track_id AND kind='lyrics')
BEGIN SELECT RAISE(ABORT,'STATION_LYRICS_REFERENCE'); END;
CREATE TRIGGER station_lyrics_retired_insert BEFORE INSERT ON station_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.lyrics_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_lyrics_retired_update BEFORE UPDATE ON station_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.lyrics_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_media_asset_body BEFORE UPDATE OF object_key,kind,owner_clip_id,owner_game_id ON station_media_assets
BEGIN SELECT RAISE(ABORT,'STATION_ASSET_IDENTITY'); END;
CREATE TRIGGER station_media_asset_replace BEFORE INSERT ON station_media_assets
WHEN EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.id OR object_key=NEW.object_key)
BEGIN SELECT RAISE(ABORT,'STATION_ASSET_IDENTITY'); END;
CREATE TRIGGER station_media_asset_terminal BEFORE UPDATE OF state ON station_media_assets
WHEN (OLD.state='validated' AND NEW.state NOT IN ('validated','revoked')) OR (OLD.state='revoked' AND NEW.state<>'revoked')
BEGIN SELECT RAISE(ABORT,'STATION_VALIDATED_ASSET'); END;
CREATE TRIGGER station_media_asset_validated BEFORE UPDATE OF content_type,byte_size,duration_ms,width,height,sha256,etag ON station_media_assets WHEN OLD.state IN ('validated','revoked')
BEGIN SELECT RAISE(ABORT,'STATION_VALIDATED_ASSET'); END;
CREATE TRIGGER station_media_assets_identity BEFORE UPDATE OF id ON station_media_assets
WHEN NEW.id IS NOT OLD.id
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_media_assets_retained BEFORE DELETE ON station_media_assets
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_media_upload_asset BEFORE INSERT ON station_media_upload_sessions
WHEN NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.asset_id AND state='reserved')
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_ASSET'); END;
CREATE TRIGGER station_media_upload_completed BEFORE UPDATE OF status ON station_media_upload_sessions
WHEN NEW.status='completed' AND NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.asset_id
 AND state='validated' AND byte_size=NEW.actual_bytes AND sha256=NEW.expected_sha256 AND etag IS NOT NULL
 AND width IS NOT NULL AND height IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_ASSET'); END;
CREATE TRIGGER station_media_upload_identity BEFORE UPDATE OF id,asset_id,actor_id,declared_bytes,expected_sha256,created_at,expires_at ON station_media_upload_sessions
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_IDENTITY'); END;
CREATE TRIGGER station_media_upload_replace BEFORE INSERT ON station_media_upload_sessions
WHEN EXISTS (SELECT 1 FROM station_media_upload_sessions WHERE id=NEW.id OR asset_id=NEW.asset_id)
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_IDENTITY'); END;
CREATE TRIGGER station_media_upload_retained BEFORE DELETE ON station_media_upload_sessions
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_RETAINED'); END;
CREATE TRIGGER station_media_upload_terminal BEFORE UPDATE ON station_media_upload_sessions
WHEN OLD.status IN ('completed','rejected','expired')
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_TERMINAL'); END;
CREATE TRIGGER station_media_upload_transition BEFORE UPDATE OF status ON station_media_upload_sessions
WHEN NOT ((OLD.status='reserved' AND NEW.status IN ('uploading','rejected','expired'))
 OR (OLD.status='uploading' AND NEW.status IN ('uploaded','validating','rejected','expired'))
 OR (OLD.status='uploaded' AND NEW.status IN ('validating','rejected','expired'))
 OR (OLD.status='validating' AND NEW.status IN ('completed','rejected','expired')))
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_TRANSITION'); END;
CREATE TRIGGER station_media_upload_writer BEFORE UPDATE OF write_token ON station_media_upload_sessions
WHEN OLD.write_token IS NOT NULL OR NEW.write_token IS NULL OR OLD.status<>'reserved'
BEGIN SELECT RAISE(ABORT,'STATION_UPLOAD_WRITER'); END;
CREATE TRIGGER station_platform_links_identity BEFORE UPDATE OF id,track_id,provider ON station_platform_links
WHEN NEW.id IS NOT OLD.id OR NEW.track_id IS NOT OLD.track_id OR NEW.provider IS NOT OLD.provider
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_platform_links_replace BEFORE INSERT ON station_platform_links WHEN EXISTS (SELECT 1 FROM station_platform_links WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_platform_links_retained BEFORE DELETE ON station_platform_links
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_platform_territories_insert BEFORE INSERT ON station_platform_links
WHEN NEW.territories_json<>(SELECT json_group_array(value) FROM (SELECT DISTINCT value FROM json_each(NEW.territories_json) ORDER BY value))
  OR EXISTS (SELECT 1 FROM json_each(NEW.territories_json) WHERE type<>'text' OR (value<>'*' AND (length(value)<>2 OR value GLOB '*[^A-Z]*')))
  OR (json_array_length(NEW.territories_json)>1 AND EXISTS (SELECT 1 FROM json_each(NEW.territories_json) WHERE value='*'))
BEGIN SELECT RAISE(ABORT,'STATION_TERRITORIES'); END;
CREATE TRIGGER station_platform_territories_update BEFORE UPDATE ON station_platform_links
WHEN NEW.territories_json<>(SELECT json_group_array(value) FROM (SELECT DISTINCT value FROM json_each(NEW.territories_json) ORDER BY value))
  OR EXISTS (SELECT 1 FROM json_each(NEW.territories_json) WHERE type<>'text' OR (value<>'*' AND (length(value)<>2 OR value GLOB '*[^A-Z]*')))
  OR (json_array_length(NEW.territories_json)>1 AND EXISTS (SELECT 1 FROM json_each(NEW.territories_json) WHERE value='*'))
BEGIN SELECT RAISE(ABORT,'STATION_TERRITORIES'); END;
CREATE TRIGGER station_preview_kind_insert BEFORE INSERT ON station_promotion_revisions
WHEN NEW.preview_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.preview_asset_id AND owner_track_id=NEW.track_id AND kind='preview')
BEGIN SELECT RAISE(ABORT,'STATION_PREVIEW_REFERENCE'); END;
CREATE TRIGGER station_preview_kind_update BEFORE UPDATE ON station_promotion_revisions
WHEN NEW.preview_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.preview_asset_id AND owner_track_id=NEW.track_id AND kind='preview')
BEGIN SELECT RAISE(ABORT,'STATION_PREVIEW_REFERENCE'); END;
CREATE TRIGGER station_promotion_revisions_identity BEFORE UPDATE OF track_id,revision ON station_promotion_revisions
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_promotion_revisions_immutable BEFORE UPDATE ON station_promotion_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_promotion_revisions_replace BEFORE INSERT ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM station_promotion_revisions WHERE track_id=NEW.track_id AND revision=NEW.revision AND state='sealed')
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_promotion_revisions_retained BEFORE DELETE ON station_promotion_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_promotion_revisions_retired_asset_insert BEFORE INSERT ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.preview_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_promotion_revisions_retired_asset_update BEFORE UPDATE ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.preview_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_promotion_revisions_selected_clip_ids_json_insert BEFORE INSERT ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_clip_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_clips WHERE id=item.value AND track_id=NEW.track_id))
  OR json_array_length(NEW.selected_clip_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_clip_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_promotion_revisions_selected_clip_ids_json_update BEFORE UPDATE ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_clip_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_clips WHERE id=item.value AND track_id=NEW.track_id))
  OR json_array_length(NEW.selected_clip_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_clip_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_promotion_revisions_selected_platform_ids_json_insert BEFORE INSERT ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_platform_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_platform_links WHERE id=item.value AND track_id=NEW.track_id))
  OR json_array_length(NEW.selected_platform_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_platform_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_promotion_revisions_selected_platform_ids_json_update BEFORE UPDATE ON station_promotion_revisions
WHEN EXISTS (SELECT 1 FROM json_each(NEW.selected_platform_ids_json) AS item WHERE item.type<>'text' OR NOT EXISTS (SELECT 1 FROM station_platform_links WHERE id=item.value AND track_id=NEW.track_id))
  OR json_array_length(NEW.selected_platform_ids_json)<>(SELECT COUNT(DISTINCT value) FROM json_each(NEW.selected_platform_ids_json))
BEGIN SELECT RAISE(ABORT,'STATION_SELECTED_REFERENCE'); END;
CREATE TRIGGER station_promotions_identity BEFORE UPDATE OF track_id ON station_promotions
WHEN NEW.track_id IS NOT OLD.track_id
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_promotions_pointers_insert AFTER INSERT ON station_promotions
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_promotion_revisions WHERE track_id=NEW.track_id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_promotion_revisions WHERE track_id=NEW.track_id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_promotions_pointers_update AFTER UPDATE ON station_promotions
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_promotion_revisions WHERE track_id=NEW.track_id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_promotion_revisions WHERE track_id=NEW.track_id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_promotions_replace BEFORE INSERT ON station_promotions WHEN EXISTS (SELECT 1 FROM station_promotions WHERE track_id=NEW.track_id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_promotions_retained BEFORE DELETE ON station_promotions
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_publish_job_identity BEFORE UPDATE OF id,object_type,object_id,revision,edit_version,actor_id,due_at,created_at ON station_publish_jobs
BEGIN SELECT RAISE(ABORT,'STATION_JOB_IDENTITY'); END;
CREATE TRIGGER station_publish_job_replace BEFORE INSERT ON station_publish_jobs WHEN EXISTS(SELECT 1 FROM station_publish_jobs WHERE id=NEW.id)
BEGIN SELECT RAISE(ABORT,'STATION_JOB_RETAINED'); END;
CREATE TRIGGER station_publish_job_retained BEFORE DELETE ON station_publish_jobs
BEGIN SELECT RAISE(ABORT,'STATION_JOB_RETAINED'); END;
CREATE TRIGGER station_publish_job_terminal BEFORE UPDATE ON station_publish_jobs WHEN OLD.status<>'pending'
BEGIN SELECT RAISE(ABORT,'STATION_JOB_TERMINAL'); END;
CREATE TRIGGER station_report_job_delete BEFORE DELETE ON station_report_jobs
WHEN NOT EXISTS(SELECT 1 FROM station_report_retention_guard WHERE singleton=1 AND OLD.expires_at<=cutoff)
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_RETAINED'); END;
CREATE TRIGGER station_report_job_sealed BEFORE INSERT ON station_report_jobs
WHEN NOT EXISTS(SELECT 1 FROM station_report_window_seal WHERE singleton=1 AND sealed_before>=NEW.window_end)
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_WINDOW_UNSEALED'); END;
CREATE TRIGGER station_report_operation_delete BEFORE DELETE ON station_report_operations
WHEN NOT EXISTS(SELECT 1 FROM station_report_retention_guard WHERE singleton=1 AND OLD.expires_at<=cutoff)
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_RETAINED'); END;
CREATE TRIGGER station_report_operation_immutable BEFORE UPDATE ON station_report_operations
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_RETAINED'); END;
CREATE TRIGGER station_report_seal_monotonic BEFORE UPDATE ON station_report_window_seal
WHEN NEW.singleton<>OLD.singleton OR NEW.sealed_before<OLD.sealed_before OR NEW.updated_at<OLD.updated_at
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_SEAL_RETAINED'); END;
CREATE TRIGGER station_report_seal_retained BEFORE DELETE ON station_report_window_seal
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_SEAL_RETAINED'); END;
CREATE TRIGGER station_report_snapshot_delete BEFORE DELETE ON station_report_snapshots
WHEN NOT EXISTS(SELECT 1 FROM station_report_retention_guard WHERE singleton=1 AND OLD.expires_at<=cutoff)
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_RETAINED'); END;
CREATE TRIGGER station_report_snapshot_immutable BEFORE UPDATE ON station_report_snapshots
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_RETAINED'); END;
CREATE TRIGGER station_report_snapshot_sealed BEFORE INSERT ON station_report_snapshots
WHEN NOT EXISTS(SELECT 1 FROM station_report_window_seal WHERE singleton=1 AND sealed_before>=NEW.window_end)
 OR NEW.generated_at<NEW.window_end
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_WINDOW_UNSEALED'); END;
CREATE TRIGGER station_report_snapshot_shape BEFORE INSERT ON station_report_snapshots
WHEN EXISTS(SELECT 1 FROM json_each(NEW.stats_json) WHERE key NOT IN
 ('track_view','preview_start','full_audio_start','preview_qualified','platform_click','clip_start','clip_complete','game_launch_request','game_ready','save_success','visit_sessions','preview_sessions','click_sessions','unlinked_previews','unlinked_clicks','memory_events','time_anomalies')
 OR type<>'integer' OR value<0 OR value>9007199254740991)
 OR (SELECT COUNT(*) FROM json_each(NEW.stats_json))<>17
 OR (SELECT SUM(value) FROM json_each(NEW.stats_json) WHERE key IN ('track_view','preview_start','full_audio_start','preview_qualified','platform_click','clip_start','clip_complete','game_launch_request','game_ready','save_success'))>20000
BEGIN SELECT RAISE(ABORT,'STATION_REPORT_INVALID_AGGREGATE'); END;
CREATE TRIGGER station_rights_scope_insert BEFORE INSERT ON station_asset_rights
WHEN (NEW.music_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.music_asset_id AND kind=NEW.scope AND kind IN ('cover','preview','lyrics')))
  OR (NEW.media_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.media_asset_id AND kind=NEW.scope))
BEGIN SELECT RAISE(ABORT,'STATION_RIGHTS_SCOPE'); END;
CREATE TRIGGER station_rights_scope_update BEFORE UPDATE ON station_asset_rights
WHEN (NEW.music_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM music_assets WHERE id=NEW.music_asset_id AND kind=NEW.scope AND kind IN ('cover','preview','lyrics')))
  OR (NEW.media_asset_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_media_assets WHERE id=NEW.media_asset_id AND kind=NEW.scope))
BEGIN SELECT RAISE(ABORT,'STATION_RIGHTS_SCOPE'); END;
CREATE TRIGGER station_track_publications_identity BEFORE UPDATE OF track_id ON station_track_publications
WHEN NEW.track_id IS NOT OLD.track_id
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_track_publications_pointers_insert AFTER INSERT ON station_track_publications
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_track_revisions WHERE track_id=NEW.track_id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_track_revisions WHERE track_id=NEW.track_id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_track_publications_pointers_update AFTER UPDATE ON station_track_publications
WHEN (NEW.draft_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_track_revisions WHERE track_id=NEW.track_id AND revision=NEW.draft_revision AND state='draft'))
  OR (NEW.published_revision IS NOT NULL AND NOT EXISTS (SELECT 1 FROM station_track_revisions WHERE track_id=NEW.track_id AND revision=NEW.published_revision AND state='sealed'))
BEGIN SELECT RAISE(ABORT,'STATION_REVISION_POINTER'); END;
CREATE TRIGGER station_track_publications_replace BEFORE INSERT ON station_track_publications WHEN EXISTS (SELECT 1 FROM station_track_publications WHERE track_id=NEW.track_id)
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_track_publications_retained BEFORE DELETE ON station_track_publications
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE TRIGGER station_track_revisions_identity BEFORE UPDATE OF track_id,revision ON station_track_revisions
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_track_revisions_immutable BEFORE UPDATE ON station_track_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_track_revisions_replace BEFORE INSERT ON station_track_revisions
WHEN EXISTS (SELECT 1 FROM station_track_revisions WHERE track_id=NEW.track_id AND revision=NEW.revision AND state='sealed')
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_track_revisions_retained BEFORE DELETE ON station_track_revisions WHEN OLD.state='sealed'
BEGIN SELECT RAISE(ABORT,'STATION_SEALED_REVISION'); END;
CREATE TRIGGER station_track_revisions_retired_asset_insert BEFORE INSERT ON station_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.cover_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_track_revisions_retired_asset_update BEFORE UPDATE ON station_track_revisions
WHEN EXISTS (SELECT 1 FROM music_upload_cleanup WHERE asset_id=NEW.cover_asset_id)
BEGIN SELECT RAISE(ABORT,'MUSIC_ASSET_RETIRED'); END;
CREATE TRIGGER station_track_routes_alias BEFORE UPDATE OF role ON station_track_routes WHEN OLD.role='alias' AND NEW.role<>OLD.role
BEGIN SELECT RAISE(ABORT,'STATION_SLUG_RETIRED'); END;
CREATE TRIGGER station_track_routes_identity BEFORE UPDATE OF slug,track_id,origin,created_at ON station_track_routes
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_IDENTITY'); END;
CREATE TRIGGER station_track_routes_owner BEFORE INSERT ON station_track_routes
WHEN EXISTS (SELECT 1 FROM station_track_routes WHERE slug=NEW.slug AND track_id<>NEW.track_id)
  OR EXISTS (SELECT 1 FROM music_tracks WHERE slug=NEW.slug AND id<>NEW.track_id)
BEGIN SELECT RAISE(ABORT,'STATION_SLUG_OWNERSHIP'); END;
CREATE TRIGGER station_track_routes_replace BEFORE INSERT ON station_track_routes
WHEN EXISTS (SELECT 1 FROM station_track_routes WHERE slug=NEW.slug AND (track_id<>NEW.track_id OR role<>NEW.role OR origin<>NEW.origin OR created_at<>NEW.created_at))
BEGIN SELECT RAISE(ABORT,'STATION_SLUG_RETAINED'); END;
CREATE TRIGGER station_track_routes_retained BEFORE DELETE ON station_track_routes
BEGIN SELECT RAISE(ABORT,'STATION_OBJECT_RETAINED'); END;
CREATE VIEW music_analytics_public_variants AS
SELECT t.id AS track_id,r.revision_no,'full' AS variant,a.duration_ms,t.published_at
FROM music_tracks t JOIN music_track_revisions r ON r.id=t.published_revision_id AND r.track_id=t.id
JOIN music_assets a ON a.id=r.audio_asset_id AND a.owner_track_id=t.id
WHERE t.lifecycle='published' AND r.state='sealed' AND a.state='validated' AND a.kind='audio' AND a.duration_ms>0
UNION ALL
SELECT t.id,r.revision_no,'preview',a.duration_ms,t.published_at
FROM music_tracks t JOIN music_track_revisions r ON r.id=t.published_revision_id AND r.track_id=t.id
JOIN music_assets a ON a.id=r.preview_asset_id AND a.owner_track_id=t.id
WHERE t.lifecycle='published' AND r.state='sealed' AND a.state='validated' AND a.kind='preview' AND a.duration_ms>0;
CREATE VIEW music_asset_references AS
SELECT a.id,
  (EXISTS (SELECT 1 FROM music_track_revisions r WHERE a.id IN
    (r.audio_asset_id,r.preview_asset_id,r.cover_asset_id,r.lyrics_asset_id))
   OR EXISTS (SELECT 1 FROM station_track_revisions r WHERE a.id IN (r.cover_asset_id,r.lyrics_asset_id))
   OR EXISTS (SELECT 1 FROM station_promotion_revisions r WHERE r.preview_asset_id=a.id)) AS revision_ref,
  EXISTS (SELECT 1 FROM music_rights_evidence e WHERE e.asset_id=a.id) AS evidence_ref,
  (EXISTS (SELECT 1 FROM music_rights_reviews r,json_tree(r.review_json) j WHERE j.atom=a.id)
   OR EXISTS (SELECT 1 FROM station_asset_rights r WHERE r.music_asset_id=a.id)) AS rights_ref,
  EXISTS (SELECT 1 FROM music_assets d WHERE d.derived_from_asset_id=a.id
    AND NOT EXISTS (SELECT 1 FROM music_upload_cleanup c WHERE c.asset_id=d.id)) AS derived_ref,
  EXISTS (SELECT 1 FROM music_admin_audit_logs l WHERE l.action NOT IN
    ('music.upload.reserve','music.upload.start','music.upload.reject','music.upload.complete',
     'music.cleanup.claim','music.cleanup.prove','music.cleanup.release')
    AND (l.target_id=a.id OR EXISTS (SELECT 1 FROM json_tree(l.summary_json) j WHERE j.atom=a.id))) AS audit_ref
FROM music_assets a;
CREATE VIEW music_invalid_revision_assets AS
SELECT r.id FROM music_track_revisions r WHERE EXISTS (
  SELECT 1 FROM music_assets a WHERE
    (a.id = r.audio_asset_id AND a.kind <> 'audio') OR
    (a.id = r.cover_asset_id AND a.kind <> 'cover') OR
    (a.id = r.lyrics_asset_id AND a.kind <> 'lyrics') OR
    (a.id = r.preview_asset_id AND (a.kind <> 'preview' OR a.derived_from_asset_id IS NOT r.audio_asset_id)) OR
    (r.state = 'sealed' AND a.id IN (r.audio_asset_id, r.preview_asset_id, r.cover_asset_id, r.lyrics_asset_id) AND a.state <> 'validated')
);
CREATE VIEW music_storage_charges AS
-- Each compound SELECT stays within the native D1/workerd five-term limit.
SELECT asset_id,charged_bytes FROM (
SELECT u.asset_id,u.declared_bytes AS charged_bytes FROM music_upload_sessions u
WHERE NOT EXISTS(SELECT 1 FROM music_upload_cleanup c WHERE c.upload_id=u.id AND c.released_at IS NOT NULL)
UNION ALL SELECT a.id,a.byte_size FROM music_assets a WHERE NOT EXISTS(SELECT 1 FROM music_upload_sessions u WHERE u.asset_id=a.id)
UNION ALL SELECT u.asset_id,u.declared_bytes FROM music_collection_upload_sessions u
UNION ALL SELECT a.id,a.byte_size FROM music_collection_assets a WHERE NOT EXISTS(SELECT 1 FROM music_collection_upload_sessions u WHERE u.asset_id=a.id)
)
UNION ALL SELECT u.asset_id,u.declared_bytes FROM station_media_upload_sessions u
UNION ALL SELECT a.id,COALESCE(a.byte_size,CASE WHEN a.kind IN ('short_video','mv') THEN 268435456 ELSE 10485760 END)
 FROM station_media_assets a WHERE NOT EXISTS(SELECT 1 FROM station_media_upload_sessions u WHERE u.asset_id=a.id);
